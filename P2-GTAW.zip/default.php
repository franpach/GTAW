<?php
	header('Location: main.html');
?>