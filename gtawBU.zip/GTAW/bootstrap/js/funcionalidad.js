/**
* Suma o resta los votos de un artículo
*/
function votoPosArt(usuario, idarticulo, tipo, idpositivo, idnegativo){

	if(usuario == "visitante") {
		alert("Tienes que estar registrado para poder puntuar");
	}
	else {
		var xhttp;
		var parrilla = "#";
		var positivo = parrilla.concat(idpositivo);
		var negativo = parrilla.concat(idnegativo);
		
		$.ajax({
			dataType: "json",
			type: "GET",
			url: 'votoPosArt.php',
			data: ({usuario:usuario,idarticulo:idarticulo,tipo:tipo}),
			success: function (data, textStatus){
	    			$(positivo).html(data.pos);
			       	$(negativo).html(data.neg);
			 	},
			 	error: function() {
					alert("No ha podido registrarse el voto");	
			 	}
		});	
	}
		
}

function votoNegArt(usuario, idarticulo, tipo, idpositivo, idnegativo){

	if(usuario == "visitante") {
		alert("Tienes que estar registrado para poder puntuar");
	}
	else {
		var parrilla = "#";
		var positivo = parrilla.concat(idpositivo);
		var negativo = parrilla.concat(idnegativo);
		
		$.ajax({
    		dataType: "json",
    		type: "GET",
    		url: 'votoNegArt.php',
    		data: ({usuario:usuario,idarticulo:idarticulo,tipo:tipo}),
    		success: function (data, textStatus){
        		$(positivo).html(data.pos);
 		       	$(negativo).html(data.neg);
   		 	},
   		 	error: function() {
					alert("No ha podido registrarse el voto");	
			 	}
		});

	}
}

/**
* Suma o resta votos de un comentario
*/

function votoPosCom(usuario, idcomentario, tipo, idpositivo, idnegativo) {
	if(usuario == "visitante") {
		alert("Tienes que estar registrado para poder puntuar");
	}
	else {
		var parrilla = "#";
		var positivo = parrilla.concat(idpositivo);
		var negativo = parrilla.concat(idnegativo);
		
		$.ajax({
    		dataType: "json",
    		type: "GET",
    		url: 'votoPosCom.php',
    		data: ({usuario:usuario,idcomentario:idcomentario,tipo:tipo}),
    		success: function (data, textStatus){
        		$(positivo).html(data.pos);
 		       	$(negativo).html(data.neg);
   		 	},
   		 	error: function() {
					alert("No ha podido registrarse el voto");	
			 	}
		});

	}	
}

function votoNegCom(usuario, idcomentario, tipo, idpositivo, idnegativo) {
	if(usuario == "visitante") {
		alert("Tienes que estar registrado para poder puntuar");
	}
	else {
		var parrilla = "#";
		var positivo = parrilla.concat(idpositivo);
		var negativo = parrilla.concat(idnegativo);
		
		$.ajax({
    		dataType: "json",
    		type: "GET",
    		url: 'votoNegCom.php',
    		data: ({usuario:usuario,idcomentario:idcomentario,tipo:tipo}),
    		success: function (data, textStatus){
        		$(positivo).html(data.pos);
 		       	$(negativo).html(data.neg);
   		 	},
   		 	error: function() {
					alert("No ha podido registrarse el voto");	
			 	}
		});

	}	
}


/**
* Función para validar una dirección de correo
* Tiene que recibir el identificador del formulario
*/ 

function validateMail(idMail) {
	//Creamos un objeto 
   	object=document.getElementById(idMail);
    valueForm=object.value;

    // Patron para el correcto
    var patron=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/;
    if(valueForm.search(patron)==0) {
    //Mail correcto
       	document.getElementById('correoCorrecto').style.display = 'inline-block';
        document.getElementById('correoIncorrecto').style.display = 'none';
        object.style.color="#000";
  	    return;
    }
    else if (valueForm == 0) {
        //No hay mail escrito
        document.getElementById('correoCorrecto').style.display = 'none';          
        document.getElementById('correoIncorrecto').style.display = 'none';
    }
    else {
        //Mail incorrecto
        document.getElementById('correoIncorrecto').style.display = 'inline-block';
        document.getElementById('correoCorrecto').style.display = 'none';
        object.style.color="#f00";
    }
}

/**
*Función que valida una contraseña
*/
function validatePass(idPass1,idPass2)
{

	//Creamos un objeto 
	object1=document.getElementById(idPass1);
	object2=document.getElementById(idPass2);
	valueForm1=object1.value;
	valueForm2=object2.value;
 
	// Patron para el correo
	if(valueForm1==valueForm2)
	{
		//Mail correcto
		document.getElementById('pwdCorrecto').style.display = 'inline-block';
		document.getElementById('pwdIncorrecto').style.display = 'none';
		object1.style.color="#000";
		return;
	}
	else if (valueForm2==0) {
		//No hay contraseña escrita
		document.getElementById('pwdIncorrecto').style.display = 'none';
		document.getElementById('pwdIncorrecto').style.display = 'none';
	}
	else {
		//Mail incorrecto
		document.getElementById('pwdCorrecto').style.display = 'inline-block';
		document.getElementById('pwdIncorrecto').style.display = 'none';
		object1.style.color="#f00";
	}
}

/*
* Función que comprueba que un nick está cogido antes de enviar un formulario en el registro
*/
function compruebaUser(usuario) {
	object=document.getElementById(usuario);
    valueForm=object.value;
    if(valueForm=="") {
		document.getElementById('selected').style.display = 'none';	
	}
	else {
		var xhttp;
		xhttp=new XMLHttpRequest();
		xhttp.onreadystatechange=function(){
			if(xhttp.readyState==4&&xhttp.status==200) {
				document.getElementById("selected").innerHTML=xhttp.responseText;
			}
		}
		
		xhttp.open("GET", "listausuarios.php?usuario="+valueForm, true);
		xhttp.send();
		document.getElementById('selected').style.display = 'inline-block';
	}
	
}

/**
*
*/
function insertarNota() {
	$("input[name=articulo]").change(function(){
		$("notaIn").hide();
		if($(this).attr('id')=="analisis") {
			$("#notaIn").show();
		}
		else {
			$("#notaIn").hide();	
		}
	});
}

function reporte(){
     prompt("Indica la razón del reporte: (-Al hacer un reporte se avisaría a algún administrador del reporte y de la causa de dicho reporte para que él decida sobre lo que hacer con el mensaje-)","");
}
