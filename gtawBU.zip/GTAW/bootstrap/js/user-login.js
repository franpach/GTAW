/* Simula el logueo de un usuario, todavía no se ha implementado la base de datos de la página */

function logueoCorrecto(){

	var boton=getElementsByTagName(form-group);
	var b = boton[2];
	document.write(getAttribute(b));
	if(b.onmouseup) {
	alert("logueado!");	
	}
	//var nuevaVentana=window.open("main.html");
	//alert("logueado!");
}