<?php
    echo '<footer class="footer">
      		<p>© 2016 GTAW, Inc. | Lee <a href="normas.php">aquí</a> nuestras normas</p>
   		 </footer>'; 
?>