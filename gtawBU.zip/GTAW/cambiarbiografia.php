<?php
	require 'dbconnect.php';
	require 'database.php';

	session_start();
	$user = $_SESSION["nombre"];
	$info = $_REQUEST['info'];

	$insert = cambiarBiografia($user, $info);
	header('Location: usuario.php?usuario=$user'); 	
?>