<?php

	$db= mysqli_connect('localhost','aw','admin');
	if($db){
		//echo 'vale';
	}
	else {
		//echo'Fallo en la conexión.';
	}

	$sql = "SELECT id_juego FROM aw.videojuegos";
	$result = mysqli_query($db, $sql);
	$data = array();
	while($fila = mysqli_fetch_assoc($result)) {
		$data[] = $fila["id_juego"];
	}
	$q = $_REQUEST["q"];
	$hint=array();

	if($q!==""){
		$q = strtolower($q);
		$len = strlen($q);
		foreach ($data as $value) {
			if(stristr($q, substr($value, 0, $len))) {
				if($hint=="") {
					$hint[0]=$value;
				}
				else {
					$hint[] = $value;
				}
			}
		}
		
	}
	if (empty($hint)) {
		echo "no hay usuarios";
	}
	else {
		foreach ($hint as $nombre) {
		echo "<ul>
				<li> $nombre </li>
			</ul>";
		}	
	}


?>