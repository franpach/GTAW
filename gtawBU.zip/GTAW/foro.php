<!DOCTYPE html>
<html lang="es"><head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="http://getbootstrap.com/favicon.ico">

    <title>Foro de GTAW</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
   
    <link rel="stylesheet" href="bootstrap/css/foro.css" />
    <link rel="stylesheet" href="bootstrap/css/header.css">
    <link rel="stylesheet" href="bootstrap/css/bootstrap-theme.css" />

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <script src="js/bootstrap.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script type="text/javascript" src="bootstrap/js/funcionalidad.js"></script>
  </head>

  <body>
  <?php
    include 'database.php';
    session_start();

    $temas = sacarTemas();
    if($temas) {
      if(mysqli_num_rows($temas)==0) $noTemas = true;
      else $noTemas = false;
    }
    else $noTemas = true;
  ?>

  <div class="container">

    <!-- CABECERA -->
    <?php
      include 'menu.php';
    ?>

    <!-- LINKS -->
    <div class="row links">
      <div class="col-lg-12">
        <a href="main.php" >Inicio</a> / <a href="foro.php" >Foro</a> 
      </div>
    </div>

    <!-- TITULO -->
    <div class="row">
      <div class="col-lg-12">
        <h1 class="titulo"> Foro </h1>
      </div>
    </div>

    <!-- LEAD -->
    <div class="row">
      <div class="col-lg-12">
        <p class="lead">En este foro podrás discutir diversos temas relacionados con videojuegos con otros usuarios que sean miembros de la comunidad.</p>
      </div>
    </div>

    <!-- FORO -->
    <div class="row">
      <div class="col-lg-5">
        <p><a class="btn btn-primary" href="creartema.php" role="button" >Crear tema</a></p>
      </div>
    </div>
    <?php
        if($noTemas) {
          print '<div class="row">
                <div class="col-lg-12 nolista">
                  <p> Vaya, parece que nadie ha publicado ningún tema en el foro. </p>
                </div>
              </div>
              ';
        }
        else {
          print'<table class="table table-striped">
                  <thead>
                    <tr>
                      <th>Tema</th>
                      <th class=" text-center hidden-xs hidden-sm"></th>
                      <th class=" text-center ">Primer Post</th>
                      <th class=" text-center hidden-xs hidden-sm"></th>
                      <th class=" text-center hidden-xs hidden-sm">Último Post</th>
                      <th class="text-center">Respuestas</th>
                    </tr>
                  </thead>
                  <tbody>';
              //Se obtiene el número de páginas que va a tener el foro
              $num_total = mysqli_num_rows($temas);
              $tamano_pagina = 5;
              $pagina=0;
              if(isset($_GET["pagina"])){
              $pagina = $_GET["pagina"];
             }
              if(!$pagina){
                $inicio=0;
                $pagina=1;
              }
              else
              {
                $inicio = ($pagina - 1) * $tamano_pagina;
              }
              $total_paginas = ceil($num_total / $tamano_pagina);
              $temas = dividirTemas($inicio,$tamano_pagina);
          while($tema = mysqli_fetch_row($temas)) {
            // DE CADA TEMA SE SACAN INFORMACIÓN DEL ÚLTIMO MENSAJE Y NÚMERO DE MENSAJES TOTALES
            $consultaUM = ultimoMensaje($tema[0]);
            $consultaNM = numMensajes($tema[0]);
            if(!$consultaUM || !$consultaNM) {
              echo '<tr><td>no se puede recuperar información de este tema.</td></tr>';
            }
            else {
              $consultaFotoPM = fotoUsuario($tema[2]);
              $fotoPM = mysqli_fetch_row($consultaFotoPM); 
              if(mysqli_num_rows($consultaUM)==0) { // SI NO HAY MÁS MENSAJES QUE EL PRIMERO, EL ÚLTIMO MENSAJE TENDRÁ LA MISMA INFO QUE EL PRIMERO
                $ultimoMensaje = array();
                $ultimoMensaje[0] = $tema[2];
                $ultimoMensaje[1] = $tema[4];
                $fotoUM = array();
                $fotoUM[0] = $fotoPM[0];
              }
              else {
                $ultimoMensaje = mysqli_fetch_row($consultaUM);
                $consultaFotoUM = fotoUsuario($ultimoMensaje[0]);
                $fotoUM = mysqli_fetch_row($consultaFotoUM);
              }
              $numMsj = mysqli_fetch_row($consultaNM);
              $numero = $numMsj[0];
              print'<tr>
                    <td>
                      <h4><a href="mensaje.php?idTema='. $tema[0] .'">'. $tema[1] .'</a></h4>
                    </td>
                    <td class="text-center hidden-xs hidden-sm"><img src='. $fotoPM[0] . '  class ="user_img" alt="imagen de usuario no disponible"></td>
                    <td class="text-center ">por <a href="usuario.php?user=' . $tema[2] . '">'. $tema[2] . '</a><br> '. $tema[4] . '</td>
                    <td class="text-center hidden-xs hidden-sm"><img src='. $fotoUM[0] .' class ="user_img" alt="imagen de usuario no disponible"></td>
                    <td class="text-center hidden-xs hidden-sm">por <a href="usuario.php?user=' . $ultimoMensaje[0] . '">'. $ultimoMensaje[0] .'</a><br>' . $ultimoMensaje[1] . '</td>
                    <td class="text-center" ><a href="#">' . $numero . '</a></td>
                </tr>';
            }
          
          }
          print   '</tbody>
                </table>';
        
          //paginacion
        if ($total_paginas > 1)
                {
                  echo '<ul class="pagination ">';
                  if ($pagina != 1)
                    echo '<li><a href="foro.php?pagina='.($pagina-1).'">&laquo;</a></li>';
                    for ($i=1;$i<=$total_paginas;$i++) {
                       if ($pagina == $i)
                          //si muestro el índice de la página actual, no coloco enlace
                          echo "<li class='active'><a href='#'>". $pagina . "</a></li>";
                       else
                          //si el índice no corresponde con la página mostrada actualmente,
                          //coloco el enlace para ir a esa página
                          echo '  <li><a href="foro.php?pagina='.$i.'">'.$i.'</a></li>  ';
                    }
                    if ($pagina != $total_paginas)
                    {
                       echo '<li><a href="foro.php?pagina='.($pagina+1).'">&raquo;</a></li>';
                     }
                     echo '</ul>';
              }
            }
        
        ?>
  
    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?>
 
</div>


</body>
</html>