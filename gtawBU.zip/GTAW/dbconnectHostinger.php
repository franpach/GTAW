<?php
	$servername = "mysql.hostinger.es";
	$database = "u870692062_aw";
	$username = "u870692062_aw";
	$password = "gtaw2017";
	$db= mysqli_connect($servername,$username,$password,$database);
	if($db){
		return $db;
	}
	else {
		die("Conexión fallida: " . mysqli_connect_error());
	}
	mysqli_close($db);
?>
