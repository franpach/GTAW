<?php
	include 'database.php';

	$usuario = $_GET["usuario"];
	$idarticulo = $_GET["idarticulo"];
	$tipo = $_GET["tipo"];

	// Sacamos los votos positivos, negativos y valoración del artículo
	$val_pos = votosPos($idarticulo, $tipo);
	$val = mysqli_fetch_row($val_pos);
	$votos_pos = $val[0];
	$votos_neg = $val[1];
	$valoracionArt = $val[2];

	// También sacamos los votos que tenía el usuario y su id
	if ($tipo == "analisis") {
		$consulta = consultaAnalisis($idarticulo);
		$fila = mysqli_fetch_row($consulta);
		$escritor = $fila[2]; // El id del usuario escritor
	}
	else {
		$consulta = consultaOpinion($idarticulo);
		$fila = mysqli_fetch_row($consulta);
		$escritor = $fila[2]; // El id del usuario escritor
	}
	$consulta = sacarUsuario($escritor);
	$fila = mysqli_fetch_row($consulta);
	$valoracionUser = $fila[3]; // La valoración del usuario


	// Comprobamos si le ha dado like o dislike con anterioridad
	$havotado = compruebaMeGusta($idarticulo, $usuario, $tipo);
	if (mysqli_num_rows($havotado)==0){
		// Si no ha puntuado el artículo, se procede a registrar el voto
		// Le sumamos un voto positivo y uno a la valoración total
		$votos_pos = $votos_pos + 1;
		$valoracionArt = $valoracionArt + 1;

		// Le sumamos uno a la valoración del usuario
		$valoracionUser = $valoracionUser + 1;

		//Actualizamos el recuento e indicamos que al usuario le ha gustado esa publicacion, también se suma 1 a la puntuación del usuario y del artículo
		if (insertMeGusta($idarticulo, $usuario, $tipo, 1) && actualizaVotosPosArt($idarticulo, $tipo, $votos_pos) && actualizaValUser($escritor, $valoracionUser) && actualizaValArticulo($idarticulo, $valoracionArt, $tipo)) {
				echo json_encode(array("pos" => $votos_pos, "neg" => $votos_neg));
		}
	}
	else {
		$voto = mysqli_fetch_row($havotado);
		if ($voto[2]==1) { 
			// si había votado ya positivamente, se quitan las puntuaciones
			$valoracionUser = $valoracionUser - 1;
			$votos_pos = $votos_pos - 1;
			$valoracionArt = $valoracionArt - 1;

			// se elimina la entrada de los me gusta registrados
			if (eliminarMegustaArt($idarticulo, $usuario, $tipo) && actualizaVotosPosArt($idarticulo, $tipo, $votos_pos) && actualizaValUser($escritor, $valoracionUser) && actualizaValArticulo($idarticulo, $valoracionArt, $tipo)) {

				echo json_encode(array("pos" => $votos_pos, "neg" => $votos_neg)); 

				//echo $votos_pos;
			}
		}
		else {
			// si había votado negativamente, se quita el voto negativo y se añade uno positivo
			$valoracionUser = $valoracionUser + 2;
			$votos_pos = $votos_pos + 1;
			$votos_neg = $votos_neg - 1;
			$valoracionArt = $valoracionArt + 2;

			// se actualiza la entrada de los me gusta registrados
			if (actMegustaArt($idarticulo, $usuario, $tipo, 1) && actualizaVotosNegArt($idarticulo, $tipo, $votos_neg) && actualizaValUser($escritor, $valoracionUser) && actualizaValArticulo($idarticulo, $valoracionArt, $tipo) && actualizaVotosPosArt($idarticulo, $tipo, $votos_pos)) {
				echo json_encode(array("pos" => $votos_pos, "neg" => $votos_neg));
			}
		}
	}

?>