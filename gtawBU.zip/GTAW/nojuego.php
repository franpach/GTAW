<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>Horizon: Zero Dawn</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="bootstrap/css/subetucontenido.css" rel="stylesheet">
  <link rel="stylesheet" href="bootstrap/css/header.css">

  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>
  <!-- Funcionalidad de la página -->
  <script src="bootstrap/js/funcionalidad.js"></script>
</head>
<body>
  <div class="container">

    <!-- CABECERA -->
    <div class="masthead">
      <div class="row">
        <div class="col-lg-2">
          <h3 class="text-muted">GTAW</h3>
        </div>
        <div class="col-lg-3 col-lg-offset-7">
          <p class="perfil"><a href="miusuario.html">Ver mi perfil >></a>
        </div>
      </div> 
      <div class="row">
        <div class="col-lg-3 col-lg-offset-7">
          <form>
            <input type="search" name="search" placeholder="Buscar...">
            <button class="search" type="submit"><img src="img/search.png" width=19 height=19 alt="búsqueda"></button>
          </form>
        </div>
        <div class="col-lg-2">
          <p class="reg"><a href="login.html">Login</a> | <a href="registro.html">Regístrate</a></p>
        </div>
        <div class="row">
          <div class="col-lg-1">
            <button class="navbar-toggle collapsed" type="button" data-target="#navbarCollapse" data-toggle="collapse" aria-expanded="false">
              <span class="sr-only">Toggle navigation </span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
          </div>
        </div>
        <div id="navbarCollapse" class="navbar-collapse collapse" aria-expanded="false" role="banner">
          <ul class="nav nav-justified">
            <li><a href="main.html">Home</a></li>
            <li><a href="juegos.html">Juegos</a></li>
            <li><a href="foro.html">Foro</a></li>
            <li class="dropdown"><a class="dropbtn">Top <span class="caret"></span></a>
              <div class="dropdown-content">
                <a href="topjuegos.html"> Top juegos </a>
                <a href="topusers.html"> Top usuarios </a>
              </div>
            </li>
            <li><a href="subetucontenido.html">Sube tu contenido</a></li>
            <li class="dropdown"><a class="dropbtn">Acerca de<span class="caret"></span></a>
            <div class="dropdown-content">
              <a href="acercade.html">¿Quiénes somos?</a>
              <a href="contacto.html">Contacto</a>
            </div>
          </ul>
        </div>
      </div>
    </div>

    <!-- TITULO -->
    <div class="row">
      <div class="col-lg-12">
        <h1>Juego no encontrado</h1>
      </div>
    </div>

    <!-- MENSAJE ERROR -->
    <div class="row">
      <div class="col-lg-12">
        <p class="lead"> ¡Vaya! Parece que el juego que estás buscando no se encuentra en nuestra base de datos. ¿Estás seguro de que existe? De ser así, no dudes en comentárnoslo a través de nuestra página de <a href="contacto.php">contacto</a>.
        </p>
      </div>
    </div>

    

    <!-- Site footer -->
    <footer class="footer">
      <p>© 2016 GTAW, Inc. | Lee <a href="normas.html">aquí</a> nuestras normas</p>
    </footer> 

  </div>
</body>
</html>