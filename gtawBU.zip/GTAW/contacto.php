<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>Contacto</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="bootstrap/css/contacto.css" rel="stylesheet">
  <link rel="stylesheet" href="bootstrap/css/header.css">

  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>
  <!-- Funcionalidad de la página -->
  <script type="text/javascript" src="bootstrap/js/funcionalidad.js"></script>
</head>

<body>
  <?php
    if(!include 'database.php') {
      header('Location: paginaerror.php');
    }

    session_start();
    if(isset($_SESSION['nombre'])) {
      $usuario = $_SESSION['nombre'];
    }
    else $usuario = "visitante";
  ?>
  <div class="container">

    <!-- CABECERA -->
    <?php
      include 'menu.php';
    ?>

    <!-- LINKS -->
    <div class="row links">
      <div class="col-lg-12">
        <a href="main.php" >Inicio</a> / <a href="contacto.php" >Contacto</a> 
      </div>
    </div>

    <!-- TÍTULO -->
    <div class="row">
      <div class="col-lg-12">
        <h1> Contacta </h1>
      </div>
    </div>

    <!-- LEAD -->
    <div class="row">
      <div class="col-lg-12">
        <p class="lead"> ¡Hola! ¿Hay algo que quieras comentarnos? Este es tu sitio. Siéntete libre de comentarnos lo que desees. ¡Estaremos encantados de escucharte! </p>
      </div>
    </div>

    <!-- FORMULARIO -->
    <div class="row">
      <div class="col-lg-5  col-lg-offset-3">
        <form action="mailto:gtaw@gmail.com" method="post" enctype="text/plain">
          <p> Nombre: <input type="text" name="nombre" class="form-control input-lg" placeholder="Nombre">
              Dirección de email de contacto: <input type="text" name="correo" id="correo" class="form-control input-lg" placeholder="correo" 
              onkeyup="javascript:validateMail('correo')">
              <img class="check" src="img/correct.png" id="correoCorrecto" alt="correcto">
              <img class="check" src="img/incorrect.png" id="correoIncorrecto" alt="incorrecto">
          </p>
        </form>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-5 col-lg-offset-3">
        <p> Motivo de la consulta: <br>
          <input type="radio" name="consulta" value="evaluacion" checked> Evaluación <br>
          <input type="radio" name="consulta" value="sugerencias"> Sugerencias <br>
          <input type="radio" name="consulta" value="critica"> Críticas <br>
        </p>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-5 col-lg-offset-3">
        <p> Escribe lo que quieras decirnos: </p>
        <textarea name="consulta"></textarea>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-5 col-lg-offset-3">
        <input type="submit" value="Enviar formulario">
      </div>
    </div>

    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?>

  </div> 
</body>
</html>