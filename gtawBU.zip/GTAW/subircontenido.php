<?php

	require 'dbconnect.php';
	require 'database.php';
	session_start();
	$usuario = $_SESSION['nombre'];

	$juego = $_GET["juego"];
	$titulo = htmlspecialchars(trim(strip_tags($_POST['titulo'])));
	$texto = htmlspecialchars(trim(strip_tags($_POST['texto'])));
	$tipo = htmlspecialchars(trim(strip_tags($_POST['articulo'])));

	if($tipo == 'analisis') {
		(int) $nota = $_POST["nota"];
		$insert = insertAnalisis($juego, $usuario, $texto, $titulo, $nota);
		if(!$insert) {
			echo "mal";
		}
		header("Location: juego.php?juego=$juego");
	}
	else {
		$insert = insertOpinion($juego, $usuario, $texto, $titulo);
		if(!$insert) {
			echo "mal";
		}
		header("Location: juego.php?juego=$juego");
	}


?>