<?php
	$db= mysqli_connect('localhost','aw','admin');
	if($db){
		//echo 'vale';
		return $db;
	}
	else {
		//echo'Fallo en la conexión.';
	}
?>