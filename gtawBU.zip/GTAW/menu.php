<?php

  if(isset($_SESSION['nombre'])) {
  	$usuario = $_SESSION['nombre'];
    include 'menuUsuario.php';
  }
  else {
    include 'menuVisitante.php';
  }
?>