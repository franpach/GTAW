<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>GTAW</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- CSS -->
  <link rel="stylesheet" href="bootstrap/css/header.css"> <!-- Cabecera, footer, links y título -->
  <link href="bootstrap/css/portadas.css" rel="stylesheet"> <!--- Imágenes de portada -->
  <link rel="stylesheet" href="bootstrap/css/navalternate.css">  <!-- Listas de colores alternos azules -->

  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>
  <!-- Funcionalidad de la página -->
  <script src="bootstrap/js/funcionalidad.js"></script>
</head>
<body>
  <?php
    if(!include 'database.php') {
      header('Location: paginaerror.php');
    }

    session_start();
    if(isset($_SESSION['nombre'])) {
      $usuario = $_SESSION['nombre'];
    }
    else $usuario = "visitante";

    $lanzamientos = ultimosDiezLanz();
    if(mysqli_num_rows($lanzamientos)==0) {
      $noLanz = true;
    }    
    else $noLanz = false;
  ?>

  <div class="container">

    <!-- CABECERA -->
    <?php
      include 'menu.php';
    ?>

    <!-- PORTADA -->
    <div class="row">
      <div class="col-lg-4">
        <h2>Opiniones</h2>
        <p class="portada" id="portada-op">Lee las últimas opiniones compartidas por los usuarios. Comenta, vota tus preferidas
        y opina tú también. </p>
        <p><a class="btn btn-primary" href="ultimasopiniones.php" role="button">Últimas opiniones »</a></p>
      </div>
      <div class="col-lg-4">
        <h2>Análisis</h2>
        <p class="portada" id="portada-an">Si no te decides por comprar este u otro juego, aquí puedes hacerte una idea de cuál te conviene más. Comparte
        también tus propios análisis para que otros usuarios puedan decidirse también. </p>
        <p><a class="btn btn-primary" href="ultimosanalisis.php" role="button">Últimos ánálisis »</a></p>
     </div>
      <div class="col-lg-4">
        <h2>Lanzamientos</h2>
          <?php
            if($noLanz) {
              echo '<p>Vaya, parece que en nuestra base de datos no tenemos lanzamientos registrados. ¿Conoces alguno? Cuéntanoslo <a href="contacto.html">aquí</a>.';
            }
            else {
              echo '<ul class="nav nav-alternate">';
              while($lan = mysqli_fetch_row($lanzamientos)) {
                echo '<li><a href="lanzamiento.php?lanzamiento=' . $lan[0] . '">' . $lan[0] . '</a></li>';
              }
              echo '</ul>
                    <p><a class="btn btn-primary" href="lanzamientos.php" role="button">Más lanzamientos »</a></p>';
            }
          ?>  
      </div>
    </div>    

    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?>

  </div>
</body>
</html>