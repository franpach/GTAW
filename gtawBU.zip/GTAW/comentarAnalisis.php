<?php
	require 'dbconnect.php';
	require 'database.php';
	session_start();
	$usuario = $_SESSION['nombre'];

	$idanalisis = $_GET["idanalisis"];
	$comentario = htmlspecialchars(trim(strip_tags($_POST['coment-text'])));

	$insert = insertComAn($usuario, $idanalisis, $comentario);

	if(!$insert) {
		echo "mal";
	}
	header("Location: analisis.php?idanalisis=$idanalisis");
?>