<!DOCTYPE html>
<html lang="es"><head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="http://getbootstrap.com/favicon.ico">

    <title>Sube tu contenido</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="bootstrap/css/formularios.css" rel="stylesheet"> <!-- Display de formularios -->
    <link rel="stylesheet" href="bootstrap/css/header.css"> <!-- Cabecera, footer, links y título -->

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="js/bootstrap.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script type="text/javascript" src="bootstrap/js/funcionalidad.js"></script>
  </head>

<body>

  <div class="container">

    <!-- CABECERA -->
    <?php
      include 'menu.php';
    ?>      

    <!-- LINKS -->
    <div class="row links">
      <div class="col-lg-12">
         <a href="main.html" >Inicio</a> / <a href="foro.html" >Foro</a> / <a href="creaTema.php">Crear tema</a> 
      </div>
    </div>

    <!-- FORO -->
      <div class="row">
        <div class="col-lg-12">
          <h1 class="titulo"> Crear tema</h1>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12">
          <p class="lead"> Crea un tema para discutir con otros usuarios sobre lo que quieras. Recuerda que tienes que seguir las normas del sitios, que puedes encontrar <a href="normas.php">aquí</a> para que no nos obligues a borrar aquello que no consideremos
          adecuado para nuestro sitio.
          </p>
        </div>
      </div>
      <form method="post" action="escribirTema.php">
      <div class="row">
        <div class="col-lg-5  col-lg-offset-3">
            <p> Título: <input type="text" name="titulo" class="form-control input-lg" placeholder="Título"></p>
         
        </div>
      </div>
      <div class="row">
        <div class="col-lg-5 col-lg-offset-3">
          <p> Escribe el contenido de tu tema: </p>
          <textarea class="textarea-lg" name="contenido"></textarea>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-5 col-lg-offset-3">
           <input type="submit" value="Publicar tema">
         </div>
      </div>
       </form>
      

    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?>

    </div> <!-- /container -->
  

</body>
</html>