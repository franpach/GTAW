<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>Usuario</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- CSS -->
  <link rel="stylesheet" href="bootstrap/css/header.css"> <!-- Cabecera, footer, links y título -->
  <link href="bootstrap/css/infousuario.css" rel="stylesheet"> <!--- Imágenes de portada -->
  <link rel="stylesheet" href="bootstrap/css/navalternate.css">  <!-- Listas de colores alternos azules -->
  <link rel="stylesheet" href="bootstrap/css/textos-juego.css"> <!-- Display informacion de juego -->

  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>
  <!-- Funcionalidad de la página -->
  <script src="bootstrap/js/funcionalidad.js"></script>
  <!-- Fuente para la biografia -->
  <link href='http://fonts.googleapis.com/css?family=Great+Vibes' rel='stylesheet' type='text/css'>
</head>
<body>
  <?php
    include 'database.php';

    session_start();
    if(isset($_SESSION['nombre'])) {
      $usuario = $_SESSION['nombre'];
    }
    else $usuario = "visitante";

    $perfil = $_GET["usuario"];
    $infouser = sacarUsuario($perfil);
    if($infouser) {
      if (mysqli_num_rows($infouser)!==0) {
        $noUser = false;
        //SACAMOS INFORMACIÓN DEL USUARIO
        $ultAnalisis = ultimoAnalisis($perfil);
        if(mysqli_num_rows($ultAnalisis)==0) $noAnal = true;
        else {
          $noAnal = false;
          $campAnal = mysqli_fetch_row($ultAnalisis);
        } 

        $ultOpinion = ultimaOpinion($perfil);
        if(mysqli_num_rows($ultOpinion)==0) $noOp = true;
        else {
          $noOp = false;
          $campOp = mysqli_fetch_row($ultOpinion);
        } 

        $campos = mysqli_fetch_row($infouser);           
      }
      else {
        // Redireccionamos a página de error si el juego no existe
        header('Location: nocarga.php?error=perfil');  
      }  
    }
    else {
      // Redireccionamos a página de error si el juego no existe
      header('Location: nocarga.php?error=perfil');  
    }
  ?>

  <div class="container">

    <!-- CABECERA -->
    <?php
      include 'menu.php';
    ?>

    <!-- LINKS -->
    <div class="row links">
      <div class="col-lg-12">
        <?php
          echo '<a href="main.php" >Inicio</a> / <a href="usuario.php?usuario=' . $perfil . '" >Página de ' . $perfil . '</a>'; 
        ?>
      </div>
    </div>

    <!-- TÍTULO -->
    <div class="row">
      <div class="col-lg-12">
        <?php
          echo '<h1 class="titulo">' . $campos[0] . '</h1>';
        ?>
      </div>
    </div>

    <!-- INFO USUARIO -->
   
      <?php
        if($perfil != $usuario) {
          echo '<div class="row">
                  <div class="col-lg-2 col-lg-offset-10">
                    <p class="puntuacion-usuario">' . $campos[3] . '</p>
                  </div>
                </div>';
        }
        else {
          echo '<div class="row">
                  <div class="col-lg-2 col-lg-offset-6 boton-art">
                    <p><a class="btn btn-primary collapsed" data-target="#cambiarinfo" data-toggle="collapse" aria-expanded="false">Cambia tu biografía »</a></p>
                  </div>
                  <div class="col-lg-2 boton-art">
                    <p><a class="btn btn-primary collapsed" data-target="#subir" data-toggle="collapse" aria-expanded="false">Cambia tu foto de perfil »</a></p>
                  </div>
                  <div class="col-lg-2">
                    <p class="puntuacion-usuario">' . $campos[3] . '</p>
                  </div>
                </div>
                <div class="row collapse" id="cambiarinfo">
                  <div class="col-lg-12 form-subir">
                    <form action="cambiarbiografia.php" method="post">
                      <textarea class="insertinfo form-control" type="text" name="info" placeholder="Escribe aquí tu nueva biografía"></textarea>
                      <button>Cambiar</button>
                    </form>
                  </div>
                </div>
                <div class="row collapse" id="subir">
                  <div class="col-lg-12 form-subir">
                    <form action="cambiarfoto.php" method="post" enctype="multipart/form-data">
                      <input type="file" name="foto" id="foto" />
                      <input type="submit" name="submit" value="subir imagen">
                    </form>
                  </div>  
                </div>';
        }
      ?>
    
    <div class="row">
      <div class="col-lg-2">
        <?php echo '<img class="foto-perfil" src="' . $campos[1] . '" alt="imagen no disponible">'; ?>
      </div>
      <div class="col-lg-1">
        <div class="row redes">
          <div class="col-lg-12">
            <img class="rrss" src="img/Twitter-48.png" alt="imagen no disponible">
          </div>
        </div>
        <div class="row redes">
          <div class="col-lg-12">
            <img class="rrss" src="img/Facebook-48.png" alt="imagen no disponible">
          </div>
        </div>
        <div class="row redes">
          <div class="col-lg-12">
            <img class="rrss" src="img/Gmail-48.png" alt="imagen no disponible">  
          </div>
        </div>
      </div>
      <div class="col-lg-9">
        <?php echo' <p class="texto-borde-gris texto-scroll texto-grande texto-biografia">' . $campos[2] . '</p>'; ?>
      </div>
    </div>

    <!-- ÚLTIMOS ARTÍCULOS -->
    <div class="row">
      <div class="col-lg-12">
        <h3>Últimos articulos</h3>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-6">
        <h4>Análisis</h4>
        <?php
          $tipoAnalisis = "analisis";
          $positivos = "votosPosAn";
          $negativos = "votosNegAn";
          if($noAnal) {
            if($usuario!=$perfil) {
              print '<p> Este usuario no ha compartido ningún análisis con la comunidad.';  
            }
            else {
              print '<p> No has compartido ningún análisis con la comunidad.';
            }
          }
          else {
            echo '<div class="row">
                    <div class="col-lg-12">
                      <p class="expand"><a href="analisis.php?idanalisis=' . $campAnal[0] . '">' . $campAnal[1] . '</a></p>
                    </div>  
                  </div>';
            echo '<div class="row">
                    <div class="col-lg-12">
                      <p class="texto-borde-gris texto-grande texto-scroll">' . $campAnal[2] . '</p> 
                    </div>
                  </div>';
            echo '<div class="row">
                    <div class="col-lg-2">
                      <p class="nota-analisis">' . $campAnal[6] . '</p> <!-- Nota otorgada al juego por el usuario -->
                    </div>
                    <div class="col-lg-4">
                      <button class="positive" type="button" class="positive" value="sumar" onClick="votoPosArt(&quot;'.$usuario.'&quot;, &quot;'.$campAnal[0].'&quot;, &quot;'.$tipoAnalisis.'&quot;, &quot;'.$positivos.'&quot;, &quot;'.$negativos.'&quot;)">
                      <img src="img/positive.png" class="rate" alt="positivo"></button>
                      <span class="voto" id="votosPosAn">' . $campAnal[3] . '</span>
                      <button class="negative" type="button" class="negative" value="restar" onClick="votoNegArt(&quot;'.$usuario.'&quot;, &quot;'.$campAnal[0].'&quot;, &quot;'.$tipoAnalisis.'&quot;, &quot;'.$positivos.'&quot;, &quot;'.$negativos.'&quot;)">
                      <img src="img/negative.png" class="rate" alt="negativo"> </button>
                      <span class="voto" id="votosNegAn">' . $campAnal[4] . '</span>
                    </div>
                    <div class="col-lg-6">
                      <p> Para el juego <a href="juego.php?juego=' . $campAnal[7] . '">' . $campAnal[7] . '</a></p>
                    </div>
                  </div>';
          }
        ?>
      </div> 
      <div class="col-lg-6">
        <h4>Opiniones</h4>
        <?php 
          $tipoOpinion = "opinion";
          $positivos = "votosPosOp";
          $negativos = "votosNegOp";
          if($noOp) {
            if($usuario!=$perfil) {
              print '<p> Este usuario no ha compartido ninguna opinión con la comunidad.';  
            }
            else {
              print '<p> No has compartido ninguna opinión con la comunidad.';
            }
          }
          else {
            echo '<div class="row">
                    <div class="col-lg-12">
                      <p class="expand"><a href="opinion.php?idopinion=' . $campOp[0] . '">' . $campOp[1] . '</a></p>
                    </div>  
                  </div>';
            echo '<div class="row">
                    <div class="col-lg-12">
                      <p class="texto-borde-gris texto-grande texto-scroll">' . $campOp[2] . '</p> 
                    </div>
                  </div>';
            echo '<div class="row">
                    <div class="col-lg-6">
                      <button class="positive" type="button" class="positive" value="sumar" onClick="votoPosArt(&quot;'.$usuario.'&quot;, &quot;'.$campOp[0].'&quot;, &quot;'.$tipoOpinion.'&quot;, &quot;'.$positivos.'&quot;, &quot;'.$negativos.'&quot;)">
                      <img src="img/positive.png" class="rate" alt="positivo"></button>
                      <span class="voto" id="votosPosOp">' . $campOp[3] . '</span>
                      <button class="negative" type="button" class="negative" value="restar" onClick="votoNegArt(&quot;'.$usuario.'&quot;, &quot;'.$campOp[0].'&quot;, &quot;'.$tipoOpinion.'&quot;, &quot;'.$positivos.'&quot;, &quot;'.$negativos.'&quot;)">
                      <img src="img/negative.png" class="rate" alt="negativo"> </button>
                      <span class="voto" id="votosNegOp">' . $campOp[4] . '</span>
                    </div>
                    <div class="col-lg-6">
                      <p> Para el juego <a href="juego.php?juego=' . $campOp[6] . '">' . $campOp[6] . '</a></p>
                    </div>
                  </div>';
          }  
        ?>
      </div> 
    </div>

    <!--TODOS SUS ARTÍCULOS -->
    <div class="row acciones-usuario">
      <div class="col-lg-3 boton-art">
        <p><a class="btn btn-primary collapsed" data-target="#mejoresArticulos" data-toggle="collapse" aria-expanded="false">Mejores artículos »</a></p>
      </div>
      <div class="col-lg-3">
        <?php echo '<p><a class="btn btn-primary" href="analisisuser.php?usuario=' . $perfil . '">Todos los análisis »</a>'; ?>
      </div>
      <div class="col-lg-3">
        <?php echo '<p><a class="btn btn-primary" href="opinionesuser.php?usuario=' . $perfil . '">Todos las opiniones »</a>'; ?>
      </div>
    </div>

    <div class="row collapse" id="mejoresArticulos">
      <div class="col-lg-6">
        <h4>Análisis</h4>
        <?php
          if($noAnal) {
            if($usuario!=$perfil) {
              print '<p> Este usuario no ha compartido ningún análisis con la comunidad.';  
            }
            else {
              print '<p> No has compartido ningún análisis con la comunidad.';
            }
          }
          else {
            $topAn = topTresAnalisis($perfil);
            echo '<ul class="nav nav-alternate">';
            while($fila = mysqli_fetch_row($topAn)) {
              echo '<li><a href=analisis.php?idanalisis=' . $fila[0] . '>' . $fila[1] . '</a></li>';
            }
            echo '</ul>';
          }
        ?>
      </div>
      <div class="col-lg-6">
        <h4>Opiniones</h4>
        <?php
          if($noOp) {
            if($usuario!=$perfil) {
              print '<p> Este usuario no ha compartido ninguna opinión con la comunidad.';  
            }
            else {
              print '<p> No has compartido ninguna opinión con la comunidad.';
            }
          }
          else {
            $topOp = topTresOpiniones($perfil);
            echo '<ul class="nav nav-alternate">';
            while($fila = mysqli_fetch_row($topOp)) {
              echo '<li><a href=opinion.php?idopinion=' . $fila[0] . '>' . $fila[1] . '</a></li>';
            }
            echo '</ul>';
          }
        ?>
      </div>
    </div>

    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?> 

  </div>
</body>
</html> 