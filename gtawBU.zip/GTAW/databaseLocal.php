<?php
	
	/*Función que lista toda la información de un juego*/
	function sacarjuego($juego) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT * FROM u870692062_aw.videojuegos WHERE videojuegos.id_juego LIKE '$juego'";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que lista los autores de últimos 3 análisis de un juego*/
	function ultimosAnalisis($juego) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_usuario, id_analisis FROM u870692062_aw.analisis WHERE analisis.id_juego LIKE '$juego' ORDER BY analisis.fecha DESC LIMIT 3";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que lista los autores de las últimas 3 opiniones de un juego*/
	function ultimasOpiniones($juego) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_usuario, id_opinion FROM u870692062_aw.opiniones WHERE opiniones.id_juego LIKE '$juego' ORDER BY opiniones.fecha DESC LIMIT 3";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que lista todos los análisis de un juego*/
	function listaAnalisis($juego) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_usuario, texto, titulo, val_pos, val_neg, id_analisis FROM u870692062_aw.analisis WHERE analisis.id_juego LIKE '$juego'";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;	
	}

	/*Función que lista todas las opiniones de un juego*/
	function listaOpiniones($juego) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_usuario, texto, titulo, val_pos, val_neg, id_opinion FROM u870692062_aw.opiniones WHERE opiniones.id_juego LIKE '$juego'";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;	
	}

	/*Función que lista todos los juegos del sitio*/
	function listaJuegos($genero) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		if ($genero == 'cualquiera') {
			$sql = "SELECT id_juego, portada, fecha_venta, plataforma, genero, descripcion, nota FROM u870692062_aw.videojuegos";
			$result=mysqli_query($db, $sql);
		}
		else {
			$sql = "SELECT id_juego, portada, fecha_venta, plataforma, genero, descripcion, nota FROM u870692062_aw.videojuegos WHERE videojuegos.genero LIKE '$genero'";
			$result=mysqli_query($db, $sql);
		}
		mysqli_close($db);
		return $result;
	}
	/*Función que saca solo un numero determinado de juegos */
	function dividirJuegos($genero,$inicio,$tam_pagina) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		if ($genero == 'cualquiera') {
			$sql = "SELECT id_juego, portada, fecha_venta, plataforma, genero, descripcion, nota FROM u870692062_aw.videojuegos LIMIT $inicio, $tam_pagina";
			$result=mysqli_query($db, $sql);
		}
		else {
			$sql = "SELECT id_juego, portada, fecha_venta, plataforma, genero, descripcion, nota FROM u870692062_aw.videojuegos WHERE videojuegos.genero LIKE '$genero' LIMIT $inicio, $tam_pagina";
			$result=mysqli_query($db, $sql);
		}
		mysqli_close($db);
		return $result;
	}

	/*Función que selecciona el análisis mejor valorado para un juego*/
	function mejorAnalisis($juego) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_usuario, titulo, id_analisis FROM u870692062_aw.analisis WHERE analisis.id_juego LIKE '$juego' ORDER BY (analisis.valoracion) DESC LIMIT 1";
		$result=mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que selecciona la opinión mejor valorada para un juego*/
	function mejorOpinion($juego) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_usuario, titulo, id_opinion FROM u870692062_aw.opiniones WHERE opiniones.id_juego LIKE '$juego' ORDER BY (opiniones.valoracion) DESC LIMIT 1";
		$result=mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que saca toda la información de un análisis de un usuario concreto para un juego concreto*/
	function consultaAnalisis($idanalisis) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT * FROM u870692062_aw.analisis WHERE analisis.id_analisis LIKE '$idanalisis'";
		$result=mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que saca toda la información de una opinión de un usuario concreto para un juego concreto*/
	function consultaOpinion($idopinion) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT * FROM u870692062_aw.opiniones WHERE opiniones.id_opinion LIKE '$idopinion'";
		$result=mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que devuelve la foto de un usuario*/
	function fotoUsuario($usuario) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT foto FROM u870692062_aw.usuarios WHERE usuarios.id_usuario LIKE '$usuario'";
		$result=mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que devuelve todos los comentarios de un análisis*/
	function sacarComAnalisis($idanalisis) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT * FROM u870692062_aw.com_an WHERE com_an.id_analisis LIKE '$idanalisis' ORDER BY com_an.fecha";
		$result=mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que saca solo un numero determinado de comentarios */
	function dividirComAnalisis($idanalisis,$inicio,$tam_pagina) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT * FROM u870692062_aw.com_an WHERE com_an.id_analisis LIKE '$idanalisis' ORDER BY com_an.fecha DESC LIMIT $inicio, $tam_pagina";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que devuelve todos los comentarios de una opinión*/
	function sacarComOpinion($idopinion) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT * FROM u870692062_aw.com_op WHERE com_op.id_opinion LIKE '$idopinion' ORDER BY com_op.fecha";
		$result=mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que saca solo un numero determinado de comentarios de una opinión */
	function dividirComOpinion($idopinion,$inicio,$tam_pagina) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT * FROM u870692062_aw.com_op WHERE com_op.id_opinion LIKE '$idopinion' ORDER BY com_op.fecha LIMIT $inicio, $tam_pagina";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}


	/*Función que saca análisis hasta límite*/
	function sacarAnalisis($limite) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_usuario, id_juego, texto, titulo, val_pos, val_neg, id_analisis FROM u870692062_aw.analisis ORDER BY analisis.fecha DESC LIMIT $limite";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que saca las opiniones hasta límite*/
	function sacarOpiniones($limite) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_usuario, id_juego, texto, titulo, val_pos, val_neg, id_opinion FROM u870692062_aw.opiniones ORDER BY opiniones.fecha DESC LIMIT $limite";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que saca los 5 mejores juegos de un género concreto*/
	function sacarTopJuegos($genero) {
		require 'dbconnect.php';
		$sql = "SELECT id_juego FROM u870692062_aw.videojuegos WHERE videojuegos.genero LIKE '$genero' ORDER BY videojuegos.nota DESC LIMIT 5";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que saca el id de usuario, foto y su valoración absoluta (votos pos - votos neg de todos sus aportes)  de los 100 mejores users*/
	function usuariosTop() {
		require 'dbconnect.php';
		$sql = "SELECT id_usuario, foto, valoracion FROM u870692062_aw.usuarios ORDER BY valoracion DESC LIMIT 100";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que saca el mejor artículo de un usuario junto a la valoracion del mismo (val_pos - val_neg)*/
	function mejorArticulo($usuario) {
		require 'dbconnect.php';
		// MEJOR ANÁLISIS
		$mejorAn = "SELECT id_analisis, titulo, valoracion, nota FROM u870692062_aw.analisis WHERE analisis.id_usuario LIKE '$usuario' ORDER BY analisis.valoracion DESC LIMIT 1";
		$analisis = mysqli_query($db, $mejorAn);

		// MEJOR OPINIÓN
		$mejorOp = "SELECT id_opinion, titulo, valoracion FROM u870692062_aw.opiniones WHERE opiniones.id_usuario LIKE '$usuario' ORDER BY opiniones.valoracion DESC LIMIT 1";
		$opinion = mysqli_query($db, $mejorOp);

		// VEMOS CUAL ES MEJOR
		if((mysqli_num_rows($analisis)==1) && (mysqli_num_rows($opinion)==1)) {
			// SI HA APORTADO AMBOS TIPO DE ARTÍCULO
			$filan = mysqli_fetch_row($analisis);
			$a = intval($filan[2]);
			$filop = mysqli_fetch_row($opinion);
			$o = intval($filop[2]);
			if ($a >= $o) {
				$result = mysqli_query($db, $mejorAn); // EN CASO DE IGUALDAD TAMBIÉN SE SACA EL ANÁLISIS
			}
			else $result = mysqli_query($db, $mejorOp);
		}	
		else {
			// SI SOLO HA APORTADO DE UN TIPO, SACAMOS EL MEJOR DE ESE TIPO
			if(mysqli_num_rows($analisis)==0) $result = $opinion;
			else $result = $analisis;
		}
		mysqli_close($db);
		return $result;
	}

	/*Función que devuelve la lista de los próximos 10 lanzamientos*/
	function ultimosDiezLanz() {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_lanzamiento FROM u870692062_aw.lanzamientos ORDER BY lanzamientos.fecha ASC LIMIT 10";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que devuelve la lista de todos los próximos lanzamientos*/
	function sacaLanzamientos() {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_lanzamiento, fecha, plataformas, genero, portada, avance FROM u870692062_aw.lanzamientos ORDER BY lanzamientos.fecha ASC";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que saca solo un numero determinado de lanzamientos */
	function dividirLanzamientos($inicio,$tam_pagina) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_lanzamiento, fecha, plataformas, genero, portada, avance FROM u870692062_aw.lanzamientos ORDER BY lanzamientos.fecha ASC LIMIT $inicio, $tam_pagina";
		
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que devuelve toda la información de un lanzamiento*/
	function sacarLanzamiento($id_lanzamiento) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT * FROM u870692062_aw.lanzamientos WHERE lanzamientos.id_lanzamiento LIKE '$id_lanzamiento'";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que devuelve la información de un usuario*/
	function sacarUsuario($usuario) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_usuario, foto, biografia, valoracion FROM u870692062_aw.usuarios WHERE usuarios.id_usuario LIKE '$usuario'";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que devuelve el último analisis de un usuario*/
	function ultimoAnalisis($usuario) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_analisis, titulo, texto, val_pos, val_neg, valoracion, nota, id_juego FROM u870692062_aw.analisis where analisis.id_usuario LIKE '$usuario' ORDER BY analisis.fecha DESC LIMIT 1";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que devuelve el último analisis de un usuario*/
	function ultimaOpinion($usuario) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_opinion, titulo, texto, val_pos, val_neg, valoracion, id_juego FROM u870692062_aw.opiniones where opiniones.id_usuario LIKE '$usuario' ORDER BY opiniones.fecha DESC LIMIT 1";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que devuelve los tres mejores análisis de un usuario*/
	function topTresAnalisis($usuario) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_analisis, titulo FROM u870692062_aw.analisis where analisis.id_usuario LIKE '$usuario' ORDER BY analisis.valoracion DESC LIMIT 3";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que devuelve las tres mejores opiniones de un usuario*/
	function topTresOpiniones($usuario) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_opinion, titulo FROM u870692062_aw.opiniones where opiniones.id_usuario LIKE '$usuario' ORDER BY opiniones.valoracion DESC LIMIT 3";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que devuelve el id de un juego dado un análisis sobre él*/
	function sacarIdJuegoPorAnalisis($idanalisis) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_juego FROM u870692062_aw.analisis WHERE id_analisis LIKE '$idanalisis'";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que devuelve todos los análisis de un usuario*/
	function analisisUsuario($usuario) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_juego, texto, titulo, val_pos, val_neg, id_analisis FROM u870692062_aw.analisis WHERE analisis.id_usuario LIKE '$usuario' ORDER BY analisis.fecha DESC";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que saca solo un numero determinado de analisis de un usuario */
	function dividirAnalisisUsuario($usuario,$inicio,$tam_pagina) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_juego, texto, titulo, val_pos, val_neg, id_analisis FROM u870692062_aw.analisis WHERE analisis.id_usuario LIKE '$usuario' ORDER BY analisis.fecha DESC LIMIT $inicio, $tam_pagina";
		$result = mysqli_query($db, $sql);
		return $result;
	}

	/*Función que devuelve todos las opiniones de un usuario*/
	function opinionesUsuario($usuario) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_juego, texto, titulo, val_pos, val_neg, id_opinion FROM u870692062_aw.opiniones WHERE opiniones.id_usuario LIKE '$usuario' ORDER BY opiniones.fecha DESC";
		$result = mysqli_query($db, $sql);
		return $result;
	}

	/*Función que saca solo un numero determinado de opiniones de un usuario */
	function dividirOpinionesUsuario($usuario,$inicio,$tam_pagina) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT id_juego, texto, titulo, val_pos, val_neg, id_opinion FROM u870692062_aw.opiniones WHERE opiniones.id_usuario LIKE '$usuario' ORDER BY opiniones.fecha DESC LIMIT $inicio, $tam_pagina";
		$result = mysqli_query($db, $sql);
		return $result;
	}

	/*Función que devuelve un usuario de la base de datos al hacer login*/
	function loginUsuario($usuario, $contr) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$Key = "gtaw2549";
		$encriptado = base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($Key), $contr, MCRYPT_MODE_CBC, md5(md5($Key))));
					
		$sql= "SELECT * FROM u870692062_aw.usuarios WHERE usuarios.id_usuario LIKE '$usuario' AND usuarios.password LIKE '$encriptado'";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;			
	}

	/*Función que devuelve un usuario de la base para comprobar si ya existe*/
	function compruebaUsu($nombre) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
          $sql= "SELECT * FROM u870692062_aw.usuarios WHERE usuarios.id_usuario like '$nombre'";
          $consulta = mysqli_query($db,$sql);
          mysqli_close($db);
          return $consulta;
	}

	/*Función que inserta un nuevo usuario*/
	function regisUsu($nombre, $contr, $corr) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
          
        $Key = "gtaw2549";
        $encriptado = base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($Key), $contr, MCRYPT_MODE_CBC, md5(md5($Key))));

        $sql = "INSERT INTO u870692062_aw.usuarios VALUES ('$nombre', '$encriptado', ' ', '$corr' , ' ', ' ')";
        $result = mysqli_query($db, $sql);
        mysqli_close($db);
        return $result;
	}

	/*Función que inserta un análisis*/
	function insertAnalisis($juego, $usuario, $texto, $titulo, $nota) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$val_pos = 0;
		$val_neg = 0;
		$valoracion = 0;
		$sql = "INSERT INTO u870692062_aw.analisis VALUES(DEFAULT, '$juego','$usuario', CURRENT_TIMESTAMP, '$texto', '$titulo', '$nota', '$val_pos', '$val_neg', 'valoracion')";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
        return $result;
	}

	/*Función que inserta una opinión*/
	function insertOpinion($juego, $usuario, $texto, $titulo) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$val_pos = 0;
		$val_neg = 0;
		$valoracion = 0;
		$sql = "INSERT INTO u870692062_aw.opiniones VALUES(DEFAULT, '$juego','$usuario', CURRENT_TIMESTAMP, '$titulo', '$texto', '$val_pos', '$val_neg', 'valoracion')";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
        return $result;
	}

	/*Función que inserta un comentario en un análisis*/
	function insertComAn($usuario, $idanalisis, $comentario) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$val_pos = 0;
		$val_neg = 0;
		$valoracion = 0;
		$sql = "INSERT INTO u870692062_aw.com_an VALUES (DEFAULT, '$usuario', '$idanalisis', '$comentario' ,'$val_pos', '$val_neg', '$valoracion', CURRENT_TIMESTAMP)";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
        return $result;
	}

	/*Función que inserta un comentario en una opinión*/
	function insertComOp($usuario, $idopinion, $comentario) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$val_pos = 0;
		$val_neg = 0;
		$valoracion = 0;
		$sql = "INSERT INTO u870692062_aw.com_op VALUES (DEFAULT, '$usuario', '$idopinion', '$comentario' ,'$val_pos', '$val_neg', '$valoracion', CURRENT_TIMESTAMP)";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
        return $result;
	}

	/*Función que devuelve los votos positivos, negativos y la valoración de un artículo*/
	function votosArt($idarticulo, $tipo) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		if($tipo == "analisis") {
			$sql = "SELECT val_pos, val_neg, valoracion FROM u870692062_aw.analisis WHERE analisis.id_analisis LIKE '$idarticulo'";
			$result = mysqli_query($db, $sql);
		}
		else {
			$sql = "SELECT val_pos, val_neg, valoracion FROM u870692062_aw.opiniones WHERE opiniones.id_opinion LIKE '$idarticulo'";
			$result = mysqli_query($db, $sql);
		}
		mysqli_close($db);
		return $result;
	}

	/* Función que actualiza los votos positivos de un artículo*/
	function actualizaVotosPosArt($idarticulo, $tipo, $votos) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		// Salvamos la fecha anterior para que no se modifique al realizar un update
		if($tipo == "analisis") {
			$sql = "SELECT fecha FROM u870692062_aw.analisis WHERE analisis.id_analisis LIKE '$idarticulo'";
			$result = mysqli_query($db, $sql);
			$datos = mysqli_fetch_row($result);
			$fecha = $datos[0];
			$sql = "UPDATE u870692062_aw.analisis SET analisis.val_pos = '$votos', analisis.fecha = '$fecha' WHERE analisis.id_analisis LIKE '$idarticulo'";
			$result = mysqli_query($db, $sql);
		}
		else {
			$sql = "SELECT fecha FROM u870692062_aw.opiniones WHERE opiniones.id_opinion LIKE '$idarticulo'";
			$result = mysqli_query($db, $sql);
			$datos = mysqli_fetch_row($result);
			$fecha = $datos[0];
			$sql = "UPDATE u870692062_aw.opiniones SET opiniones.val_pos = '$votos', opiniones.fecha = '$fecha' WHERE opiniones.id_opinion LIKE '$idarticulo'";
			$result = mysqli_query($db, $sql);
		}
		mysqli_close($db);
		return $result;
	}

	function actualizaVotosNegArt($idarticulo, $tipo, $votos) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		// Salvamos la fecha anterior para que no se modifique al realizar un update
		if($tipo == "analisis") {
			$sql = "SELECT fecha FROM u870692062_aw.analisis WHERE analisis.id_analisis LIKE '$idarticulo'";
			$result = mysqli_query($db, $sql);
			$datos = mysqli_fetch_row($result);
			$fecha = $datos[0];
			$sql = "UPDATE u870692062_aw.analisis SET analisis.val_neg = '$votos', analisis.fecha = '$fecha' WHERE analisis.id_analisis LIKE '$idarticulo'";
			$result = mysqli_query($db, $sql);
		}
		else {
			$sql = "SELECT fecha FROM u870692062_aw.opiniones WHERE opiniones.id_opinion LIKE '$idarticulo'";
			$result = mysqli_query($db, $sql);
			$datos = mysqli_fetch_row($result);
			$fecha = $datos[0];
			$sql = "UPDATE u870692062_aw.opiniones SET opiniones.val_neg = '$votos', opiniones.fecha = '$fecha' WHERE opiniones.id_opinion LIKE '$idarticulo'";
			$result = mysqli_query($db, $sql);
		}
		mysqli_close($db);
		return $result;
	}

	/*Función que inserta el voto positivo de un usuario con un artículo*/
	function insertMeGustaArt($idarticulo, $usuario, $tipo, $likedislike) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		if($tipo == "analisis") {
			$sql = "INSERT INTO u870692062_aw.megusta_an VALUES ('$usuario', '$idarticulo', '$likedislike')";
			$result = mysqli_query($db, $sql);
		}
		else {
			$sql = "INSERT INTO u870692062_aw.megusta_op VALUES ('$usuario', '$idarticulo', '$likedislike')";
			$result = mysqli_query($db, $sql);
		}
		mysqli_close($db);
		return $result;
	}

	/*Función que comprueba si un usuario ha dado like a un artículo en concreto*/
	function compruebaMeGustaArt($idarticulo, $usuario, $tipo) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		if($tipo == "analisis") {
			$sql = "SELECT * FROM u870692062_aw.megusta_an WHERE megusta_an.id_usuario LIKE '$usuario' AND megusta_an.id_analisis LIKE '$idarticulo'";
			$result = mysqli_query($db, $sql);
		}
		else {
			$sql = "SELECT * FROM u870692062_aw.megusta_op WHERE megusta_op.id_usuario LIKE '$usuario' AND megusta_op.id_opinion LIKE '$idarticulo'";
			$result = mysqli_query($db, $sql);
		}
		mysqli_close($db);
		return $result;
	}

	/*Función que actualiza la valoración del usuario*/
	function actualizaValUser($usuario, $valoracion) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "UPDATE u870692062_aw.usuarios SET usuarios.valoracion = '$valoracion' WHERE usuarios.id_usuario LIKE '$usuario'";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
        return $result;
	}

	/*Función que actualiza la valoración de un usuario de un artículo*/
	function actualizaValArticulo($idarticulo, $valoracion, $tipo) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		// Salvamos la fecha anterior para que no se modifique al realizar un update
		if($tipo == "analisis") {
			$sql = "SELECT fecha FROM u870692062_aw.analisis WHERE analisis.id_analisis LIKE '$idarticulo'";
			$result = mysqli_query($db, $sql);
			$datos = mysqli_fetch_row($result);
			$fecha = $datos[0];
			$sql = "UPDATE u870692062_aw.analisis SET analisis.valoracion = '$valoracion', analisis.fecha = '$fecha' WHERE analisis.id_analisis LIKE '$idarticulo'";
			$result = mysqli_query($db, $sql);
		}
		else {
			$sql = "SELECT fecha FROM u870692062_aw.opiniones WHERE opiniones.id_opinion LIKE '$idarticulo'";
			$result = mysqli_query($db, $sql);
			$datos = mysqli_fetch_row($result);
			$fecha = $datos[0];
			$sql = "UPDATE u870692062_aw.opiniones SET opiniones.valoracion = '$valoracion', opiniones.fecha = '$fecha' WHERE opiniones.id_opinion LIKE '$idarticulo'";
			$result = mysqli_query($db, $sql);
		}
		mysqli_close($db);
		return $result;
	}

	/*Función que elimina el me gusta de un usuario*/
	function eliminarMegustaArt($idarticulo, $usuario, $tipo) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		if($tipo == "analisis") {
			$sql = "DELETE FROM u870692062_aw.megusta_an WHERE megusta_an.id_analisis LIKE '$idarticulo' AND megusta_an.id_usuario LIKE '$usuario'";
			$result = mysqli_query($db, $sql);
		}
		else {
			$sql = "DELETE FROM u870692062_aw.megusta_op WHERE megusta_op.id_opinion LIKE '$idarticulo' AND megusta_op.id_usuario LIKE '$usuario'";
			$result = mysqli_query($db, $sql);
		}
		mysqli_close($db);
		return $result;
	}

	/*Función que actualiza el me gusta de un usuario, sabiendo de antemano que ha dado al voto contrario al que estaba marcado*/
	function actMegustaArt($idarticulo, $usuario, $tipo, $likedislike) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		if($tipo == "analisis") {
			$sql = "UPDATE u870692062_aw.megusta_an SET megusta_an.likedislike = '$likedislike' WHERE megusta_an.id_analisis LIKE '$idarticulo' AND megusta_an.id_usuario LIKE '$usuario'";
			$result = mysqli_query($db, $sql);
		}
		else {
			$sql = "UPDATE u870692062_aw.megusta_op SET megusta_op.likedislike = '$likedislike' WHERE megusta_op.id_opinion LIKE '$idarticulo' AND megusta_op.id_usuario LIKE '$usuario'";
			$result = mysqli_query($db, $sql);
		}
		mysqli_close($db);
		return $result;	
	}

	/*Función que cambia la biografía de un usuario*/
	function cambiarBiografia($usuario, $biografia) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "UPDATE u870692062_aw.usuarios SET usuarios.biografia = '$biografia' WHERE usuarios.id_usuario LIKE '$usuario'";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que cambia la foto de usuario*/
	function cambiarFoto($usuario, $foto) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "UPDATE u870692062_aw.usuarios SET usuarios.foto = '$foto' WHERE usuarios.id_usuario LIKE '$usuario'";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que devuelve los votos positivos, negativos, la valoración y el usuario de un comentario*/
	function votosCom($idcomentario, $tipo) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		if($tipo == "analisis") {
			$sql = "SELECT val_pos, val_neg, valoracion, id_usuario FROM u870692062_aw.com_an WHERE com_an.id_comentario LIKE '$idcomentario'";
			$result = mysqli_query($db, $sql);
		}
		else {
			$sql = "SELECT val_pos, val_neg, valoracion, id_usuario FROM u870692062_aw.com_op WHERE com_op.id_comentario LIKE '$idcomentario'";
			$result = mysqli_query($db, $sql);
		}
		mysqli_close($db);
		return $result;
	}

	/* Función que actualiza los votos positivos de un artículo*/
	function actualizaVotosPosCom($idcomentario, $tipo, $votos) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		// Salvamos la fecha anterior para que no se modifique al realizar un update
		if($tipo == "analisis") {
			$sql = "SELECT fecha FROM u870692062_aw.com_an WHERE com_an.id_comentario LIKE '$idcomentario'";
			$result = mysqli_query($db, $sql);
			$datos = mysqli_fetch_row($result);
			$fecha = $datos[0];
			$sql = "UPDATE u870692062_aw.com_an SET com_an.val_pos = '$votos', com_an.fecha = '$fecha' WHERE com_an.id_comentario LIKE '$idcomentario'";
			$result = mysqli_query($db, $sql);
		}
		else {
			$sql = "SELECT fecha FROM u870692062_aw.com_op WHERE com_op.id_comentario LIKE '$idcomentario'";
			$result = mysqli_query($db, $sql);
			$datos = mysqli_fetch_row($result);
			$fecha = $datos[0];
			$sql = "UPDATE u870692062_aw.com_op SET com_op.val_pos = '$votos', com_op.fecha = '$fecha' WHERE com_op.id_comentario LIKE '$idcomentario'";
			$result = mysqli_query($db, $sql);
		}
		mysqli_close($db);
		return $result;
	}

	function actualizaVotosNegCom($idcomentario, $tipo, $votos) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		// Salvamos la fecha anterior para que no se modifique al realizar un update
		if($tipo == "analisis") {
			$sql = "SELECT fecha FROM u870692062_aw.com_an WHERE com_an.id_comentario LIKE '$idcomentario'";
			$result = mysqli_query($db, $sql);
			$datos = mysqli_fetch_row($result);
			$fecha = $datos[0];
			$sql = "UPDATE u870692062_aw.com_an SET com_an.val_neg = '$votos', com_an.fecha = '$fecha' WHERE com_an.id_comentario LIKE '$idcomentario'";
			$result = mysqli_query($db, $sql);
		}
		else {
			$sql = "SELECT fecha FROM u870692062_aw.com_op WHERE com_op.id_comentario LIKE '$idcomentario'";
			$result = mysqli_query($db, $sql);
			$datos = mysqli_fetch_row($result);
			$fecha = $datos[0];
			$sql = "UPDATE u870692062_aw.com_op SET com_op.val_neg = '$votos', com_op.fecha = '$fecha' WHERE com_op.id_comentario LIKE '$idcomentario'";
			$result = mysqli_query($db, $sql);
		}
		mysqli_close($db);
		return $result;
	}

	/*Función que inserta el voto positivo de un usuario con un artículo*/
	function insertMeGustaCom($idcomentario, $usuario, $tipo, $likedislike) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		if($tipo == "analisis") {
			$sql = "INSERT INTO u870692062_aw.megusta_com_an VALUES ('$idcomentario', '$usuario', '$likedislike')";
			$result = mysqli_query($db, $sql);
		}
		else {
			$sql = "INSERT INTO u870692062_aw.megusta_com_op VALUES ('$idcomentario', '$usuario', '$likedislike')";
			$result = mysqli_query($db, $sql);
		}
		mysqli_close($db);
		return $result;
	}

	/*Función que comprueba si un usuario ha dado like a un artículo en concreto*/
	function compruebaMeGustaCom($idcomentario, $usuario, $tipo) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		if($tipo == "analisis") {
			$sql = "SELECT * FROM u870692062_aw.megusta_com_an WHERE megusta_com_an.id_usuario LIKE '$usuario' AND megusta_com_an.id_comentario LIKE '$idcomentario'";
			$result = mysqli_query($db, $sql);
		}
		else {
			$sql = "SELECT * FROM u870692062_aw.megusta_com_op WHERE megusta_com_op.id_usuario LIKE '$usuario' AND megusta_com_op.id_comentario LIKE '$idcomentario'";
			$result = mysqli_query($db, $sql);
		}
		mysqli_close($db);
		return $result;
	}

	/*Función que actualiza la valoración de un usuario de un artículo*/
	function actualizaValComentario($idcomentario, $valoracion, $tipo) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		// Salvamos la fecha anterior para que no se modifique al realizar un update
		if($tipo == "analisis") {
			$sql = "SELECT fecha FROM u870692062_aw.com_an WHERE com_an.id_comentario LIKE '$idcomentario'";
			$result = mysqli_query($db, $sql);
			$datos = mysqli_fetch_row($result);
			$fecha = $datos[0];
			$sql = "UPDATE u870692062_aw.com_an SET com_an.valoracion = '$valoracion', com_an.fecha = '$fecha' WHERE com_an.id_comentario LIKE '$idcomentario'";
			$result = mysqli_query($db, $sql);
		}
		else {
			$sql = "SELECT fecha FROM u870692062_aw.com_op WHERE com_op.id_comentario LIKE '$idcomentario'";
			$result = mysqli_query($db, $sql);
			$datos = mysqli_fetch_row($result);
			$fecha = $datos[0];
			$sql = "UPDATE u870692062_aw.com_op SET com_op.valoracion = '$valoracion', com_op.fecha = '$fecha' WHERE com_op.id_comentario LIKE '$idcomentario'";
			$result = mysqli_query($db, $sql);
		}
		mysqli_close($db);
		return $result;
	}

	/*Función que elimina el me gusta de un usuario*/
	function eliminarMegustaCom($idcomentario, $usuario, $tipo) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		if($tipo == "analisis") {
			$sql = "DELETE FROM u870692062_aw.megusta_com_an WHERE megusta_com_an.id_comentario LIKE '$idcomentario' AND megusta_com_an.id_usuario LIKE '$usuario'";
			$result = mysqli_query($db, $sql);
		}
		else {
			$sql = "DELETE FROM u870692062_aw.megusta_com_op WHERE megusta_com_op.id_comentario LIKE '$idcomentario' AND megusta_com_op.id_usuario LIKE '$usuario'";
			$result = mysqli_query($db, $sql);
		}
		mysqli_close($db);
		return $result;
	}

	/*Función que actualiza el me gusta de un usuario, sabiendo de antemano que ha dado al voto contrario al que estaba marcado*/
	function actMegustaCom($idcomentario, $usuario, $tipo, $likedislike) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		if($tipo == "analisis") {
			$sql = "UPDATE u870692062_aw.megusta_com_an SET megusta_com_an.likedislike = '$likedislike' WHERE megusta_com_an.id_comentario LIKE '$idcomentario' AND megusta_com_an.id_usuario LIKE '$usuario'";
			$result = mysqli_query($db, $sql);
		}
		else {
			$sql = "UPDATE u870692062_aw.megusta_com_op SET megusta_com_op.likedislike = '$likedislike' WHERE megusta_com_op.id_comentario LIKE '$idcomentario' AND megusta_com_op.id_usuario LIKE '$usuario'";
			$result = mysqli_query($db, $sql);
		}
		mysqli_close($db);
		return $result;	
	}


	/*Función que saca los temas del foro */
	function sacarTemas() {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT * FROM u870692062_aw.tema_foro ORDER BY tema_foro.fecha DESC ";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}
	/*Función que saca solo un numero determinado de temas */
	function dividirTemas($inicio,$tam_pagina) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT * FROM u870692062_aw.tema_foro ORDER BY tema_foro.fecha DESC LIMIT $inicio, $tam_pagina";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que saca un tema determinado */
	function devuelveTema($tema) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT * FROM u870692062_aw.tema_foro WHERE tema_foro.id_tema like '$tema'";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que saca los mensajes de un tema del foro */
	function sacarMensajesTema($tema) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT * FROM u870692062_aw.mensajes_foro WHERE mensajes_foro.id_tema like '$tema' ORDER BY mensajes_foro.fecha ASC ";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}

	/*Función que saca solo un numero determinado de mensajes */
	function dividirMensajesForo($tema,$inicio,$tam_pagina) {
		if(!require 'dbconnect.php') {
			header('Location: paginaerror.php');
		}
		$sql = "SELECT * FROM u870692062_aw.mensajes_foro WHERE mensajes_foro.id_tema like '$tema' ORDER BY mensajes_foro.fecha ASC LIMIT $inicio, $tam_pagina";
		$result = mysqli_query($db, $sql);
		mysqli_close($db);
		return $result;
	}
?>