<?php
	require 'dbconnect.php';
	session_start();
	$nombre = $_SESSION['nombre']; 

	$biografia = htmlspecialchars(trim(strip_tags($_POST['Biografia'])));
	$foto = htmlspecialchars(trim(strip_tags($_POST['foto'])));

	$target_dir = $_FILES["foto"]["tmp_name"]; // guardamos el nombre temporal
	$name = $_FILES["foto"]["name"]; // guardamos el nombre del archivo subido

	if(isset($_POST["submit"])) {
		$newlocation = "img/users/".$name; // creamos el nombre de archivo que se quiere almacenar
	    move_uploaded_file($target_dir, $newlocation); // almacenamos en la carpeta la nueva imagen
	}

	$sql = "UPDATE aw.usuarios SET usuarios.biografia = '$biografia', usuarios.foto = '$newlocation' WHERE usuarios.id_usuario like '$nombre' ";

	$result= mysqli_query($db,$sql);
	if($result) {
		header('Location: main.php');
		echo $name;
	}
		


?>