<?php
  session_start();
  if(!isset($_SESSION['nombre'])) {
    echo "No hay ninguna sesión iniciada";
  }
  else { 
    session_destroy();
    header('Location: main.php');
           
  }
?>