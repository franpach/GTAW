<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>Opiniones</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- CSS -->
  <link rel="stylesheet" href="bootstrap/css/header.css"> <!-- Cabecera, footer, links y título -->
  <link rel="stylesheet" href="bootstrap/css/textos-juego.css"> <!-- Display informacion de juego -->
  <link href="bootstrap/css/infoarticulo.css" rel="stylesheet"> <!--- Display artículo -->
  <link rel="stylesheet" href="bootstrap/css/listas.css">  <!-- Display usuario -->
  <link rel="stylesheet" href="bootstrap/css/votos.css">  <!-- Display de botones para votar artículos y comentarios -->

  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>
  <!-- Funcionalidad de la página -->
  <script src="bootstrap/js/funcionalidad.js"></script>
</head>
<body>
	<?php
		if(!include 'database.php') {
      		header('Location: paginaerror.php');
    	}

	    session_start();
	    if(isset($_SESSION['nombre'])) {
	      $usuario = $_SESSION['nombre'];
	    }
	    else $usuario = "visitante";

      	$juego = $_GET["juego"];
      	$lista = listaOpiniones($juego);
      	if($lista) {
      		if (mysqli_num_rows($lista)==0) $noOp = true;
      		else $noOp = false;
      	}
      	else $noOp = true;
	?>
	<div class="container">
	
		<!-- CABECERA -->
	    <?php
	      include 'menu.php';
	    ?>	

	    <!-- LINKS -->
	    <div class="row links">
	      <div class="col-lg-12">
	      	<?php
	        	echo '<a href="main.php" >Inicio</a> / <a href="juegos.php">Juegos</a> / <a href="juego.php?juego=' . $juego . '" >' . $juego . '</a> / <a href="listopiniones.php?juego=' . $juego . '">Opiniones de ' . $juego . '</a>';
	        ?>
	      </div>
	    </div>

	    <!-- TITULO -->
	    <div class="row">
	    	<div class="col-lg-12">
	        	<?php
	        		echo '<h1 class="titulo">Opiniones de <a href="juego.php?juego=' . $juego . '">' . $juego . '</a></h1>';
	        	?>
	        </div>
	    </div>

	    <!-- LISTA -->
	    <?php
	    	if($noOp) {
	    		print '<div class="row">
	    					<div class="col-lg-12 nolista">
	    						<p> Vaya, parece que nadie ha escrito ninguna opinión para este juego. </p>
	    					</div>
	    				</div>';
	    	}
	    	else {
	    		$tipo = "opinion";
	    		$i = 0; // se indexará cada opinión para poder referenciar sus elementos de forma unívoca
	    		while($opinion = mysqli_fetch_row($lista)) {
	    			$positivos = "positivo".$i;
	    			$negativos = "negativo".$i;
	    			$i = $i + 1;
	    			print ' <div class="row row-art-titulo">
	          					<div class="col-lg-10">
						            <h3 class="expand"> Opinión de <a href="usuario.php?usuario=' . $opinion[0] . '">' . $opinion[0] . '</a>: <a href="opinion.php?idopinion=' . $opinion[5] . '">' . $opinion[2] . '</a> </h3>
						        </div>
						    </div>
					        <div class="row row-art-contenido">
					          <div class="col-lg-10">
					            <p class="texto-borde-gris texto-mediano texto-scroll">' . $opinion[1] . '</p>
					          </div>
					          <div class="col-lg-2 puntuacion-art-lista">
					            <div class="row btn-rate">
					              <div class="col-lg-12">
					                <span id="' . $positivos . '" class="voto">' . $opinion[3] . '</span>
					                <button class="positive" type="button" value="sumar" onClick="votoPosArt(&quot;'.$usuario.'&quot;, &quot;'.$opinion[5].'&quot;, &quot;'.$tipo.'&quot;, &quot;'.$positivos.'&quot;, &quot;'.$negativos.'&quot;)"><img class="rateArt" src="img/positive.png" alt="positivo"></button>
					              </div>
					            </div>
					            <div class="row btn-rate">
					              <div class="col-lg-12">
					                <span id="' . $negativos . '" class="voto">' . $opinion[4] . '</span> 
					                <button class="negative" type="button" value="restar" onClick="votoNegArt(&quot;'.$usuario.'&quot;, &quot;'.$opinion[5].'&quot;, &quot;'.$tipo.'&quot;, &quot;'.$positivos.'&quot;, &quot;'.$negativos.'&quot;)"><img class="rateArt" src="img/negative.png" alt="negativo"></button>
					              </div>
					            </div>
					          </div>
					        </div>';
	    		}
	    	}
	    	
	    ?>

	   	<!-- FOOTER -->
	    <?php
	      $ok = include 'footer.php';
	      if(!$ok) {
	        echo '<footer> GTAW </footer>';
	      }
	    ?>

  </div>
</body>
</html>