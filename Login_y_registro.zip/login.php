
<!DOCTYPE html>
<html lang="es"><head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="http://getbootstrap.com/favicon.ico">

    <title>GTAW - Registro</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="bootstrap/css/registro.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>
<body>
<div class="container">
  <div class="row">
    <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
				<?php
					include 'database.php';
					$corr = htmlspecialchars(trim(strip_tags($_POST['Correo'])));
					//La contraseña en la base de datos tiene que tener longitud 50-60
					$contr = htmlspecialchars(trim(strip_tags($_POST['Contraseña'])));
					$consulta = loginUsuario($corr,$contr);

					if ($consulta) {	
						$fila=mysqli_fetch_assoc($consulta);
						if($fila['correo'] == $corr)
						{
							session_start();
         				 $_SESSION['nombre']=$fila['nombre'];
						header('Location: Main.php');
						}
			
						else
						{
							
						print '<p> El usuario o contraseña que has introducido son incorrectos</p><br>
						<a href="Login.html">Volver a la página de login.</a>';
						}

				
			}
					

			    
				?>
				
        </div>

    </div>
      <!-- Site footer -->
      <footer class="footer">
        <p>© 2016 GTAW, Inc. | Lee <a href="normas.html">aquí</a> nuestras normas</p>
      </footer>
  </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="js/bootstrap.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</body>
</html>
