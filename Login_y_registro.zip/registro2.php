<?php
	session_start();
	require 'dbconnect.php';
	

	$nombre = $_SESSION['nombre']; 

	$biografia = htmlspecialchars(trim(strip_tags($_POST['Biografia'])));

	$foto = htmlspecialchars(trim(strip_tags($_POST['FotoPerfil'])));//Faltaría poder subir la fotografía
	$sql = "UPDATE  aw.usuarios SET usuarios.biografia = '$biografia', usuarios.foto = ' ' WHERE usuarios.id_usuario like '$nombre' ";

	$result= mysqli_query($db,$sql);
	if($result)
	{
		header('Location: Main.php');
	}
		


?>