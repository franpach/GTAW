<?php


	
	/*Función que lista toda la información de un juego*/
	function sacarjuego($juego) {
		require 'dbconnect.php';
		$sql = "SELECT * FROM aw.videojuegos WHERE videojuegos.id_juego LIKE '$juego'";
		$result = mysqli_query($db, $sql);
		return $result;
	}

	/*Función que lista los autores de últimos 3 análisis de un juego*/
	function ultimosAnalisis($juego) {
		require 'dbconnect.php';
		$sql = "SELECT id_usuario FROM aw.analisis WHERE analisis.id_juego LIKE '$juego' ORDER BY analisis.fecha DESC LIMIT 3";
		$result = mysqli_query($db, $sql);
		return $result;
	}

	/*Función que lista los autores de las últimas 3 opiniones de un juego*/
	function ultimasOpiniones($juego) {
		require 'dbconnect.php';
		$sql = "SELECT id_usuario FROM aw.opiniones WHERE opiniones.id_juego LIKE '$juego' ORDER BY opiniones.fecha DESC LIMIT 3";
		$result = mysqli_query($db, $sql);
		return $result;
	}

	/*Función que lista todos los análisis de un juego*/
	function listaAnalisis($juego) {
		require 'dbconnect.php';
		$sql = "SELECT id_usuario, texto, titulo, val_pos, val_neg FROM aw.analisis WHERE analisis.id_juego LIKE '$juego'";
		$result = mysqli_query($db, $sql);
		return $result;	
	}

	/*Función que lista todas las opiniones de un juego*/
	function listaOpiniones($juego) {
		require 'dbconnect.php';
		$sql = "SELECT id_usuario, texto, titulo, val_pos, val_neg FROM aw.opiniones WHERE opiniones.id_juego LIKE '$juego'";
		$result = mysqli_query($db, $sql);
		return $result;	
	}

	/*Función que lista todos los juegos del sitio*/
	function listaJuegos() {
		require 'dbconnect.php';
		$sql = "SELECT id_juego, portada, fecha_venta, plataforma, genero, descripcion, nota FROM aw.videojuegos";
		$result=mysqli_query($db, $sql);
		return $result;
	}

	/*Función que selecciona el análisis mejor valorado para un juego*/
	function mejorAnalisis($juego) {
		require 'dbconnect.php';
		$sql = "SELECT id_usuario, titulo FROM aw.analisis WHERE analisis.id_juego LIKE '$juego' ORDER BY (analisis.val_pos-analisis.val_neg) DESC LIMIT 1";
		$result=mysqli_query($db, $sql);
		return $result;
	}

	/*Función que selecciona la opinión mejor valorada para un juego*/
	function mejorOpinion($juego) {
		require 'dbconnect.php';
		$sql = "SELECT id_usuario, titulo FROM aw.opiniones WHERE opiniones.id_juego LIKE '$juego' ORDER BY (opiniones.val_pos - opiniones.val_neg) DESC LIMIT 1";
		$result=mysqli_query($db, $sql);
		return $result;
	}

	/*Función que saca toda la información de un análisis de un usuario concreto para un juego concreto*/
	function consultaAnalisis($juego, $usuario) {
		require 'dbconnect.php';
		$sql = "SELECT * FROM aw.analisis WHERE analisis.id_juego LIKE '$juego' AND analisis.id_usuario LIKE '$usuario'";
		$result=mysqli_query($db, $sql);
		return $result;
	}

	/*Función que saca toda la información de una opinión de un usuario concreto para un juego concreto*/
	function consultaOpinion($juego, $usuario) {
		require 'dbconnect.php';
		$sql = "SELECT * FROM aw.opiniones WHERE opiniones.id_juego LIKE '$juego' AND opiniones.id_usuario LIKE '$usuario'";
		$result=mysqli_query($db, $sql);
		return $result;
	}

	/*Función que devuelve la foto de un usuario*/
	function fotoUsuario($usuario) {
		require 'dbconnect.php';
		$sql = "SELECT foto FROM aw.usuarios WHERE usuarios.id_usuario LIKE '$usuario'";
		$result=mysqli_query($db, $sql);
		return $result;
	}

	/*Función que devuelve todos los comentarios de un análisis*/
	function sacarComAnalisis($idanalisis) {
		require 'dbconnect.php';
		$sql = "SELECT * FROM aw.com_an WHERE com_an.id_analisis LIKE '$idanalisis'";
		$result=mysqli_query($db, $sql);
		return $result;
	}

	/*Función que devuelve todos los comentarios de una opinión*/
	function sacarComOpinion($idopinion) {
		require 'dbconnect.php';
		$sql = "SELECT * FROM aw.com_op WHERE com_op.id_opinion LIKE '$idopinion'";
		$result=mysqli_query($db, $sql);
		return $result;
	}

	/*Función que saca todos los análisis*/
	function sacarAnalisis() {
		require 'dbconnect.php';
		$sql = "SELECT id_usuario, id_juego, texto, titulo, val_pos, val_neg FROM aw.analisis ORDER BY analisis.fecha DESC LIMIT 10";
		$result = mysqli_query($db, $sql);
		return $result;
	}

	/*Función que saca todos las opiniones*/
	function sacarOpiniones() {
		require 'dbconnect.php';
		$sql = "SELECT id_usuario, id_juego, texto, titulo, val_pos, val_neg FROM aw.opiniones ORDER BY opiniones.fecha DESC LIMIT 10";
		$result = mysqli_query($db, $sql);
		return $result;
	}

	/*Función que saca los 5 mejores juegos de un género concreto*/
	function sacarTopJuegos($genero) {
		require 'dbconnect.php';
		$sql = "SELECT id_juego FROM aw.videojuegos WHERE videojuegos.genero LIKE '$genero' ORDER BY videojuegos.nota DESC LIMIT 5";
		$result = mysqli_query($db, $sql);
		return $result;
	}

	/*Función que saca el id de usuario, foto y su valoración absoluta (votos pos - votos neg de todos sus aportes)  de los 100 mejores users*/
	function usuariosTop() {
		require 'dbconnect.php';
		$sql = "SELECT id_usuario, foto, valoracion FROM aw.usuarios ORDER BY valoracion DESC LIMIT 100";
		$result = mysqli_query($db, $sql);
		return $result;
	}

	/*Función que saca el mejor artículo de un usuario junto a la nota del mismo (val_pos - val_neg)*/
	function mejorArticulo($usuario) {
		require 'dbconnect.php';
		// MEJOR ANÁLISIS
		$mejorAn = "SELECT titulo, valoracion FROM aw.analisis WHERE analisis.id_usuario LIKE '$usuario' ORDER BY analisis.valoracion DESC LIMIT 1";
		$analisis = mysqli_query($db, $mejorAn);

		// MEJOR OPINIÓN
		$mejorOp = "SELECT titulo, valoracion FROM aw.opiniones WHERE opiniones.id_usuario LIKE '$usuario' ORDER BY opiniones.valoracion DESC LIMIT 1";
		$opinion = mysqli_query($db, $mejorOp);

		// VEMOS CUAL ES MEJOR
		if((mysqli_num_rows($analisis)==1) && (mysqli_num_rows($opinion)==1)) {
			// SI HA APORTADO AMBOS TIPO DE ARTÍCULO
			$filan = mysqli_fetch_row($analisis);
			$a = intval($filan[1]);
			$filop = mysqli_fetch_row($opinion);
			$o = intval($filop[1]);
			if ($a >= $o) {
				$result = mysqli_query($db, $mejorAn); // EN CASO DE IGUALDAD TAMBIÉN SE SACA EL ANÁLISIS
			}
			else $result = mysqli_query($db, $mejorOp);
		}	
		else {
			// SI SOLO HA APORTADO DE UN TIPO, SACAMOS EL MEJOR DE ESE TIPO
			if(mysqli_num_rows($analisis)==0) $result = $opinion;
			else $result = $analisis;
		}
		return $result;
	}

	/*Función que devuelve la lista de los próximos 10 lanzamientos*/
	function ultimosDiezLanz() {
		require 'dbconnect.php';
		$sql = "SELECT id_lanzamiento FROM aw.lanzamientos ORDER BY lanzamientos.fecha ASC LIMIT 10";
		$result = mysqli_query($db, $sql);
		return $result;
	}

	/*Función que devuelve la lista de todos los próximos lanzamientos*/
	function sacaLanzamientos() {
		require 'dbconnect.php';
		$sql = "SELECT id_lanzamiento, fecha, plataformas, genero, portada, avance FROM aw.lanzamientos ORDER BY lanzamientos.fecha ASC";
		$result = mysqli_query($db, $sql);
		return $result;
	}

	/*Función que devuelve toda la información de un lanzamiento*/
	function sacarLanzamiento($id_lanzamiento) {
		require 'dbconnect.php';
		$sql = "SELECT * FROM aw.lanzamientos WHERE lanzamientos.id_lanzamiento LIKE '$id_lanzamiento'";
		$result = mysqli_query($db, $sql);
		return $result;
	}
	/*Función que devuelve un usuario de la base de datos al hacer login*/
	function loginUsuario($corr,$contr){
		require 'dbconnect.php';
		$Key = "gtaw2549";
		$encriptado = base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($Key), $contr, MCRYPT_MODE_CBC, md5(md5($Key))));
					
		$sql= "SELECT * FROM aw.usuarios WHERE usuarios.correo LIKE '$corr' AND usuarios.password LIKE '$encriptado'";
		$result = mysqli_query($db, $sql);
		return $result;			
	}
	/*Función que devuelve un usuario de la base para comprobar si ya existe*/
	function compruebaUsu($nombre){
		require 'dbconnect.php';
          $sql= "SELECT * FROM aw.usuarios WHERE usuarios.id_usuario like '$nombre'";
          $consulta = mysqli_query($db,$sql);
          return $consulta;
	}

	/*Función que inserta un nuevo usuario*/
	function regisUsu($nombre,$contr,$corr){
		require 'dbconnect.php';
          
        $Key = "gtaw2549";
        $encriptado = base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($Key), $contr, MCRYPT_MODE_CBC, md5(md5($Key))));

        $sql = "INSERT INTO aw.usuarios VALUES ('$nombre', '$encriptado', ' ', '$corr' ,' ', ' ')";
        $result = mysqli_query($db, $sql);
        return $result;
        
	}

?>