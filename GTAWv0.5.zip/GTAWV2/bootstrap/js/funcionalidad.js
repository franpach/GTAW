/**
* Suma o resta los votos de un artículo
*/
function sumar(){
	alert("Se sumaria 1 a la puntuacion");
}
function restar(){
	alert("Se restaria 1 a la puntuacion");
}

/**
* Función para validar una dirección de correo
* Tiene que recibir el identificador del formulario
*/ 

function validateMail(idMail) {
	//Creamos un objeto 
   	object=document.getElementById(idMail);
    valueForm=object.value;

    // Patron para el correcto
    var patron=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/;
    if(valueForm.search(patron)==0) {
    //Mail correcto
       	document.getElementById('correoCorrecto').style.display = 'inline-block';
        document.getElementById('correoIncorrecto').style.display = 'none';
        objetoject.style.color="#000";
  	    return;
    }
    else if (valueForm == 0) {
        //No hay mail escrito
        document.getElementById('correoCorrecto').style.display = 'none';          
        document.getElementById('correoIncorrecto').style.display = 'none';
    }
    else {
        //Mail incorrecto
        document.getElementById('correoIncorrecto').style.display = 'inline-block';
        document.getElementById('correoCorrecto').style.display = 'none';
        object.style.color="#f00";
    }
}

/**
*Función que valida una contraseña
*/
function validatePass(idPass1,idPass2)
{

	//Creamos un objeto 
	object1=document.getElementById(idPass1);
	object2=document.getElementById(idPass2);
	valueForm1=object1.value;
	valueForm2=object2.value;
 
	// Patron para el correo
	if(valueForm1==valueForm2)
	{
		//Mail correcto
		document.getElementById('pwdCorrecto').style.display = 'inline-block';
		document.getElementById('pwdIncorrecto').style.display = 'none';
		object1.style.color="#000";
		return;
	}
	else if (valueForm2==0) {
		//No hay contraseña escrita
		document.getElementById('pwdIncorrecto').style.display = 'none';
		document.getElementById('pwdIncorrecto').style.display = 'none';
	}
	else {
		//Mail incorrecto
		document.getElementById('pwdCorrecto').style.display = 'inline-block';
		document.getElementById('pwdIncorrecto').style.display = 'none';
		object1.style.color="#f00";
	}
}

/**
*
*/
function insertarNota() {
	$("input[name=articulo]").change(function(){
		$("notaIn").hide();
		if($(this).attr('id')=="analisis") {
			$("#notaIn").show();
		}
		else {
			$("#notaIn").hide();	
		}
	});
}

function alertaOp(){
	alert("Esto mostraría las últimas opiniones de todos los juegos, no solo de uno");
}
function alertaAn() {
	alert("Esto mostraría los últimas análisis de todos los juegos, no solo de uno");	
}