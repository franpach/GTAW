<?php
	if((include 'database.php')==FALSE) {
      header('Location: paginaerror.php');
    }

	$usuario = $_GET["usuario"];
	$idcomentario = $_GET["idcomentario"];
	$tipo = $_GET["tipo"];

	// Sacamos los votos positivos, negativos y valoración del comentario
	$val_pos = votosCom($idcomentario, $tipo);
	$val = mysqli_fetch_row($val_pos);
	$votos_pos = $val[0];
	$votos_neg = $val[1];
	$valoracionCom = $val[2];
	$escritor = $val[3];

	$consulta = sacarUsuario($escritor);
	$fila = mysqli_fetch_row($consulta);
	$valoracionUser = $fila[3]; // La valoración del usuario

	// Comprobamos si le ha dado like o dislike con anterioridad
	$havotado = compruebaMeGustaCom($idcomentario, $usuario, $tipo);
	if (mysqli_num_rows($havotado)==0){
		// Si no ha puntuado el comentario, se procede a registrar el voto
		// Le sumamos un voto positivo y uno a la valoración total
		$votos_pos = $votos_pos + 1;
		$valoracionCom = $valoracionCom + 1;

		// Le sumamos uno a la valoración del usuario
		$valoracionUser = $valoracionUser + 1;

		//Actualizamos el recuento e indicamos que al usuario le ha gustado ese comentario, también se suma 1 a la puntuación del usuario y del artículo
		if (insertMeGustaCom($idcomentario, $usuario, $tipo, 1) && actualizaVotosPosCom($idcomentario, $tipo, $votos_pos) && actualizaValUser($escritor, $valoracionUser) && actualizaValComentario($idcomentario, $valoracionCom, $tipo)) {
				echo json_encode(array("pos" => $votos_pos, "neg" => $votos_neg));
		}
	}
	else {
		$voto = mysqli_fetch_row($havotado);
		if ($voto[2]==1) { 
			// si había votado ya positivamente, se quitan las puntuaciones
			$valoracionUser = $valoracionUser - 1;
			$votos_pos = $votos_pos - 1;
			$valoracionCom = $valoracionCom - 1;

			// se elimina la entrada de los me gusta registrados
			if (eliminarMegustaCom($idcomentario, $usuario, $tipo) && actualizaVotosPosCom($idcomentario, $tipo, $votos_pos) && actualizaValUser($escritor, $valoracionUser) && actualizaValComentario($idcomentario, $valoracionCom, $tipo)) {

				echo json_encode(array("pos" => $votos_pos, "neg" => $votos_neg)); 

				//echo $votos_pos;
			}
		}
		else {
			// si había votado negativamente, se quita el voto negativo y se añade uno positivo
			$valoracionUser = $valoracionUser + 2;
			$votos_pos = $votos_pos + 1;
			$votos_neg = $votos_neg - 1;
			$valoracionCom = $valoracionCom + 2;

			// se actualiza la entrada de los me gusta registrados
			if (actMegustaCom($idcomentario, $usuario, $tipo, 1) && actualizaVotosNegCom($idcomentario, $tipo, $votos_neg) && actualizaValUser($escritor, $valoracionUser) && actualizaValComentario($idcomentario, $valoracionCom, $tipo) && actualizaVotosPosCom($idcomentario, $tipo, $votos_pos)) {
				echo json_encode(array("pos" => $votos_pos, "neg" => $votos_neg));
			}
		}
	}

?>