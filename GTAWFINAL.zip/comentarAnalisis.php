<?php
	if((include 'dbconnect.php')==FALSE) {
      header('Location: paginaerror.php');
    }
    if((include 'database.php')==FALSE) {
      header('Location: paginaerror.php');
    }
	session_start();
	$usuario = $_SESSION['nombre'];

	$idanalisis = $_GET["idanalisis"];
	$comentario = htmlspecialchars(trim(strip_tags($_POST['coment-text'])));

	$insert = insertComAn($usuario, $idanalisis, $comentario);

	if(!$insert) {
		echo "mal";
	}
	header("Location: analisis.php?idanalisis=$idanalisis");
?>