<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>Lanzamiento</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- CSS -->
  <link rel="stylesheet" href="bootstrap/css/header.css"> <!-- Cabecera, footer, links y título -->
  <link href="bootstrap/css/textos-juego.css" rel="stylesheet"> <!--- Textos -->
  <link rel="stylesheet" href="bootstrap/css/fichatecnica.css">  <!-- Listas de colores alternos azules -->

  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>
  <!-- Funcionalidad de la página -->
  <script src="bootstrap/js/funcionalidad.js"></script>
</head>
<body>
  <?php
    if(!include 'database.php') {
      header('Location: paginaerror.php');
    }

    session_start();
    if(isset($_SESSION['nombre'])) {
      $usuario = $_SESSION['nombre'];
    }
    else $usuario = "visitante";

    $lanzamiento = $_GET["lanzamiento"];

    // Información del juego
    $campos = sacarLanzamiento($lanzamiento);
    if($campos) {  
      if(mysqli_num_rows($campos)==0) {
        // Redireccionamos a página de error si el juego no existe
        header('Location: nocarga.php?error=juego');
      }
      else {
        $juego = mysqli_fetch_row($campos);  
      }
    }
    else {
      // Redireccionamos a página de error si el juego no existe
      header('Location: nocarga.php?error=juego');
    }
  ?>
  <div class="container">

    <!-- CABECERA -->
    <?php
      include 'menu.php';
    ?>

    <!-- LINKS -->
    <div class="row links">
      <div class="col-lg-12">
        <?php
          echo '<a href="main.php" >Inicio</a> / <a href="lanzamientos.php" >Próximos lanzamientos</a> / <a href="lanzamiento.php?lanzamiento=' . $lanzamiento . '" >' . $lanzamiento . '</a>';
        ?>
      </div>
    </div>

    <!-- TÍTULO -->
    <div class="row">
      <div class="col-lg-12">
        <?php
          echo '<h1 class="titulo">' . $juego[0] . '</h1>';
        ?>
      </div>
    </div>

    <!-- ACCIONES -->
    <div class="row">
      <div class="col-lg-3 boton-fich">
        <p><a class="btn btn-primary collapsed" data-target="#ficha-tecnica" data-toggle="collapse" aria-expanded="false">Ver ficha técnica »</a></p>
      </div>
    </div>

    <!-- FICHA TÉCNICA -->
    <div class="row collapse" id="ficha-tecnica">
      <div class="col-lg-3 comp-ficha-tecnica">
        <?php
          echo '<img class="portada-juego" src="' . $juego[9] . '"
                alt="portada no disponible" width=150 height=180>';            
        ?>
      </div>
      <div class="col-lg-3 div-tabla-datos comp-ficha-tecnica">
        <table class="tabla-datos">
          <tr class="tabla-datos-fila">
            <th class="tabla-datos-columna">Género</th>
            <?php
              echo '<th>' . $juego[3] . '</th>';
            ?>
          </tr>
          <tr class="tabla-datos-fila">
            <th class="tabla-datos-columna">Jugadores</th>
            <?php
              echo '<th>' . $juego[10] . '</th>';
            ?>
          </tr>
          <tr class="tabla-datos-fila">
            <th class="tabla-datos-columna">Plataformas</th>
            <?php
              echo '<th>' . $juego[2] . '</th>';
            ?>
          </tr>
          <tr class="tabla-datos-fila">
            <th class="tabla-datos-columna">Duración</th>
            <?php
              echo '<th>' . $juego[6] . '</th>';
            ?>
          </tr>
          <tr class="tabla-datos-fila">
            <th class="tabla-datos-columna">Idioma</th>
            <?php
              echo '<th>' . $juego[5] . '</th>';
            ?>
          </tr>
          <tr class="tabla-datos-fila">
            <th class="tabla-datos-columna">Lanzamiento</th>
            <?php
              echo '<th>' . $juego[1] . '</th>';
            ?>
          </tr>
          <tr class="tabla-datos-fila">
            <th class="tabla-datos-columna">Pegi</th>
            <?php
              echo '<th>' . $juego[7] . '</th>';
            ?>
          </tr>
        </table>
      </div>
      <div class="col-lg-6 video comp-ficha-tecnica">
       <iframe class="trailer" src="https://www.youtube.com/embed/16pEzz_ihtY" allowfullscreen></iframe>
     </div>
    </div>

    <!-- AVANCE -->
    <div class="row">
      <div class="col-lg-12">
        <h3> Descripción: </h3>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <?php
          echo '<p class="texto-borde-negro texto-justificado">' . $juego[4] . '</p>';
        ?>
      </div>  
    </div>

   
    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?> 

  </div>
</body>
</html>