<?php

	if((include 'dbconnect.php')==FALSE) {
      header('Location: paginaerror.php');
    }
    if((include 'database.php')==FALSE) {
      header('Location: paginaerror.php');
    }
	session_start();
	$usuario = $_SESSION['nombre'];

	$juego = $_GET["juego"];
	$titulo = htmlspecialchars(trim(strip_tags($_POST['titulo'])));
	$texto = htmlspecialchars(trim(strip_tags($_POST['texto'])));
	$tipo = htmlspecialchars(trim(strip_tags($_POST['articulo'])));

	if($tipo == 'analisis') {
		(int) $nota = $_POST["nota"];
		$insert = insertAnalisis($juego, $usuario, $texto, $titulo, $nota);

		// También se actualiza la nota media del juego
		$infoJuego = sacarjuego($juego);
		if($infoJuego) {
			$filaJuego = mysqli_fetch_row($infoJuego);
			if($filaJuego[6]==0) {
				actNotaJuego($juego, $nota);
			}
			else {
				(int) $notaMedia = ($filaJuego[6] + $nota) / 2;
				actNotaJuego($juego, $notaMedia);
			}
		}
		else header("Location: juego.php?juego=$juego");

		if(!$insert) {
			echo "mal";
		}
		header("Location: juego.php?juego=$juego");
	}
	else {
		$insert = insertOpinion($juego, $usuario, $texto, $titulo);
		if(!$insert) {
			echo "mal";
		}
		header("Location: juego.php?juego=$juego");
	}


?>