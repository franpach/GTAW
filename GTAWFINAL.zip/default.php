<?php
	header('Location: main.php');
?>