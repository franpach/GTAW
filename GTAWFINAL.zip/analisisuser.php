<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>Análisis</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- CSS -->
  <link rel="stylesheet" href="bootstrap/css/header.css"> <!-- Cabecera, footer, links y título -->
  <link rel="stylesheet" href="bootstrap/css/textos-juego.css"> <!-- Display informacion de juego -->
  <link href="bootstrap/css/infoarticulo.css" rel="stylesheet"> <!--- Display artículo -->
  <link rel="stylesheet" href="bootstrap/css/listas.css">  <!-- Display usuario -->
  <link rel="stylesheet" href="bootstrap/css/votos.css">  <!-- Display de botones para votar artículos y comentarios -->

  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>
  <!-- Funcionalidad de la página -->
  <script src="bootstrap/js/funcionalidad.js"></script>
</head>
<body>
	<?php
		if((include 'database.php')==FALSE) {
      		header('Location: paginaerror.php');
    	}	

    	session_start();
    	if(isset($_SESSION['nombre'])) {
      		$usuario = $_SESSION['nombre'];
    	}
    	else $usuario = "visitante";
		
		$escritor = $_GET["usuario"];
      	$lista = analisisUsuario($escritor);
      	if($lista) {
      		if (mysqli_num_rows($lista)==0) $noAn = true;
      		else $noAn = false;
      	}
      	else $noAn = true;
	?>
	<div class="container">
	
		<!-- CABECERA -->
	    <?php
	      include 'menu.php';
	    ?>

	    <!-- LINKS -->
	    <div class="row links">
	      <div class="col-lg-12">
	      	<?php
	        	echo '<a href="main.php" >Inicio</a> / <a href="usuario.php?usuario=' . $escritor . '" >Página de ' . $escritor . '</a> / <a href="analisisuser.php?usuario=' . $escritor . '" >Todos sus análisis</a>';
	        ?>
	      </div>
	    </div>

	    <!-- TITULO -->
	    <div class="row">
	    	<div class="col-lg-12">
	        	<?php
	        		echo '<h1 class="titulo">Todos los análisis de <a href="usuario.php?usuario=' . $escritor . '">' . $escritor . '</a></h1>';
	        	?>
	        </div>
	    </div>

	    <!-- LISTA -->
	    <?php
	    	if($noAn) {
	    		if($usuario == $escritor) {
	    			print '<div class="row">
	    					<div class="col-lg-12 nolista">
	    						<p> Vaya, parece que no has escrito ningún análisis. </p>
	    					</div>
	    				</div>';
	    		}
	    		else {
	    			print '<div class="row">
	    					<div class="col-lg-12 nolista">
	    						<p> Vaya, parece que este usuario no ha escrito ningún análisis. </p>
	    					</div>
	    				</div>';
	    		}
	    	}
	    	else {
	    		$tipo = "analisis";
	    		$i = 0; // se indexará cada análisis para poder referenciar sus elementos de forma unívoca
		        $num_total = mysqli_num_rows($lista);
		        $tamano_pagina = 5;
		        $pagina=0;
		        if(isset($_GET["pagina"])){
		            $pagina = $_GET["pagina"];
		          }
		        if(!$pagina){
		              $inicio=0;
		              $pagina=1;
		             }
		        else{
		              $inicio = ($pagina - 1) * $tamano_pagina;
		            }
		        $total_paginas = ceil($num_total / $tamano_pagina);
		        $lista = dividirAnalisisUsuario($escritor,$inicio,$tamano_pagina);
	    		while($analisis = mysqli_fetch_row($lista)) {
	    			$positivos = "positivo".$i;
	    			$negativos = "negativo".$i;
	    			$botonPos = "positivoB".$i;
	    			$botonNeg = "negativoB".$i;
	    			$i = $i + 1;
	    			print ' <div class="row row-art-titulo">
          						<div class="col-lg-10">
					            	<h3 class="expand"> <a href="analisis.php?idanalisis=' . $analisis[5] . '">' . $analisis[2] . '</a> </h3>
					         	</div>
					    	</div>
					        <div class="row row-art-contenido">
					          <div class="col-lg-10">
					            <p class="texto-borde-gris texto-mediano texto-scroll">' . $analisis[1] . '</p>
					          </div>
					          <div class="col-lg-2 puntuacion-art-lista">
					            <div class="row btn-rate">
					              <div class="col-lg-12">
					                <span id="' . $positivos . '" class="voto">' . $analisis[3] . '<span>
					                <button type="button" class="positive" value="sumar" onClick="votoPosArt(&quot;'.$usuario.'&quot;, &quot;'.$analisis[5].'&quot;, &quot;'.$tipo.'&quot;, &quot;'.$positivos.'&quot;, &quot;'.$negativos.'&quot;, &quot;'.$botonPos.'&quot;, &quot;'.$botonNeg.'&quot;)">';

					                	// COLORES BOTONES
					                	
						                $consultaVoto = compruebaMeGustaArt($analisis[5], $usuario, 'analisis');
						                if($consultaVoto) {
						                  if(mysqli_num_rows($consultaVoto)==0) {
						                    echo '<img class="rateArt" src="img/positive-black.png" alt="positivo" id="' . $botonPos . '"></button><br>';  
						                  }
						                  else {
						                    $filaMG = mysqli_fetch_row($consultaVoto);
						                    if($filaMG[2]==1) {
						                      echo '<img class="rateArt" src="img/positive-green.png" alt="positivo" id="' . $botonPos . '"></button><br>';
						                    }
						                    else {
						                      echo '<img class="rateArt" src="img/positive-black.png" alt="positivo" id="' . $botonPos . '"></button><br>';  
						                    }
						                  }
						                }
						                else {
						                  echo '<img class="rateArt" src="img/positive-black.png" alt="positivo" id="' . $botonPos . '"></button><br>';
						               	}

					print'              </div>
					            </div>
					            <div class="row btn-rate">
					              <div class="col-lg-12">
					                <span id="' . $negativos . '" class="voto">' . $analisis[4] . '<span> 
					                <button type="button" class="negative" value="restar" onClick="votoNegArt(&quot;'.$usuario.'&quot;, &quot;'.$analisis[5].'&quot;, &quot;'.$tipo.'&quot;, &quot;'.$positivos.'&quot;, &quot;'.$negativos.'&quot;, &quot;'.$botonPos.'&quot;, &quot;'.$botonNeg.'&quot;)">';

					                	// COLORES BOTONES
					                	$consultaVoto = compruebaMeGustaArt($analisis[5], $usuario, 'analisis');
						                if($consultaVoto) {
						                  if(mysqli_num_rows($consultaVoto)==0) {
						                    echo '<img class="rateArt" src="img/negative-black.png" alt="negativo" id="' . $botonNeg . '"></button><br>';  
						                  }
						                  else {
						                    $filaMG = mysqli_fetch_row($consultaVoto);
						                    if($filaMG[2]==1) {
						                      echo '<img class="rateArt" src="img/negative-black.png" alt="negativo" id="' . $botonNeg . '"></button><br>';
						                    }
						                    else {
						                      echo '<img class="rateArt" src="img/negative-red.png" alt="negativo" id="' . $botonNeg . '"></button><br>';  
						                    }
						                  }
						                }
						                else {
						                  echo '<img class="rateArt" src="img/negative-black.png" alt="negativo" id="' . $botonNeg . '"></button><br>';
						                }
					                	
					print'         </div>
					            </div>
					            </div>
					        	<div class="row row-juego">
					        		<div class="col-lg-10">
					        			<p>Para el juego: <a href="juego.php?juego=' . $analisis[0] . '"> ' . $analisis[0] . ' </a></p>
					        		</div>
					        	</div>	
					         </div>';

	    		}	
	    	}
	    ?>

    <!-- PAGINACION -->
    <?php
     if(mysqli_num_rows($lista)!=0) {
       if ($total_paginas > 1)
                {
                  echo '<ul class="pagination ">';
                  if ($pagina != 1)
                    echo '<li><a href="analisisuser.php?usuario='. $escritor .'&pagina='.($pagina-1).'">&laquo;</a></li>';
                    for ($i=1;$i<=$total_paginas;$i++) {
                       if ($pagina == $i)
                          //si muestro el índice de la página actual, no coloco enlace
                          echo "<li class='active'><a href='#'>". $pagina . "</a></li>";
                       else
                          //si el índice no corresponde con la página mostrada actualmente,
                          //coloco el enlace para ir a esa página
                          echo '  <li><a href="analisisuser.php?usuario='. $escritor .'&pagina='.$i.'">'.$i.'</a></li>  ';
                    }
                    if ($pagina != $total_paginas)
                    {
                       echo '<li><a href="analisisuser.php?usuario='. $escritor .'&pagina='.($pagina+1).'">&raquo;</a></li>';
                     }
                     echo '</ul>';
              }
     } 

    ?>

	   	<!-- FOOTER -->
	    <?php
	      $ok = include 'footer.php';
	      if(!$ok) {
	        echo '<footer> GTAW </footer>';
	      }
	    ?> 

  </div>
</body>
</html>