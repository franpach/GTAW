<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>Horizon: Zero Dawn</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- CSS -->
  <link rel="stylesheet" href="bootstrap/css/header.css"> <!-- Cabecera, footer, links y título -->
  <link href="bootstrap/css/infoarticulo.css" rel="stylesheet"> <!--- Display artículo -->
  <link rel="stylesheet" href="bootstrap/css/infousuario.css">  <!-- Display usuario -->

  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>
  <!-- Funcionalidad de la página -->
  <script src="bootstrap/js/funcionalidad.js"></script>
</head>
<body>
  <?php 
    if((include 'database.php')==FALSE) {
      header('Location: paginaerror.php');
    }

    session_start();
    if(isset($_SESSION['nombre'])) {
      $usuario = $_SESSION['nombre'];
    }
    else $usuario = "visitante";
    
    $users = usuariosTop();
    if($users) {
      if(mysqli_num_rows($users)==0) {
        $nousers = true;
      }
      else $nousers = false;  
    }
    else $nousers = true;
    
  ?>
  <div class="container">

    <!-- CABECERA -->
    <?php
      include 'menu.php';
    ?>


    <!-- LINKS -->
    <div class="row links">
      <div class="col-lg-12">
        <a href="main.php" >Inicio</a> / <a href="topusers.php" >Top users</a> 
      </div>
    </div>

    <!-- TÍTULO -->
    <div class="row">
      <div class="col-lg-12">
        <h1 class="titulo"> TOP 100 Usuarios </h1>
      </div>
    </div>

    <!-- LISTA -->
    <?php
      if($nousers) {
        echo '<div class="row">
                <div class="col-lg-12">
                  <p class="lead"> ¡Vaya! Parece no hay nadie registrado en esta página...</p>
                </div>
              </div>'; 
      }
      else {
        echo '<div class="row">
                <div class="col-lg-12">
                  <p class="lead"> ¡Aquí están los mejores! ¿Quieres saber quiénes son los usuarios con mejor valoración? Aquí puedes verlos, acudir a sus perfiles
                  y ver todo su contenido. ¿Quieres aparecer tú también aquí? ¡No esperes más, y comienza a aportar tu contenido! </p>
                </div>
              </div>';
        $i=0;
        while ($user = mysqli_fetch_row($users)) {
          $i = $i+1;
          $con = mejorArticulo($user[0]); 
          $art = mysqli_fetch_row($con);
          echo '<div class="row user-row-rankin">
                <div class="col-lg-1 posicion-rankin">
                  <p>' . $i . '</p>
                </div>
                <div class="col-lg-2 userInfo-rankin">
                  <h3 class="username username-rankin"><a href="usuario.php?usuario=' . $user[0] . '">' . $user[0] . '</a></h3>
                </div>
                <div class="col-lg-1 userInfo-rankin">
                  <img class="imguser imguser-rankin" src="' . $user[1] . '"
                  alt="imagen de usuario no disponible" width=50 height=50>
                </div>
                <div class="col-lg-2 userInfo-rankin">
                  <p class="nota-pequena-user"> Nota de usuario: ' . $user[2] . '</p>
                </div>';
          if(count($art)==4) { // SI TIENE 4 ELEMENTOS ES UN ANALISIS POR TENER EL CAMPO NOTA
            echo '<div class="col-lg-4 userInfo-rankin">
                    <p class="info-articulo-rankin"> Mejor artículo: <a href="analisis.php?idanalisis=' . $art[0] . '">' . $art[1] . '</a></p>
                  </div>
                  <div class="col-lg-2 userInfo-rankin">
                    <p class="nota-pequena-art"> Nota del artículo:' . $art[2] . '</p>
                  </div>';
          }
          else { // SI NO, ES UNA OPINIÓN
            echo '<div class="col-lg-4 userInfo-rankin">
                    <p class="info-articulo-rankin"> Mejor artículo: <a href="opinion.php?idopinion=' . $art[0] . '">' . $art[1] . '</a></p>
                  </div>
                  <div class="col-lg-2 userInfo-rankin"> 
                   <p class="nota-pequena-art"> Nota del artículo: ' . $art[2] . '</p>
                  </div>';
          }
          echo '</div>';                
        }
      }
      
    ?>
  
    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?> 

  </div>
</body>
</html>