<!DOCTYPE html>
<html lang="es"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<meta name="description" content="">
<meta name="author" content="">
<link rel="icon" href="http://getbootstrap.com/favicon.ico">

<title>Hilo del foro</title>

<!-- Bootstrap core CSS -->
<link href="bootstrap/css/bootstrap.css" rel="stylesheet">

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

<!-- CSS -->
<link rel="stylesheet" href="bootstrap/css/header.css">
<link rel="stylesheet" href="bootstrap/css/bootstrap-theme.css" />
<link rel="stylesheet" href="bootstrap/css/infousuario.css">  <!-- Display usuario --> 
<link rel="stylesheet" href="bootstrap/css/formularios.css"> <!-- Display de formularios --> 
<link rel="stylesheet" href="bootstrap/css/foro.css">  <!-- Display foro -->

<!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
<!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
<script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
      <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
      <script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>
      <!-- Funcionalidad de la página -->
      <script type="text/javascript" src="bootstrap/js/funcionalidad.js"></script>
    </head>
    <body>
    <?php
      if((include 'database.php')==FALSE) {
        header('Location: paginaerror.php');
      }
      session_start();
      if(isset($_SESSION['nombre'])) {
        $usuario = $_SESSION['nombre'];
      }
      else $usuario = "visitante";

      $idTema = $_GET["idTema"];

      $temaCons = devuelveTema($idTema);
      $mensajes = sacarMensajesTema($idTema);
      if(!$temaCons || !$mensajes) {
        header('Location: nocarga.php?error=tema');
      }
      else {
        if(mysqli_num_rows($temaCons)==0) header('Location: nocarga.php?error=tema');
        else {
          $tema = mysqli_fetch_row($temaCons);
          $consFoto = fotoUsuario($tema[2]);
          $foto = mysqli_fetch_row($consFoto);
          if (mysqli_num_rows($mensajes)==0) $noMsj = true;
          else $noMsj = false;
        }
      }
    ?>
    <div class="container">

      <!-- CABECERA -->
      <?php
        include 'menu.php';
      ?>

      <!-- LINKS -->
      <div class="row links">
        <div class="col-lg-12">
          <a href="main.php" >Inicio</a> / <a href="foro.php">Foro</a> / <a href="mensajes.php">Mensaje</a> 
        </div>
      </div>

      <!-- TÍTULO -->
      <div class="row">
        <div class="col-lg-12">
          <?php echo '<h1 class="titulo"> '. $tema[1] .' <a class="btn btn-default" href="foro.php"><span class="fa fa-backward"></span> Volver atrás</a></h1>';?>
        </div>
      </div>
      
      <?php
      
      print '

        <ul class="media-list ">
          <li class="media well">
            <div class="pull-left info-usu">
              <img class="imguser" src='. $foto[0] .' alt="imagen de usuario no disponible" width=50 height=50><br>
              <a href="usuario.php?usuario=' . $tema[2] . '" class="nombre-usu">'. $tema[2] .'</a>
              <br>
            </div>
            <div class="media-body">
              <div class="post btn-group btn-group-xs">
                <a href="#" class="btn btn-default"><span class="fa fa-clock-o"></span> '. $tema[4] .'</a>
                <button href="#" class="btn btn-danger" onclick="reporte(&quot;'.$tema[0].'&quot;)"><span class="fa fa-warning"  ></span> Reportar</a>
              </div>
              <p>' . $tema[3] .' </p>
            </div>
          </li>';
         
        if(!$noMsj) {
          //Se obtiene el número de páginas que va a tener este tema
           $num_total = mysqli_num_rows($mensajes);
              $tamano_pagina = 5;
              $pagina=0;
              if(isset($_GET["pagina"])){
              $pagina = $_GET["pagina"];
             }
              if(!$pagina){
                $inicio=0;
                $pagina=1;
              }
              else
              {
                $inicio = ($pagina - 1) * $tamano_pagina;
              }
              $total_paginas = ceil($num_total / $tamano_pagina);
              $mensajes = dividirMensajesForo($idTema,$inicio,$tamano_pagina);
          while($mensaje = mysqli_fetch_row($mensajes)){
            $consFoto = fotoUsuario($mensaje[2]);
            $foto = mysqli_fetch_row($consFoto);
              print '<li class="media well">
                          <div class="pull-left info-usu">
                            <img class="imguser" src='. $foto[0] .' alt="imagen de usuario no disponible" width=50 height=50><br>
                            <a href="usuario.php?usuario=' . $mensaje[2] . '" class="nombre-usu">'. $mensaje[2] .'</a>
                            <br>
                          </div>
                          <div class="media-body">
                            <div class="post btn-group btn-group-xs">
                              <a href="#" class="btn btn-default"><span class="fa fa-clock-o"></span> '. $mensaje[4] .'</a>
                              <button href="#" class="btn btn-danger" onclick="reporte(&quot;'.$mensaje[0].'&quot;)"><span class="fa fa-warning"  ></span> Reportar</a>
                            </div>
                            <p>' . $mensaje[3] .' </p>
                          </div>
                        </li>';
          }
        }
        print '</ul>';            
      ?>
    
        <?php
          if($usuario !== "visitante") {
            echo '<div class="row">
                    <div class="col-lg-2 ">
                      <p><a class="btn btn-primary collapsed" data-target="#form-comentar" data-toggle="collapse" aria-expanded="false">Comentar »</a></p>
                    </div>
                  </div>';
          }
        ?>
        
      <div class="row collapse" id="form-comentar">
        <?php 

          print'<form method="post" action="comentarTema.php?tema=' . $idTema . '">'?>
                   <div class="row ">
                      <div class="col-lg-6 col-lg-offset-3">
                        <br>
                        <p><label for="comentario">Escribe tu comentario</label></p>
                          <textarea class="coment-text textarea-lg" name="comentario" placeholder="Comentario..."></textarea>
                      </div>
                    </div>
                    <div class="row">
                      <div class ="col-lg-3 col-lg-offset-3">
                       <button class="btn btn-primary btn-block btn-lg" >Publicar comentario</button>
                      </div>
                    </div>
                    </form>
                 </div>
      <?php 
    //paginacion
     if(mysqli_num_rows($mensajes)!=0) {
       if ($total_paginas > 1)
                {
                  echo '<ul class="pagination ">';
                  if ($pagina != 1)
                    echo '<li><a href="mensaje.php?idTema='. $idTema .'&pagina='.($pagina-1).'">&laquo;</a></li>';
                    for ($i=1;$i<=$total_paginas;$i++) {
                       if ($pagina == $i)
                          //si muestro el índice de la página actual, no coloco enlace
                          echo "<li class='active'><a href='#'>". $pagina . "</a></li>";
                       else
                          //si el índice no corresponde con la página mostrada actualmente,
                          //coloco el enlace para ir a esa página
                          echo '  <li><a href="mensaje.php?idTema='. $idTema .'&pagina='.$i.'">'.$i.'</a></li>  ';
                    }
                    if ($pagina != $total_paginas)
                    {
                       echo '<li><a href="mensaje.php?idTema='. $idTema .'&pagina='.($pagina+1).'">&raquo;</a></li>';
                     }
                     echo '</ul>';
              }
     }
    ?>
        
    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?>

      </div>

    </body>
    </html>