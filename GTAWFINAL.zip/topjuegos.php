<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>Top 5 juegos</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- CSS -->
  <link rel="stylesheet" href="bootstrap/css/header.css"> <!-- Cabecera, footer, links y título -->
  <link rel="stylesheet" href="bootstrap/css/navalternate.css">  <!-- Listas de colores alternos azules -->


  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>
  <!-- Funcionalidad de la página -->
  <script src="bootstrap/js/funcionalidad.js"></script>
</head>
<body>
  <?php
    if((include 'database.php')==FALSE) {
      header('Location: paginaerror.php');
    }

    session_start();
    if(isset($_SESSION['nombre'])) {
      $usuario = $_SESSION['nombre'];
    }
    else $usuario = "visitante";

    //SACAMOS LOS 5 PRIMEROS JUEGOS DE CADA GÉNERO
    $topAccAv = sacarTopJuegos('accion/aventuras');
    if($topAccAv) {
      if(mysqli_num_rows($topAccAv)==0) {
        $noAc = true;
      }
      else $noAc = false;  
    }
    else $noAc = true;
    

    $topDep = sacarTopJuegos('deportivo');
    if($topDep) {
      if(mysqli_num_rows($topDep)==0) {
        $noDep = true;
      }
      else $noDep = false;  
    }
    else $noDep = true;
    
    $topRol = sacarTopJuegos('rol');
    if($topRol) {
      if(mysqli_num_rows($topRol)==0) {
        $noRol = true;
      }
      else $noRol = false;  
    }
    else $topRol = true;
    
    $topEst = sacarTopJuegos('estrategia');
    if($topEst) {
      if(mysqli_num_rows($topEst)==0) {
        $noEst = true;
      }
      else $noEst = false;
    }
    else $noEst = true;
    
    $topMMO = sacarTopJuegos('MMO');
    if($topMMO) {
      if(mysqli_num_rows($topMMO)==0) {
        $noMMO = true;
      }
      else $noMMO = false;  
    }
    else $noMMO = true;
    
    $topCon = sacarTopJuegos('conduccion');
    if($topCon) {
      if(mysqli_num_rows($topCon)==0) {
        $noCon = true;
      }
      else $noCon = false;    
    }
    else $noCon = true;
    
  ?>
  <div class="container">

    <!-- CABECERA -->
    <?php
      include 'menu.php';
    ?>

    <!-- LINKS -->
    <div class="row links">
      <div class="col-lg-12">
        <a href="main.php" >Inicio</a> / <a href="topjuegos.php" >Top 5 juegos</a> 
      </div>
    </div>

    <!-- TÍTULO -->
    <div class="row">
      <div class="col-lg-12">
        <h1 class="titulo">TOP 5 Juegos</h1>
      </div>
    </div>

    <!-- TOPS -->
    <div class="row">
      <div class="col-lg-4">
        <h2>Acción/Aventura</h2>
          <?php
            if ($noAc) {
              echo '<p>No hay juegos que mostrar para este género</p>';
            }
            else {
              echo '<ul class="nav nav-alternate">';
              while($juego = mysqli_fetch_row($topAccAv)) {
                echo '<li><a href="juego.php?juego=' . $juego[0] . '">' . $juego[0] . '</a></li>';
              }
              echo '</ul>';
              echo '<p><a class="btn btn-primary" href="juegos.php?genero=accion/aventuras" role="button">Ver todos »</a></p>';
            }
          ?>
      </div>
      <div class="col-lg-4">
        <h2>Deportivos</h2>
          <?php
            if ($noDep) {
              echo '<p>No hay juegos que mostrar para este género</p>';
            }
            else {
              echo '<ul class="nav nav-alternate">';
              while($juego = mysqli_fetch_row($topDep)) {
                echo '<li><a href="juego.php?juego=' . $juego[0] . '">' . $juego[0] . '</a></li>';
              }
              echo '</ul>';
              echo '<p><a class="btn btn-primary" href="juegos.php?genero=deportivo" role="button">Ver todos »</a></p>';
            }
          ?>
      </div>
      <div class="col-lg-4">
        <h2>Rol</h2>
          <?php
            if ($noRol) {
              echo '<p>No hay juegos que mostrar para este género</p>';
            }
            else {
              echo '<ul class="nav nav-alternate">';
              while($juego = mysqli_fetch_row($topRol)) {
                echo '<li><a href="juego.php?juego=' . $juego[0] . '">' . $juego[0] . '</a></li>';
              }
              echo '</ul>';
              echo '<p><a class="btn btn-primary" href="juegos.php?genero=rol" role="button">Ver todos »</a></p>';
            }
          ?>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-4">
        <h2>Estrategia</h2>
          <?php
            if ($noEst) {
              echo '<p>No hay juegos que mostrar para este género</p>';
            }
            else {
              echo '<ul class="nav nav-alternate">';
              while($juego = mysqli_fetch_row($topEst)) {
                echo '<li><a href="juego.php?juego=' . $juego[0] . '">' . $juego[0] . '</a></li>';
              }
              echo '</ul>';
              echo '<p><a class="btn btn-primary" href="juegos.php?genero=estrategia" role="button">Ver todos »</a></p>';
            }
          ?>
      </div>
      <div class="col-lg-4">
        <h2>MMO</h2>
          <?php
            if ($noMMO) {
              echo '<p>No hay juegos que mostrar para este género</p>';
            }
            else {
              echo '<ul class="nav nav-alternate">';
              while($juego = mysqli_fetch_row($topMMO)) {
                echo '<li><a href="juego.php?juego=' . $juego[0] . '">' . $juego[0] . '</a></li>';
              }
              echo '</ul>';
              echo '<p><a class="btn btn-primary" href="juegos.php?genero=MMO" role="button">Ver todos »</a></p>';
            }
          ?>
      </div>
      <div class="col-lg-4">
        <h2>Conducción</h2>
          <?php
            if ($noCon) {
              echo '<p>No hay juegos que mostrar para este género</p>';
            }
            else {
              echo '<ul class="nav nav-alternate">';
              while($juego = mysqli_fetch_row($topCon)) {
                echo '<li><a href="juego.php?juego=' . $juego[0] . '">' . $juego[0] . '</a></li>';
              }
              echo '</ul>';
              echo '<p><a class="btn btn-primary" href="juegos.php?genero=conduccion" role="button">Ver todos »</a></p>';
            }
          ?>
      </div>
    </div>         
            
    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?> 

  </div>
</body>
</html>