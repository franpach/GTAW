<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>Horizon: Zero Dawn</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- CSS -->
  <link rel="stylesheet" href="bootstrap/css/header.css"> <!-- Cabecera, footer, links y título -->
  <link href="bootstrap/css/portadas.css" rel="stylesheet"> <!--- Imágenes de portada -->
  <link rel="stylesheet" href="bootstrap/css/navalternate.css">  <!-- Listas de colores alternos azules -->
  <link rel="stylesheet" href="bootstrap/css/fichatecnica.css">  <!-- Ficha técnica de un juego-->

  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>
  <!-- Funcionalidad de la página -->
  <script src="bootstrap/js/funcionalidad.js"></script>
</head>
<body>
  <?php
      if((include 'database.php')==FALSE) {
        header('Location: paginaerror.php');
      }

      session_start();
      if(isset($_SESSION['nombre'])) {
        $usuario = $_SESSION['nombre'];
      }
      else $usuario = "visitante";

      $juego = $_GET["juego"];

      // SACAMOS INFORMACIÓN VARIA QUE SE NECESITARÁ
      // Información del juego
      $campos = sacarjuego($juego);

      if($campos) {
        if(mysqli_num_rows($campos) !== 0) {
          $infojuego = mysqli_fetch_row($campos);
        
          // últimos 3 análisis y opiniones
          $ultimosAn = ultimosAnalisis($juego);
          $ultimasOp = ultimasOpiniones($juego);

          // mejor análisis y mejor opinión
          $mejorAn = mejorAnalisis($juego);
          if(mysqli_num_rows($mejorAn) > 0) {
            $vaciaAn = false;
            $infoMejorAn = mysqli_fetch_row($mejorAn);
          }
          else $vaciaAn = true;
          
          $mejorOp = mejorOpinion($juego);
          if(mysqli_num_rows($mejorOp) > 0) {
            $vaciaOp = false;
            $infoMejorOp = mysqli_fetch_row($mejorOp);
          } 
          else $vaciaOp = true;   
        } 
        else {
          // Redireccionamos a página de error si el juego no existe
          header('Location: nocarga.php?error=juego');  
        } 
      }
      else {
        // Redireccionamos a página de error si el juego no existe
        header('Location: nocarga.php?error=juego');  
      }
    ?>
  <div class="container">

    <!-- CABECERA -->
    <?php
      include 'menu.php';
    ?>

    <!-- LINKS -->
    <div class="row links">
      <div class="col-lg-12">
        <?php
          echo '<a href="main.php" >Inicio</a> / <a href="juegos.php" >Juegos</a> / <a href="juego.php?juego=' . $juego . '" >' . $juego . '</a>';
        ?> 
      </div>
    </div>

    <!-- TÍTULO -->
    <div class="row">
      <div class="col-lg-12">
        <?php
          echo '<h1 class="titulo">' . $infojuego[0] . '</h1>';
        ?>
      </div>
    </div>

    <!-- ACCIONES -->
    <div class="row">
      <div class="col-lg-2 boton-fich">
        <p><a class="btn btn-primary collapsed" data-target="#ficha-tecnica" data-toggle="collapse" aria-expanded="false">Ver ficha técnica »</a></p>
      </div>
      <?php
        if($usuario != "visitante") {
          echo '<div class="col-lg-2">
                  <p><a class="btn btn-primary collapsed" href="subetucontenido.php?juego=' . $infojuego[0] . '" role="button">Subir un artículo »</a></p>
                </div>';
          }
      ?>
    </div>

    <!-- FICHA TÉCNICA -->
    <div class="row collapse ficha-tecnica" id="ficha-tecnica">
      <div class="col-lg-3">
        <?php
          echo '<img class="portada-juego" src="' . $infojuego[1] . '"
          alt="portada no disponible" width=150 height=180>';            
        ?>
      </div>
      <div class="col-lg-3 div-tabla-datos comp-ficha-tecnica">
        <table class="tabla-datos">
          <tr class="tabla-datos-fila">
            <th class="tabla-datos-columna">Género</th>
            <?php
            echo "<th>$infojuego[4]</th>";
            ?>
          </tr>
          <tr class="tabla-datos-fila">
            <th class="tabla-datos-columna">Jugadores</th>
            <?php
            echo "<th>$infojuego[8]</th>";
            ?>              
          </tr>
          <tr class="tabla-datos-fila">
            <th class="tabla-datos-columna">Plataformas</th>
            <?php
            echo "<th>$infojuego[3]</th>";
            ?>              
          </tr>
          <tr class="tabla-datos-fila">
            <th class="tabla-datos-columna">Duración</th>
            <?php
            echo "<th>$infojuego[10]</th>";
            ?>              
          </tr>
          <tr class="tabla-datos-fila">
            <th class="tabla-datos-columna">Idioma</th>
            <?php
            echo "<th>$infojuego[7]</th>";
            ?>              
          </tr>
          <tr class="tabla-datos-fila">
            <th class="tabla-datos-columna">Lanzamiento</th>
            <?php
            echo "<th>$infojuego[2]</th>";
            ?>              
          </tr>
          <tr class="tabla-datos-fila">
            <th class="tabla-datos-columna">Pegi</th>
            <?php
            echo "<th>$infojuego[9]</th>";
            ?>              
          </tr>
        </table>
      </div>
      <div class="col-lg-6 video">
        <?php
        echo '<iframe class="trailer" src="' . $infojuego[11] . '" allowfullscreen></iframe>';
        ?>
      </div>
    </div>

    <!-- ARTICULOS PRINCIPALES -->
    <div class="row">
      <div class="col-lg-6">
        <h2>Análisis</h2>
        <?php
          if(!$vaciaAn) {
            print '<p class="portada" id="portada-juego-an"><span class="titulo-art-ppal">' . $infoMejorAn[1] . '</span> | Por <a href="usuario.php?usuario=' . $infoMejorAn[0] . '">' . $infoMejorAn[0] . '</a></p>
                    <p><a class="btn btn-primary" href="analisis.php?idanalisis=' . $infoMejorAn[2] . '" role="button">Leer más »</a></p>';
          }
          else {
            print '<p>No podemos enseñarte el análisis mejor valorado porque nadie ha analizado este juego.</p>';
          }
        ?>
      </div>
      <div class="col-lg-6">
        <h2>Opiniones</h2>
        <?php
          if(!$vaciaOp) {
            print '<p class="portada" id="portada-juego-op"><span class="titulo-art-ppal">' . $infoMejorOp[1] . '</span> | Por <a href="usuario.php?usuario=' . $infoMejorOp[0] . '">' . $infoMejorOp[0] . '</a></p>
                    <p><a class="btn btn-primary" href="opinion.php?idopinion=' . $infoMejorOp[2] . '" role="button">Leer más »</a></p>';
          }
          else {
            print '<p>No podemos enseñarte la opinión mejor valorada porque nadie ha opinado acerca de este juego.</p>';
          }
        ?>
      </div>
    </div>

    <!-- LISTAS DE ULTIMOS ARTICULOS -->
    <div class="row">
      <div class="col-lg-6">
        <h3> Últimos análisis </h3>
          <?php
            if(mysqli_num_rows($ultimosAn)==0) {
              print '<div class="row">
                        <div class="col-lg-12 nolista">
                          <p> Vaya, parece que nadie ha escrito ningún análisis para este juego. </p>
                        </div>
                    </div>';
            }
            else {
              print '<ul class="nav nav-alternate">';
              while($fila = mysqli_fetch_row($ultimosAn)) {
                  print '<li><a href="analisis.php?idanalisis=' . $fila[1] . '">Por ' . $fila[0] . '';  
              }
              print '</ul>
                      <p><a class="btn btn-primary" href="listanalisis.php?juego=' . $juego . '" role="button">Ver todos »</a></p>';
            
            } 
          ?>
      </div>
      <div class="col-lg-6">
        <h3> Últimas opiniones </h3>
        <?php
            if(mysqli_num_rows($ultimasOp)==0) {
              print '<div class="row">
                        <div class="col-lg-12 nolista">
                          <p> Vaya, parece que nadie ha escrito ninguna opinión para este juego. </p>
                        </div>
                    </div>';
            }
            else {
              print '<ul class="nav nav-alternate">';
              while($fila = mysqli_fetch_row($ultimasOp)) {               
                print '<li><a href="opinion.php?idopinion=' . $fila[1] . '">Por ' . $fila[0] . '';  
              }
              print '</ul>
                      <p><a class="btn btn-primary" href="listopiniones.php?juego=' . $juego . '" role="button">Ver todas »</a></p>';
            } 
          ?>
      </div>
    </div>

    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?> 

  </div>
</body>
</html>