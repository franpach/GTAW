<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>Opinión</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- CSS -->
  <link rel="stylesheet" href="bootstrap/css/header.css"> <!-- Cabecera, footer, links y título -->
  <link rel="stylesheet" href="bootstrap/css/textos-juego.css"> <!-- Display informacion de juego -->
  <link href="bootstrap/css/infoarticulo.css" rel="stylesheet"> <!--- Display artículo -->
  <link rel="stylesheet" href="bootstrap/css/infousuario.css">  <!-- Display usuario -->
  <link rel="stylesheet" href="bootstrap/css/votos.css">  <!-- Display de botones para votar artículos y comentarios -->
  <link rel="stylesheet" href="bootstrap/css/comentario.css">  <!-- Display de comentarios -->

  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>
  <!-- Funcionalidad de la página -->
  <script src="bootstrap/js/funcionalidad.js"></script>
</head>
<body>

  <?php
    if(!include 'database.php') {
      header('Location: paginaerror.php');
    }
    $idopinion = $_GET["idopinion"];

    session_start();
    if(isset($_SESSION['nombre'])) {
      $usuario = $_SESSION['nombre'];
    }
    else $usuario = "visitante";

    // Sacamos la información de la opinión
    $consulta = consultaOpinion($idopinion);
    if($consulta) {
      if(mysqli_num_rows($consulta)==0) {
        header('Location: nocarga.php?error=articulo');
      }  
      else $opinion = mysqli_fetch_row($consulta); 
    }
    else header('Location: nocarga.php?error=articulo');
    
    // Sacamos la imagen del usuario
    $consulta = fotoUsuario($opinion[2]);
    if($consulta) {
      if(mysqli_num_rows($consulta)==0) {
        header('Location: nocarga.php?error=articulo');  
      } 
      else $foto = mysqli_fetch_row($consulta);
    }
    else header('Location: nocarga.php?error=articulo');
  ?>
  <div class="container">
    
    <!-- CABECERA -->
    <?php
      include 'menu.php';
    ?> 

    <!-- LINKS -->
    <div class="row links">
      <div class="col-lg-12">
        <?php
          echo '<a href="main.php" >Inicio</a> / <a href="juegos.php">Juegos</a> / <a href="juego.php?juego=' . $opinion[1] . '">' . $opinion[1] . '</a> / <a href="opinion.php?idopinion=' . $idopinion .'">Opinión de ' . $opinion[2] . '</a>'; 
        ?>
      </div>
    </div>

    <!-- TITULO -->
    <div class="row">
      <div class="col-lg-12">
        <?php
          echo '<h1 class="titulo">Opinión de: ' . $opinion[1] . '</h1>';
        ?>
      </div>
    </div>

    <!-- INFO ANALISIS -->
    <div class="row game">
      <div class="col-lg-2">
        <?php
          echo '<img class="imguser" src="' . $foto[0] . '" 
          alt="imagen de usuario no disponible" width=100 height=100>';
        ?>
        </div>
      <div class="col-lg-2">
        <?php
          print '<p>
                  Por:<a href="usuario.php?usuario=' . $opinion[2] . '"> ' . $opinion[2] .'</a><br>
                  Fecha: ' . $opinion[3] . '
                </p>';
        ?>
      </div>
      <div class="col-lg-4">
        <?php
          echo '<h2 class="titulo-art">' . $opinion[4] . '</h2>'; 
        ?>  
      </div>
      <div class="col-lg-2">
        <div class="row ranking">
          <div class="col-lg-6 puntuacion-art">
            <button type="button" class="positive" value="sumar" onClick="votoPosArt('<?php echo $usuario; ?>','<?php echo $idopinion; ?>', 'opinion', 'votosPos', 'votosNeg', 'positivo', 'negativo')">
              <?php
                $consultaVoto = compruebaMeGustaArt($idopinion, $usuario, 'opinion');
                if($consultaVoto) {
                  if(mysqli_num_rows($consultaVoto)==0) {
                    echo '<img class="rateArt" src="img/positive-black.png" alt="positivo" id="positivo"></button><br>';  
                  }
                  else {
                    $filaMG = mysqli_fetch_row($consultaVoto);
                    if($filaMG[2]==1) {
                      echo '<img class="rateArt" src="img/positive-green.png" alt="positivo" id="positivo"></button><br>';
                    }
                    else {
                      echo '<img class="rateArt" src="img/positive-black.png" alt="positivo" id="positivo"></button><br>';  
                    }
                  }
                }
                else {
                  echo '<img class="rateArt" src="img/positive-black.png" alt="positivo" id="positivo"></button><br>';
                }
              ?>
              <?php echo '<span class="votos" id="votosPos">' . $opinion[6] . '<span>'; ?>
          </div>  
          <div class="col-lg-6 puntuacion-art">
            <button type="button" class="negative" value="restar" onClick="votoNegArt('<?php echo $usuario; ?>','<?php echo $idopinion; ?>', 'opinion', 'votosPos', 'votosNeg', 'positivo', 'negativo')">
              <?php
                $consultaVoto = compruebaMeGustaArt($idopinion, $usuario, 'opinion');
                if($consultaVoto) {
                  if(mysqli_num_rows($consultaVoto)==0) {
                    echo '<img class="rateArt" src="img/negative-black.png" alt="negativo" id="negativo"></button><br>';  
                  }
                  else {
                    $filaMG = mysqli_fetch_row($consultaVoto);
                    if($filaMG[2]==1) {
                      echo '<img class="rateArt" src="img/negative-black.png" alt="negativo" id="negativo"></button><br>';
                    }
                    else {
                      echo '<img class="rateArt" src="img/negative-red.png" alt="negativo" id="negativo"></button><br>';  
                    }
                  }
                }
                else {
                  echo '<img class="rateArt" src="img/negative-black.png" alt="negativo" id="negativo"></button><br>';
                }
              ?>              <?php echo '<span class="votos" id="votosNeg">' . $opinion[7] . '<span>'; ?>
          </div>
        </div>
      </div>
    </div>

    <!-- ANALISIS -->
    <div class="row texto">
      <div class="col-lg-12">
        <?php echo '<p class="texto-borde-negro texto-justificado">' . $opinion[5] . '</p>'; ?>  
      </div>
    </div>
 
    <!-- COMENTARIOS -->
    <?php
      $comentarios = sacarComOpinion($idopinion);
      if(mysqli_num_rows($comentarios)==0) {
        echo '<div class="row nocom">
                  <div class="col-lg-12">
                    <p> No hay comentarios </p>    
                  </div>
                </div>';
      }
      else {
        $tipo = "opinion";
        $i = 0;
        $num_total = mysqli_num_rows($comentarios);
        $tamano_pagina = 5;
        $pagina=0;
        if(isset($_GET["pagina"])){
            $pagina = $_GET["pagina"];
          }
        if(!$pagina){
              $inicio=0;
              $pagina=1;
             }
        else{
              $inicio = ($pagina - 1) * $tamano_pagina;
            }
        $total_paginas = ceil($num_total / $tamano_pagina);
        $comentarios = dividirComOpinion($idopinion,$inicio,$tamano_pagina);
        while($com = mysqli_fetch_row($comentarios)) {
          $positivos = "positivo".$i;
          $negativos = "negativo".$i;
          $i = $i + 1;
          //sacamos la imagen del usuario de la tabla usuarios
          $usercomen = $com[1];
          $consultafoto = fotoUsuario($usercomen);
          $foto = mysqli_fetch_row($consultafoto);
          print '<div class="row row-comentario">
                    <div class="col-lg-1">
                      <img class="imguser" src="' . $foto[0] . '" width=75 height=75 alt="imagen de usuario no disponible">   
                    </div>
                    <div class="col-lg-2">
                      <div class="row">
                        <div class="col-lg-12">
                          <p><a href="usuario.php?usuario=' . $com[1] . '">' . $com[1] . '</a></p>
                        </div>  
                      </div>
                      <div class="row">
                        <div class="col-lg-12">
                          <p class="texto-comentario"> 
                            <button type="button" class="positive" value="sumar" onClick="votoPosCom(&quot;'.$usuario.'&quot;, &quot;'.$com[0].'&quot;, &quot;'.$tipo.'&quot;, &quot;'.$positivos.'&quot;, &quot;'.$negativos.'&quot;)">';
                              // Se comprueba si había dado like al comentario para poner el color correspondiente
                              $consultaMGC = compruebaMeGustaCom($com[0], $usuario, $tipo);
                              if($consultaMGC) {
                                if(mysqli_num_rows($consultaMGC)==0) {
                                  echo '<img class="rateCom" src="img/positive-black.png" alt="positivo" id="positivoC"></button>';  
                                }
                                else {
                                  $filaMG = mysqli_fetch_row($consultaMGC);
                                  if($filaMG[2]==1) {
                                    echo '<img class="rateCom" src="img/positive-green.png" alt="positivo" id="positivoC"></button>';
                                  }
                                  else {
                                    echo '<img class="rateCom" src="img/positive-black.png" alt="positivos" id="positivoC"></button>';  
                                  }
                                }
                              }
                              else {
                                echo '<img class="rateCom" src="img/positive-black.png" alt="positivos" id="positivoC"></button>';
                              }

          print'                <span class="voto" id="' . $positivos . '">' . $com[4] . '</span>
                            <button type="button" class="negative" value="restar" onClick="votoNegCom(&quot;'.$usuario.'&quot;, &quot;'.$com[0].'&quot;, &quot;'.$tipo.'&quot;, &quot;'.$positivos.'&quot;, &quot;'.$negativos.'&quot;)">';
                              // Se comprueba si había dado dislike al comentario para poner el color correspondiente
                              $consultaMGC = compruebaMeGustaCom($com[0], $usuario, $tipo);
                              if($consultaMGC) {
                                if(mysqli_num_rows($consultaMGC)==0) {
                                  echo '<img class="rateCom" src="img/negative-black.png" alt="negativo" id="negativoC"></button>';  
                                }
                                else {
                                  $filaMG = mysqli_fetch_row($consultaMGC);
                                  if($filaMG[2]==1) {
                                    echo '<img class="rateCom" src="img/negative-black.png" alt="negativo" id="negativoC"></button>';
                                  }
                                  else {
                                    echo '<img class="rateCom" src="img/negative-red.png" alt="negativo" id="negativoC"></button>';  
                                  }
                                }
                              }
                              else {
                                echo '<img class="rateCom" src="img/negative-black.png" alt="negativo" id="negativoC"></button>';
                              }
                              
                            
          print'             <span class="voto" id="' . $negativos . '">' . $com[5] . '</span>
                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-9">
                      <p>' . $com[3] . '</p>
                    </div>
                  </div>';
        }
      }
    ?>

    <!-- PAGINACION -->
    <?php
     if(mysqli_num_rows($comentarios)!=0) {
       if ($total_paginas > 1)
                {
                  echo '<ul class="pagination ">';
                  if ($pagina != 1)
                    echo '<li><a href="opinion.php?idopinion='. $idopinion .'&pagina='.($pagina-1).'">&laquo;</a></li>';
                    for ($i=1;$i<=$total_paginas;$i++) {
                       if ($pagina == $i)
                          //si muestro el índice de la página actual, no coloco enlace
                          echo "<li class='active'><a href='#'>". $pagina . "</a></li>";
                       else
                          //si el índice no corresponde con la página mostrada actualmente,
                          //coloco el enlace para ir a esa página
                          echo '  <li><a href="opinion.php?idopinion='. $idopinion .'&pagina='.$i.'">'.$i.'</a></li>  ';
                    }
                    if ($pagina != $total_paginas)
                    {
                       echo '<li><a href="opinion.php?idopinion='. $idopinion .'&pagina='.($pagina+1).'">&raquo;</a></li>';
                     }
                     echo '</ul>';
              }
     } 

    ?>

    <!-- FORMULARIO PARA COMENTAR -->
    <?php
      if($usuario == "visitante") {
        echo '<div class="row">
                <div class="col-lg-12">
                  <p class="alertvisitante"> Para poder comentar tienes que estar registrado </p> 
                </div>
              </div>';
      }
      else {
        echo '<div class="row row-form-comentar">
                <div class="col-lg-12">
                  <p><a class="btn btn-primary collapsed" data-target="#form-comentar" data-toggle="collapse" aria-expanded="false">Comentar »</a></p>
                </div>
              </div>
              <div class="row collapse" id="form-comentar">
                <div class="col-lg-6 col-lg-offset-3">
                  <form action="comentarOpinion.php?idopinion=' . $idopinion . '" method="post">
                    <textarea class="coment-text" name="coment-text"></textarea>  
                    <button class="btn btn-primary btn-block btn-md">Publicar comentario</button>
                  </form>
                </div>
              </div>';
       }
    ?>
    
    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?>
    
  </div>
</body>
</html>