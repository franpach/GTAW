<?php

  if(isset($_SESSION['nombre'])) {
  	$usuario = $_SESSION['nombre'];
    $consulta = admin($usuario);
      if($consulta) {
        $fila = mysqli_fetch_row($consulta);
        $admin = $fila[0];
        if($fila[0]==0) {
        	include 'menuUsuario.php';
        } 
        else {
        	include 'menuAdmin.php';
        }
      }
      else include 'menuUsuario.php';
  }
  else {
    include 'menuVisitante.php';
  }
?>