<?php
	if((include 'dbconnect.php')==FALSE) {
      header('Location: paginaerror.php');
    }
    if((include 'database.php')==FALSE) {
      header('Location: paginaerror.php');
    }

	$tema = htmlspecialchars(trim(strip_tags($_GET['tema'])));
	$mensaje = htmlspecialchars(trim(strip_tags($_GET['idmensaje'])));
	$motivo = htmlspecialchars(trim(strip_tags($_GET['motivo'])));

	$insert = insertReporte($mensaje, $motivo); 	
?>