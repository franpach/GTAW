<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>Lanzamientos</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="bootstrap/css/juegos.css" rel="stylesheet">
  <link rel="stylesheet" href="bootstrap/css/header.css">

  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>
  <!-- Funcionalidad de la página -->
  <script src="bootstrap/js/funcionalidad.js"></script>
</head>
<body>
  <?php
    if((include 'database.php')==FALSE) {
      header('Location: paginaerror.php');
    }

    session_start();
    if(isset($_SESSION['nombre'])) {
      $usuario = $_SESSION['nombre'];
    }
    else $usuario = "visitante";
      
    $lanzamientos = sacaLanzamientos();
    if(mysqli_num_rows($lanzamientos)==0) $noLanz = true;
    else $noLanz = false;
  ?>
  <div class="container">

    <!-- CABECERA -->
    <?php
      include 'menu.php';
    ?>

    <!-- LINKS -->
    <div class="row links">
      <div class="col-lg-12">
        <a href="main.php" >Inicio</a> / <a href="lanzamientos.php" >Próximos lanzamientos</a> 
      </div>
    </div>

    <!-- TÍTULO -->
    <div class="row">
      <div class="col-lg-12">
        <h1>Próximos lanzamientos</h1>
      </div>
    </div>

    <!-- LISTA LANZAMIENTOS -->
    <?php
      if($noLanz) {
        echo '<div class="row">
                <div class="col-lg-12">
                  <p class="lead">Vaya, parece que en nuestra base de datos no tenemos lanzamientos registrados. ¿Conoces alguno? Cuéntanoslo <a href="contacto.html">aquí</a>.</p>
                </div>
              </div>';
      }
      else {

        $num_total = mysqli_num_rows($lanzamientos);
        $tamano_pagina = 5;
        $pagina=0;
        if(isset($_GET["pagina"])){
            $pagina = $_GET["pagina"];
          }
        if(!$pagina){
              $inicio=0;
              $pagina=1;
             }
        else{
              $inicio = ($pagina - 1) * $tamano_pagina;
            }
        $total_paginas = ceil($num_total / $tamano_pagina);
        $lanzamientos = dividirLanzamientos($inicio,$tamano_pagina);
       
        while($lan = mysqli_fetch_row($lanzamientos)) {
          echo '<div class="row game">
                  <div class="col-lg-2">
                    <img class="portada" src="' . $lan[4] . '"
                    alt="portada no disponible" width=100 height=130>
                  </div>
                  <div class="col-lg-2">
                    <h3 class="game-title"><a href="lanzamiento.php?lanzamiento=' . $lan[0] . '">' . $lan[0] . '</a></h3>
                    <p> 
                      A la venta: ' . $lan[1] . '<br>
                      Plataformas: ' . $lan[2] . ' <br>
                      Género: ' . $lan[3] . '
                    </p>
                  </div>
                  <div class="col-lg-8">
                    <p> ' . $lan[5] . ' </p>
                  </div>
                </div>';
        }
      }
    ?>

    <!-- PAGINACION -->
    <?php
     if(mysqli_num_rows($lanzamientos)!=0) {
       if ($total_paginas > 1)
                {
                  echo '<ul class="pagination ">';
                  if ($pagina != 1)
                    echo '<li><a href="lanzamientos.php?pagina='.($pagina-1).'">&laquo;</a></li>';
                    for ($i=1;$i<=$total_paginas;$i++) {
                       if ($pagina == $i)
                          //si muestro el índice de la página actual, no coloco enlace
                          echo "<li class='active'><a href='#'>". $pagina . "</a></li>";
                       else
                          //si el índice no corresponde con la página mostrada actualmente,
                          //coloco el enlace para ir a esa página
                          echo '  <li><a href="lanzamientos.php?pagina='.$i.'">'.$i.'</a></li>  ';
                    }
                    if ($pagina != $total_paginas)
                    {
                       echo '<li><a href="lanzamientos.php?pagina='.($pagina+1).'">&raquo;</a></li>';
                     }
                     echo '</ul>';
              }
     } 

    ?>

    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?> 

  </div>
</body>
</html>