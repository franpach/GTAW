<?php
	if((include 'dbconnect.php')==FALSE) {
      header('Location: paginaerror.php');
    }
	if((include 'database.php')==FALSE) {
      header('Location: paginaerror.php');
    }
	
	$nombre = htmlspecialchars(trim(strip_tags($_POST['nombre'])));
	$descripcion = htmlspecialchars(trim(strip_tags($_POST['descripcion'])));
	$plataforma = htmlspecialchars(trim(strip_tags($_POST['plataforma'])));
	$genero = htmlspecialchars(trim(strip_tags($_POST['genero'])));
	$idioma = htmlspecialchars(trim(strip_tags($_POST['idioma'])));
	$duracion = htmlspecialchars(trim(strip_tags($_POST['duracion'])));
	$pegi = htmlspecialchars(trim(strip_tags($_POST['pegi'])));
	$jugadores = htmlspecialchars(trim(strip_tags($_POST['jugadores'])));
	$trailer = htmlspecialchars(trim(strip_tags($_POST['trailer'])));
	$fecha = htmlspecialchars(trim(strip_tags($_POST['fecha'])));

	// PORTADA
	$target_dir = $_FILES["portada"]["tmp_name"]; // guardamos el nombre temporal
	$name = $_FILES["portada"]["name"]; // guardamos el nombre del archivo subido

	if(isset($_POST["submit"])) {
		$portada = "img/".$name; // creamos el nombre de archivo que se quiere almacenar
	    move_uploaded_file($target_dir, $portada); // almacenamos en la carpeta la nueva imagen
	}

	$insert = nuevoJuego($nombre, $descripcion, $plataforma, $genero, $idioma, $duracion, $pegi, $jugadores, $trailer, $portada, $fecha);
	header('Location: pagadministrador.php');
?>