<?php
	if((include 'dbconnect.php')==FALSE) {
      header('Location: paginaerror.php');
    }
    if((include 'database.php')==FALSE) {
      header('Location: paginaerror.php');
    }

	$nombre = htmlspecialchars(trim(strip_tags($_POST['nombre'])));
	$correo = htmlspecialchars(trim(strip_tags($_POST['correo'])));
	$motivo = htmlspecialchars(trim(strip_tags($_POST['consulta'])));
	$texto = htmlspecialchars(trim(strip_tags($_POST['texto'])));

	$insert = nuevoContacto($nombre, $correo, $motivo, $texto);
	header('Location: contacto.php')

?>
