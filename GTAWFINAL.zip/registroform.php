<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>GTAW - Registro</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="bootstrap/css/registro.css" rel="stylesheet">

  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
  <script src="js/bootstrap.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

</head>
<body>
  
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
        <?php
          if((include 'database.php')==FALSE) {
            header('Location: paginaerror.php');
          }
          $nombre = htmlspecialchars(trim(strip_tags($_POST['Nombre'])));
          $corr = htmlspecialchars(trim(strip_tags($_POST['Email'])));
          $contr = htmlspecialchars(trim(strip_tags($_POST['Contraseña'])));
          
          $consulta = compruebaUsu($nombre);
          if(mysqli_num_rows($consulta)==0) {
            $insert = regisUsu($nombre,$contr,$corr);
            if ($insert) {  
              session_start();
              $_SESSION['nombre']=$nombre;
              print   '<form method="post" action="registro2.php" enctype="multipart/form-data">
                        <h2>¡Completa tus datos!</h2>
                        <div class="form-group">
                          <textarea  name="Biografia" id="infor" class="form-control" placeholder="Escribe información sobre ti" ></textarea>
                        </div>
                        <div class="row">
                          <div class="col-xs-6 col-sm-6 col-md-6">
                            <div class="form-group">
                              <input type="file" name="foto" id="foto">
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-xs-6  col-md-6">
                            <input type="submit" name="submit" value="Finalizar" class="btn btn-primary btn-block btn-lg" >
                          </div>
                          <div class="col-xs-6 col-md-6">
                            <a href="main.php" class="btn btn-primary btn-block btn-lg">Rellenar más tarde</a>
                          </div>
                        </div>
                      </form>';
            }
          }
          else {
            print '<p> El usuario que has introducido ya existe en nuestra página</p><br>
                     <a href="registro.php">Vuelve a la página de registro para intentarlo de nuevo.</a>';
          }
        ?>
      </div>
    </div>
    
    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?>
  </div>

</body>
</html>
