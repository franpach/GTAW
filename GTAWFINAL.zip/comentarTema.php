<?php
	if((include 'dbconnect.php')==FALSE) {
      header('Location: paginaerror.php');
    }
    if((include 'database.php')==FALSE) {
      header('Location: paginaerror.php');
    }

	session_start();
	$usuario = $_SESSION['nombre'];

	$idtema = $_GET["tema"];
	$comentario = htmlspecialchars(trim(strip_tags($_POST['comentario'])));

	$insert = mensajeForo($idtema, $usuario, $comentario);
	if(!$insert) {
		echo "mal";
	}
	else {
		//También se actualiza la fecha del último mensaje del tema
		$act = actualizaUltimaFechaTema($idtema);
		header("Location: mensaje.php?idTema=$idtema");
	}
?>