<?php
	require 'dbconnect.php';
	require 'database.php';
	
	$nombre = htmlspecialchars(trim(strip_tags($_POST['nombreL'])));
	$descripcion = htmlspecialchars(trim(strip_tags($_POST['descripcionL'])));
	$plataforma = htmlspecialchars(trim(strip_tags($_POST['plataformaL'])));
	$genero = htmlspecialchars(trim(strip_tags($_POST['generoL'])));
	$idioma = htmlspecialchars(trim(strip_tags($_POST['idiomaL'])));
	$duracion = htmlspecialchars(trim(strip_tags($_POST['duracionL'])));
	$pegi = htmlspecialchars(trim(strip_tags($_POST['pegiL'])));
	$jugadores = htmlspecialchars(trim(strip_tags($_POST['jugadoresL'])));
	$trailer = htmlspecialchars(trim(strip_tags($_POST['trailerL'])));
	$fecha = htmlspecialchars(trim(strip_tags($_POST['fechaL'])));

	// PORTADA
	$target_dir = $_FILES["portadaL"]["tmp_name"]; // guardamos el nombre temporal
	$name = $_FILES["portadaL"]["name"]; // guardamos el nombre del archivo subido

	if(isset($_POST["submitL"])) {
		$portada = "img/".$name; // creamos el nombre de archivo que se quiere almacenar
	    move_uploaded_file($target_dir, $portada); // almacenamos en la carpeta la nueva imagen
	}

	$insert = nuevoLanzamiento($nombre, $descripcion, $plataforma, $genero, $idioma, $duracion, $pegi, $jugadores, $trailer, $portada, $fecha);
	header('Location: pagadministrador.php');
?>