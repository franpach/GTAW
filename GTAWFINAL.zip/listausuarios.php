<?php
	require 'database.php';
	$usuario = $_GET["usuario"];

	//comprueba que hay un usuario en la base de datos
	$comprueba = sacarUsuario($usuario);
	if (mysqli_num_rows($comprueba)==0) {
		echo "nombre disponible. ¡Cógelo si quieres!";
	}
	else {
		echo "lo sentimos, ese nombre de usuario ya está seleccionado";
	}
?>