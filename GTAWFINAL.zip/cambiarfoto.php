<?php
	if((include 'dbconnect.php')==FALSE) {
      header('Location: paginaerror.php');
    }
    if((include 'database.php')==FALSE) {
      header('Location: paginaerror.php');
    }
	session_start();
	$user = $_SESSION["nombre"];

	$target_dir = $_FILES["foto"]["tmp_name"]; // guardamos el nombre temporal
	$name = $_FILES["foto"]["name"]; // guardamos el nombre del archivo subido

	if(isset($_POST["submit"])) {
		$newlocation = "img/users/".$name; // creamos el nombre de archivo que se quiere almacenar
	    move_uploaded_file($target_dir, $newlocation); // almacenamos en la carpeta la nueva imagen
	}

	$insert = cambiarFoto($user, $newlocation);
	
	header("Location: usuario.php?usuario=$user"); 
?>