<?php
	require 'dbconnect.php';
	require 'database.php';
	session_start();
	$nombre = $_SESSION['nombre']; 

	$biografia = htmlspecialchars(trim(strip_tags($_POST['Biografia'])));

	$target_dir = $_FILES["foto"]["tmp_name"]; // guardamos el nombre temporal
	$name = $_FILES["foto"]["name"]; // guardamos el nombre del archivo subido

	if(isset($_POST["submit"])) {
		$newlocation = "img/users/".$name; // creamos el nombre de archivo que se quiere almacenar
	    move_uploaded_file($target_dir, $newlocation); // almacenamos en la carpeta la nueva imagen
	}

	$result = actUser($nombre, $biografia, $newlocation); 
	if($result) {
		header('Location: main.php');
	}
		


?>