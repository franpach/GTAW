<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>GTAW - Login</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="bootstrap/css/registro.css" rel="stylesheet">

  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]--> 

  <script src='https://www.google.com/recaptcha/api.js'></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
  <script src="js/bootstrap.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  <!-- Funcionalidad de la página -->
  <script type="text/javascript" src="bootstrap/js/funcionalidad.js"></script>
</head>
<body>

  <div class="container">

    <!-- LOGIN -->
    <div class="row">
      <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
        <form method="post" action="loginform.php">
          <h2>Iniciar sesión</h2>
          <div class="form-group">
            <input type="text" name="usuario" id="Correo" class="form-control input-lg" placeholder="Usuario" required>
            <img src="img/correct.png" id="correoCorrecto" alt="correcto">
            <img src="img/incorrect.png" id="correoIncorrecto" alt="incorrecto">
          </div>
          <div class="form-group">
            <input type="password" name="Contraseña" id="email" class="form-control input-lg" placeholder="Contraseña" required>
          </div>
          <div class="row">
            <div class="col-xs-6 col-md-3">
              <input type="submit" value="Loguéate" class="btn btn-primary btn-block btn-lg" required>
            </div>
          </div>
        </form>
        
        <hr>
        <p>¿No tienes cuenta?. Crea una, es sencillo.</p>
        <div class="col-xs-7 col-md-5">
          <a href="registro.php" class="btn btn-primary btn-block btn-lg">Crear cuenta</a>
        </div>
        <br><br>
        <hr>
        <p>O puedes seguir visitando la página sin estar logueado</p>
          <div class="col-xs-7 col-md-5">
            <a href="main.php" class="btn btn-primary btn-block btn-lg">Volver</a>
        </div>
      </div>
    </div>

    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?>
     
 </div>
</body>
</html>

