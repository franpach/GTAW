<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>GTAW - Registro</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- Custom styles for this template -->
 
  <link rel="stylesheet" href="bootstrap/css/registro.css" />
  <link rel="stylesheet" href="bootstrap/css/bootstrap-theme.css" />

  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
  <script src="js/bootstrap.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  <!-- Funcionalidad de la página -->
  <script type="text/javascript" src="bootstrap/js/funcionalidad.js"></script>

</head>
<body>

  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
        <form method="post" action="registroform.php">
          <h2>¡Únete, es gratis!</h2>
          <div class="form-group">
            <input type="text" name="Nombre" id="Nombre" class="form-control input-lg" placeholder="Nombre" onKeyUp="compruebaUser('Nombre')" required>
             <span class="selected" id="selected"></span>
          </div>
          <div class="form-group">
            <input type="email" name="Email" id="email" class="form-control input-lg" placeholder="Dirección de Email"  onKeyUp="validateMail('email')" required>
            <img src="img/correct.png" id="correoCorrecto" alt="correcto">
            <img src="img/incorrect.png" id="correoIncorrecto" alt="incorrecto">
          </div>
          <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6">
              <div class="form-group">
                <input type="password" name="Contraseña" id="Contraseña" class="form-control input-lg" placeholder="Contraseña" required>
              </div>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6">
              <div class="form-group">
                <input type="password" name="conf-contraseña" id="conf-contraseña" class="form-control input-lg" placeholder="Confirma Contraseña" onKeyUp="validatePass('conf-contraseña','Contraseña') required">
                <img src="img/correct.png"   id="pwdCorrecto" alt="correcto">
			          <img src="img/incorrect.png"  id="pwdIncorrecto" alt="incorrecto"><br>
              </div>
		        </div>
          </div>
          <div class="row">
            <div class="col-xs-6 col-md-3">
              <input type="submit" value="Regístrate" class="btn btn-primary btn-block btn-lg" >
            </div>
          </div>
        </form>
      </div>
    </div>
    <div class="row">
      <div class="col-xs-6 col-md-3 col-lg-offset-3">
        <p> Si ya tienes una cuenta, loguéate aquí. </p>
        <a href="login.php" class="btn btn-primary btn-block btn-lg">Loguéate</a> 
      </div>
      <div class="col-xs-6 col-md-3">
        <p> O si lo prefieres, navega como visitante. Pero recuerda, no dispondrás de las ventajas con las que cuentan los usuarios registrados. </p>
        <a href="main.php" class="btn btn-primary btn-block btn-lg">Ir a GTAW</a> 
      </div>
    </div>

    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?> 
  </div>
</body>
</html>