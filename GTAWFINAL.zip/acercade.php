<!DOCTYPE html>
<html lang="es">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<meta name="description" content="">
<meta name="author" content="">
<link rel="icon" href="http://getbootstrap.com/favicon.ico">

<title>Acerca de</title>

<!-- Bootstrap core CSS -->
<link href="bootstrap/css/bootstrap.css" rel="stylesheet">

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

<!-- CSS -->
<link rel="stylesheet" href="bootstrap/css/header.css"> <!-- Cabecera, footer, links y título -->
<link rel="stylesheet" href="bootstrap/css/textos-juego.css"> <!-- Display informacion de juego -->

<!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
<!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
<script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>
<!-- Funcionalidad de la página -->
<script type="text/javascript" src="bootstrap/js/funcionalidad.js"></script>
</head>

<body>
  <?php
     if(!include 'database.php') {
      header('Location: paginaerror.php');
    }

    session_start();
    if(isset($_SESSION['nombre'])) {
      $usuario = $_SESSION['nombre'];
    }
    else $usuario = "visitante";
  ?>
  <div class="container">

  <!-- CABECERA -->
    <?php
      include 'menu.php';
    ?>  
  
  <!-- LINKS -->
  <div class="row links">
    <div class="col-lg-12">
      <a href="main.php" >Inicio</a> / <a href="acercade.php">¿Quiénes somos?</a> 
    </div>
  </div>

  <!-- TÍTULO -->
  <div class="row">
    <div class="col-lg-12">
      <h1 class="titulo"> ¿Quiénes somos? </h1>
    </div>
  </div>

  <!-- COMPONENTES -->
  <div class="row">
    <div class="col-lg-12">
      <p class="lead"> Esta página web es un proyecto para la asignatura Aplicaciones Web, impartida en la Facultad de Informática
        de la Universidad Complutense de Madrid. ¡Conócenos!</p>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-3">
        <h2>Francisco Javier Pacheco Herranz</h2>
        <p> Correo: franpach@ucm.es </p>
        <p class="texto-justificado"> Disfruto con la música, los videojuegos, la lectura y el fútbol. Me gusta aprender algo nuevo todos los días. Amante de la gente de verdad, de mi familia y de mis amigos. </p>
      </div>
      <div class="col-lg-3">
        <h2>David Limón Miralles</h2>
        <p> Correo: dalimon@ucm.es </p>
        <p class="texto-justificado"> Pasión por el deporte, pricipalmente el fútbol. Demasiado gusto por las series y el cine. Intento estar lo más actualizado posible en los avances tecnológicos pero siempre es buen momento para disfrutar con los amigos. </p>
      </div>
      <div class="col-lg-3">
        <h2>Manuel Martín Canora</h2>
        <p> Correo: manuem07@ucm.es </p>
        <p class="texto-justificado"> Amante del deporte en general, pero sobre todo del fútbol del baloncesto y del tenis. Me encanta leer además de los videojuegos y la tecnología. Además disfruto viajando y conociendo nuevos lugares. </p>
      </div>
      <div class="col-lg-3">
        <h2>Javier Romero Pérez</h2>
        <p> Correo: javrom01@ucm.es </p>
        <p class="texto-justificado"> Aficionado de los videojuegos e interés por las series. Tengo interés por mantenerme informado de los avances tecnológicos. </p>
      </div>
    </div>

    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?>

  </div>
</body>
</html>