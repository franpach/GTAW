<?php
	if((include 'dbconnect.php')==FALSE) {
      header('Location: paginaerror.php');
    }
    if((include 'database.php')==FALSE) {
      header('Location: paginaerror.php');
    }

	$titulo = htmlspecialchars(trim(strip_tags($_POST['titulo'])));
	$contenido = htmlspecialchars(trim(strip_tags($_POST['contenido'])));
	
	session_start();
	$usuario = $_SESSION['nombre'];

	$insert = insertarTema($titulo, $usuario, $contenido);
	if(!$insert) {
		echo "mal";
	}
	else header("Location: foro.php");

?>