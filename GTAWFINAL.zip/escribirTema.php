<?php
	require 'dbconnect.php';
	require 'database.php';

	$titulo = htmlspecialchars(trim(strip_tags($_POST['titulo'])));
	$contenido = htmlspecialchars(trim(strip_tags($_POST['contenido'])));
	
	session_start();
	$usuario = $_SESSION['nombre'];

	$insert = insertarTema($titulo, $usuario, $contenido);
	if(!$insert) {
		echo "mal";
	}
	else header("Location: foro.php");

?>