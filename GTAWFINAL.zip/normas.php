<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>Normas</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- CSS -->
  <link rel="stylesheet" href="bootstrap/css/header.css"> <!-- Cabecera, footer, links y título -->
  <link rel="stylesheet" href="bootstrap/css/textos-juego.css"> <!-- Textos -->

  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>
  <!-- Funcionalidad de la página -->
  <script type="text/javascript" src="bootstrap/js/funcionalidad.js"></script>

</head>

<body>

  <?php
    if((include 'database.php')==FALSE) {
      header('Location: paginaerror.php');
    }
  
    session_start();
    if(isset($_SESSION['nombre'])) {
      $usuario = $_SESSION['nombre'];
    }
    else $usuario = "visitante";
  ?>  

  <div class="container">

    <!-- CABECERA -->
    <?php
      include 'menu.php';
    ?>

    <!-- LINKS -->
    <div class="row links">
      <div class="col-lg-12">
        <a href="main.php" >Inicio</a> / <a href="normas.php">Normas</a> 
      </div>
    </div>

    <!-- TITULO -->
    <div class="row">
      <div class="col-lg-12">
        <h1 class="titulo"> Normas de la comunidad </h1>
      </div>
    </div>

    <!-- NORMAS -->
    <div class="row">
      <div class="col-lg-12">
        <p class="lead justificado"> Hola. Deseamos que nuestros usuarios aporten tanto contenido como quieran. También queremos que comenten los
        aportes de otros usuarios, que dialoguen y disfruten aportando su visión de este mundo. Sin embargo, nos gustaría que el
        ambiente aquí fuese idóneo o, en su defecto, aceptable. Por ello, revisaremos todo contenido aportado a la web y eliminaremos
        aquello que no cuadre con las normas expuestas a continuación. Gracias por entendernos. </p>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12">
        <ul class="texto-borde-negro texto-justificado texto-padding-grande">
          <li>Un artículo debe de estar relacionado con el juego que se referencia. No se puede realizar un artículo que se indique que es acerca del videojuego "Dark Souls" para posteriormente tratar un tema totalmente distinto, a excepción de que dicho tema guarde relación con el videojuego referenciado y, además, sean menciones puntuales y que tengan sentido. </li>
          <li> Un artículo debe de cumplir unos mínimos de ortografía y redacción. Un artículo inenteligible será descartado y eliminado por los moderadores. También deberá tener un mínimo de longitud; un artículo cuya totalidad del cuerpo sea, por ejemplo, "me ha gustado", también será eliminado.
          Un artículo no puede contener lenguaje soez, ni insultos ni demás contenido que pueda resultar hiriente hacia otros usuarios. Se eliminarán artículos que realicen comentarios xenófobos, homófobos, antisemitas, etc. </li>
          <li> Un comentario no puede contener lenguaje soez, ni insultos ni demás contenido que pueda resultar hiriente hacia otros usuarios, al igual que sucede con los artículos. Tampoco puede contener mensajes de spam. </li>
        </ul>
      </div>
    </div>

    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?>

  </div> <!-- /container --> 

</body>
</html>