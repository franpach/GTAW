<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>Juegos</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- CSS -->
  <link rel="stylesheet" href="bootstrap/css/header.css"> <!-- Cabecera, footer, links y título -->
  <link rel="stylesheet" href="bootstrap/css/textos-juego.css"> <!-- Display informacion de juego -->
  <link rel="stylesheet" href="bootstrap/css/listas.css"> <!-- Display de listas -->
  <link href="bootstrap/css/infoarticulo.css" rel="stylesheet"> <!--- Display artículo -->

  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>
  <!-- Funcionalidad de la página -->
  <script src="bootstrap/js/funcionalidad.js"></script>
</head>
<body>
  <?php
    if((include 'database.php')==FALSE) {
      header('Location: paginaerror.php');
    }

    session_start();
    if(isset($_SESSION['nombre'])) {
      $usuario = $_SESSION['nombre'];
    }
    else $usuario = "visitante";

    if (isset($_GET["genero"])) {
      $genero = $_GET["genero"];
      $lista = listaJuegos($genero);
      if($lista) {
        if(mysqli_num_rows($lista)==0) $noJuegos = true;
        else $noJuegos = false;   
      }
      else $noJuegos = true;
    }
    else {
      $genero= "cualquiera";
      $lista = listaJuegos("cualquiera");
      if($lista) {
        if(mysqli_num_rows($lista)==0) $noJuegos = true;
        else $noJuegos = false;  
      }
      else $noJuegos = true;
    }
  ?>

  <div class="container">
     
    <!-- CABECERA -->
    <?php
      include 'menu.php';
    ?>

    <!-- LINKS -->
    <div class="row links">
      <div class="col-lg-12">
        <a href="main.php" >Inicio</a> / <a href="juegos.php" >Juegos</a>
      </div>
    </div>

    <!-- TITULO -->
    <div class="row">
      <div class="col-lg-12">
        <?php
        if($genero=="cualquiera") {
          echo '<h1 class="titulo">Juegos</h1>';
        }
        else {
          echo '<h1 class="titulo">Juegos de ' . $genero . '</h1>';
        }
        ?>
      </div>
    </div> 

    <!-- JUEGOS -->
    <?php
      if($noJuegos) {
        print   '<div class="row">
                  <div class="col-lg-12">
                    <p class="lead"> Vaya, parece que no tenemos registrados juegos para este género. ¿Conoces alguno? Cuéntanoslo <a href="contacto.html">aquí</a>.</p>
                  </div>
                </div>';
      }
      else {
        $num_total = mysqli_num_rows($lista);
        $tamano_pagina = 5;
        $pagina=0;
        if(isset($_GET["pagina"])){
            $pagina = $_GET["pagina"];
          }
        if(!$pagina){
              $inicio=0;
              $pagina=1;
             }
        else{
              $inicio = ($pagina - 1) * $tamano_pagina;
            }
        $total_paginas = ceil($num_total / $tamano_pagina);
        $lista = dividirJuegos($genero,$inicio,$tamano_pagina);
       
        while($juego = mysqli_fetch_row($lista)) {
        print '<div class="row row-game">
                  <div class="col-lg-2">
                    <img class="portada" src="' . $juego[1] . '"
                      alt="portada no disponible" width=100 height=130>
                  </div>
                  <div class="col-lg-2">
                    <h3 class="game-title"><a href="juego.php?juego=' . $juego[0] . '">' . $juego[0] . '</a></h3>
                    <p>
                      A la venta: ' . $juego[2] . '<br>
                      Plataformas: ' . $juego[3] . '<br>
                      Género: ' . $juego[4] . '
                    </p>
                  </div>
                  <div class="col-lg-6">
                    <p class="texto-desc-juego texto-grande texto-scroll texto-padding-mediano texto-justificado">' . $juego[5] . '</p>
                  </div>
                  <div class="col-lg-2">
                    <p class="nota-grande-art">' . $juego[6] . '</p>
                  </div>
                </div>';
      }
      }
    ?>

     <!-- PAGINACION -->
    <?php
     if(mysqli_num_rows($lista)!=0) {
       if ($total_paginas > 1)
                {
                  echo '<ul class="pagination ">';
                  if ($pagina != 1)
                    echo '<li><a href="juegos.php?genero='. $genero .'&pagina='.($pagina-1).'">&laquo;</a></li>';
                    for ($i=1;$i<=$total_paginas;$i++) {
                       if ($pagina == $i)
                          //si muestro el índice de la página actual, no coloco enlace
                          echo "<li class='active'><a href='#'>". $pagina . "</a></li>";
                       else
                          //si el índice no corresponde con la página mostrada actualmente,
                          //coloco el enlace para ir a esa página
                          echo '  <li><a href="juegos.php?genero='. $genero .'&pagina='.$i.'">'.$i.'</a></li>  ';
                    }
                    if ($pagina != $total_paginas)
                    {
                       echo '<li><a href="juegos.php?genero='. $genero .'&pagina='.($pagina+1).'">&raquo;</a></li>';
                     }
                     echo '</ul>';
              }
     } 

    ?>

    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?>


  </div>
</body>
</html>