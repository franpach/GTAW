<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>Análisis</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- CSS -->
  <link rel="stylesheet" href="bootstrap/css/header.css"> <!-- Cabecera, footer, links y título -->
  <link rel="stylesheet" href="bootstrap/css/textos-juego.css"> <!-- Display informacion de juego -->
  <link href="bootstrap/css/infoarticulo.css" rel="stylesheet"> <!--- Display artículo -->
  <link rel="stylesheet" href="bootstrap/css/listas.css">  <!-- Display usuario -->
  <link rel="stylesheet" href="bootstrap/css/votos.css">  <!-- Display de botones para votar artículos y comentarios -->

  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>
  <!-- Funcionalidad de la página -->
  <script src="bootstrap/js/funcionalidad.js"></script>
</head>
<body>
	<?php
		if((include 'database.php')==FALSE) {
     		header('Location: paginaerror.php');
    	}

	    session_start();
	    if(isset($_SESSION['nombre'])) {
	      $usuario = $_SESSION['nombre'];
	    }
	    else $usuario = "visitante";

	    $lista = sacarAnalisis(10);
	    if($lista) {
	    	if(mysqli_num_rows($lista)==0) $noAnal = true;
	    	else $noAnal = false;
	    } 
	    else $noAnal = true;
	?>
	
	<div class="container">
	
		<!-- CABECERA -->
	    <?php
	      include 'menu.php';
	    ?>

	    <!-- LINKS -->
	    <div class="row links">
	      <div class="col-lg-12">
	        <a href="main.php" >Inicio</a> / <a href="ultimosanalisis.php" >Los últimos análisis</a> 
	      </div>
	    </div>

	    <!-- TITULO -->
	    <div class="row">
	    	<div class="col-lg-12">
	        	<h1 class="titulo">Últimos análisis</h1>
	        </div>
	    </div>

	    <!-- LISTA -->
	    <?php
	    	if($noAnal) {
	    		print '<div class="row">
	    					<div class="col-lg-12 nolista">
	    						<p> Vaya, parece que nadie ha escrito ningún para análisis. </p>
	    					</div>
	    				</div>';
	    	}
	    	else {
	    		$tipo = "analisis";
	    		$i = 0;
	    		while($analisis = mysqli_fetch_row($lista)) {
	    			$positivos = "positivo".$i;
	    			$negativos = "negativo".$i;
	    			$botonPos = "positivoB".$i;
	    			$botonNeg = "negativoB".$i;
	    			$i = $i + 1;	
	    			print ' <div class="row row-art-titulo">
          						<div class="col-lg-10">
					            	<h3 class="expand"> Análisis de <a href="usuario.php?usuario=' . $analisis[0] . '">' . $analisis[0] . '</a>: <a href="analisis.php?idanalisis=' . $analisis[6] . '">' . $analisis[3] . '</a> </h3>
					         	</div>
					    	</div>
					        <div class="row row-art-contenido">
					          <div class="col-lg-10">
					            <p class="texto-borde-gris texto-mediano texto-scroll">' . $analisis[2] . '</p>
					          </div>
					          <div class="col-lg-2">
					            <div class="row btn-rate">
					              <div class="col-lg-12 puntuacion-art-lista">
					                <span class="voto" id="' . $positivos . '">' . $analisis[4] . '</span> 
					               <button type="button" class="btn-rate positive" value="sumar" onClick="votoPosArt(&quot;'.$usuario.'&quot;, &quot;'.$analisis[6].'&quot;, &quot;'.$tipo.'&quot;, &quot;'.$positivos.'&quot;, &quot;'.$negativos.'&quot;, &quot;'.$botonPos.'&quot;, &quot;'.$botonNeg.'&quot;)">';

					               		// COLORES BOTONES
					                	
						                $consultaVoto = compruebaMeGustaArt($analisis[6], $usuario, 'analisis');
						                if($consultaVoto) {
						                  if(mysqli_num_rows($consultaVoto)==0) {
						                    echo '<img class="rateArt" src="img/positive-black.png" alt="positivo" id="' . $botonPos . '"></button><br>';  
						                  }
						                  else {
						                    $filaMG = mysqli_fetch_row($consultaVoto);
						                    if($filaMG[2]==1) {
						                      echo '<img class="rateArt" src="img/positive-green.png" alt="positivo" id="' . $botonPos . '"></button><br>';
						                    }
						                    else {
						                      echo '<img class="rateArt" src="img/positive-black.png" alt="positivo" id="' . $botonPos . '"></button><br>';  
						                    }
						                  }
						                }
						                else {
						                  echo '<img class="rateArt" src="img/positive-black.png" alt="positivo" id="' . $botonPos . '"></button><br>';
						               	}

					print'			</div>
					            </div>
					            <div class="row btn-rate">
					              <div class="col-lg-12 puntuacion-art-lista">
					                <span class="voto" id="' . $negativos . '">' . $analisis[5] . '</span> 
					                <button type="button" class="btn-rate positive" value="sumar" onClick="votoNegArt(&quot;'.$usuario.'&quot;, &quot;'.$analisis[6].'&quot;, &quot;'.$tipo.'&quot;, &quot;'.$positivos.'&quot;, &quot;'.$negativos.'&quot;, &quot;'.$botonPos.'&quot;, &quot;'.$botonNeg.'&quot;)">';

					                	// COLORES BOTONES
					                	$consultaVoto = compruebaMeGustaArt($analisis[6], $usuario, 'analisis');
						                if($consultaVoto) {
						                  if(mysqli_num_rows($consultaVoto)==0) {
						                    echo '<img class="rateArt" src="img/negative-black.png" alt="negativo" id="' . $botonNeg . '"></button><br>';  
						                  }
						                  else {
						                    $filaMG = mysqli_fetch_row($consultaVoto);
						                    if($filaMG[2]==1) {
						                      echo '<img class="rateArt" src="img/negative-black.png" alt="negativo" id="' . $botonNeg . '"></button><br>';
						                    }
						                    else {
						                      echo '<img class="rateArt" src="img/negative-red.png" alt="negativo" id="' . $botonNeg . '"></button><br>';  
						                    }
						                  }
						                }
						                else {
						                  echo '<img class="rateArt" src="img/negative-black.png" alt="negativo" id="' . $botonNeg . '"></button><br>';
						                }

					print'			</div>
					            </div>
					            </div>
					        	<div class="row row-juego">
					        		<div class="col-lg-10">
					        			<p>Para el juego: <a href="juego.php?juego=' . $analisis[1] . '"> ' . $analisis[1] . ' </a></p>
					        		</div>
					        	</div>	
					          </div>
					          ';

	    		}	
	    	}
	    ?>

	    <!-- FOOTER -->
	    <?php
	      $ok = include 'footer.php';
	      if(!$ok) {
	        echo '<footer> GTAW </footer>';
	      }
	    ?> 

  </div>
</body>
</html>