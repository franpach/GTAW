<?php
	if((include 'dbconnect.php')==FALSE) {
      header('Location: paginaerror.php');
    }
    if((include 'database.php')==FALSE) {
      header('Location: paginaerror.php');
    }

	session_start();
	$user = $_SESSION["nombre"];
	$info = $_REQUEST['info'];

	$insert = cambiarBiografia($user, $info);
	header("Location: usuario.php?usuario=$user"); 	
?>