<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>GTAW</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- CSS -->
  <link rel="stylesheet" href="bootstrap/css/header.css"> <!-- Cabecera, footer, links y título -->

  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>
  <!-- Funcionalidad de la página -->
  <script src="bootstrap/js/funcionalidad.js"></script>
</head>
<body>
  <?php
    if((include 'database.php')==FALSE) {
      header('Location: paginaerror.php');
    }

    session_start();
    if(isset($_SESSION['nombre'])) {
      $usuario = $_SESSION['nombre'];
      // si no es administrador se le redirigie al main
      $consulta = admin($usuario);
      if($consulta) {
        $fila = mysqli_fetch_row($consulta);
        $admin = $fila[0];
        if($fila[0]==0) header('Location: main.php');
      }
      else header('Location: main.php'); 
    }
    else {
      $usuario = "visitante";
      header('Location: main.php');
    }

    $lanzamientos = ultimosDiezLanz();
    if(mysqli_num_rows($lanzamientos)==0) {
      $noLanz = true;
    }    
    else $noLanz = false;
  ?>

  <div class="container">

    <!-- CABECERA -->
    <?php
      include 'menu.php';
    ?>

    <!-- LINKS -->
    <div class="row links">
      <div class="col-lg-12">
        <a href="main.php" >Inicio</a> / <a href="pagadministrador.php">Administrador</a>
      </div>
    </div>

    <!-- TÍTULO -->
    <div class="row">
      <div class="col-lg-12">
        <h1 class="titulo">Subir contenido</h1>
      </div>
    </div>
    
    <!-- LEAD -->
    <div class="row">
      <div class="col-lg-12">
        <p class="lead">Hola, administrador. Sube aquí el contenido que sea pertinente.</p>
      </div>
    </div>

    <!-- BOTONES -->  
    <div class="row">
      <div class="col-lg-3 col-lg-offset-3">
        <p><a class="btn btn-primary collapsed" data-target="#form-juego" data-toggle="collapse" aria-expanded="false">Subir un juego »</a></p>  
      </div>
      <div class="col-lg-3">
        <p><a class="btn btn-primary collapsed" data-target="#form-lanz" data-toggle="collapse" aria-expanded="false">Subir un avance »</a></p>
      </div>
    </div>

    <!-- FORM JUEGO -->
    <div class="row">
      <div class="col-lg-12">
        <form action="subirjuego.php" method="POST" id="form-juego" class="collapse" enctype="multipart/form-data">
          <div class="row">
            <div class="col-lg-6 col-lg-offset-3">
              <p><label for="nombre">Nombre:</label><input type="text" name="nombre" class="form-control input-lg" placeholder="Nombre" required></p>
            </div>
            <div class="col-lg-6 col-lg-offset-3">
              <p><label for="descripcion">Descripción:</label><textarea type="text" name="descripcion" class="form-control input-lg" placeholder="Descripción" required></textarea></p>
            </div>
            <div class="col-lg-6 col-lg-offset-3">
              <p><label for="plataforma">Plataforma:</label>
              <input type="radio" id="ps4" name="plataforma" value="ps4" checked> PS4
              <input type="radio" id="xboxOne" name="plataforma" value="xboxOne"> XBOX ONE
              <input type="radio" id="ps3" name="plataforma" value="ps3"> PS3
              <input type="radio" id="xbox360" name="plataforma" value="xbox360"> XBOX 360
              <input type="radio" id="pc" name="plataforma" value="pc"> PC
              <input type="radio" id="wii" name="plataforma" value="wii"> WII
              <input type="radio" id="wiiU" name="plataforma" value="wiiU"> WII U
              <input type="radio" id="switch" name="plataforma" value="switch"> SWITCH
            </div>
            <div class="col-lg-6 col-lg-offset-3">
              <p><label for="genero">Género:</label>
              <input type="radio" id="accion/aventuras" name="genero" value="accion/aventuras" checked> Acción / Aventuras
              <input type="radio" id="deportivo" name="genero" value="deportivo"> Deportivo
              <input type="radio" id="rol" name="genero" value="rol"> Rol
              <input type="radio" id="estrategia" name="genero" value="estrategia"> Estrategia
              <input type="radio" id="MMO" name="genero" value="MMO"> MMO
              <input type="radio" id="conduccion" name="genero" value="conduccion"> Conducción 
            </div>
          </div>
          <div class="col-lg-6 col-lg-offset-3">
            <p><label for="idioma">Idioma:</label><input type="text" name="idioma" class="form-control input-lg" placeholder="Idioma" required></p>
          </div>
          <div class="col-lg-6 col-lg-offset-3">
            <p><label for="duracion">Duración:</label><input type="text" name="duracion" class="form-control input-lg" placeholder="Duración" required></p>
          </div>
          <div class="col-lg-6 col-lg-offset-3">
            <p><label for="jugadores">Jugadores:</label><input type="number" name="jugadores" class="form-control input-lg" placeholder="Jugadores" required></p>
          </div>
          <div class="col-lg-6 col-lg-offset-3">
            <p><label for="pegi">Pegi:</label><input type="number" name="pegi" class="form-control input-lg" placeholder="Pegi" required></p>
          </div>
          <div class="col-lg-6 col-lg-offset-3">
            <p><label for="trailer">Link del trailer:</label><input type="text" name="trailer" class="form-control input-lg" placeholder="Trailer" required></p>
          </div>
          <div class="col-lg-6 col-lg-offset-3">
            <label for="fecha">Fecha:</label><input type="text" class="form-control input-lg" placeholder="Fecha" name="fecha" required>                        
          </div>
          <div class="col-lg-6 col-lg-offset-3">
            <label for="portada">Portada:</label>
            <input type="file" name="portada">                        
          </div>
          <div class="col-lg-6 col-lg-offset-3">
            <input type="submit" value="Subir juego" name="submit">
          </div>
        </form>
      </div>
    </div>
    

    <!-- FORM LANZAMIENTO -->
    <div class="row">
      <div class="col-lg-12">
        <form action="subirlanzamiento.php" method="POST" id="form-lanz" class="collapse" enctype="multipart/form-data">
          <div class="row">
            <div class="col-lg-6 col-lg-offset-3">
              <p><label for="nombreL">Nombre:</label><input type="text" name="nombreL" class="form-control input-lg" placeholder="Nombre" required></p>
            </div>
            <div class="col-lg-6 col-lg-offset-3">
              <p><label for="descripcionL">Descripción:</label><textarea type="text" name="descripcionL" class="form-control input-lg" placeholder="Descripción" required></textarea></p>
            </div>
            <div class="col-lg-6 col-lg-offset-3">
              <p><label for="plataformaL">Plataforma:</label>
              <input type="radio" name="plataformaL" value="ps4" checked> PS4
              <input type="radio" name="plataformaL" value="xboxOne"> XBOX ONE
              <input type="radio" name="plataformaL" value="ps3"> PS3
              <input type="radio" name="plataformaL" value="xbox360"> XBOX 360
              <input type="radio" name="plataformaL" value="pc"> PC
              <input type="radio" name="plataformaL" value="wii"> WII
              <input type="radio" name="plataformaL" value="wiiU"> WII U
              <input type="radio" name="plataformaL" value="switch"> SWITCH
            </div>
            <div class="col-lg-6 col-lg-offset-3">
              <p><label for="generoL">Género:</label>
              <input type="radio" name="generoL" value="accion/aventuras" checked> Acción / Aventuras
              <input type="radio" name="generoL" value="deportivo"> Deportivo
              <input type="radio" name="generoL" value="rol"> Rol
              <input type="radio" name="generoL" value="estrategia"> Estrategia
              <input type="radio" name="generoL" value="MMO"> MMO
              <input type="radio" name="generoL" value="conduccion"> Conducción 
            </div>
          </div>
          <div class="col-lg-6 col-lg-offset-3">
            <p><label for="idiomaL">Idioma:</label><input type="text" name="idiomaL" class="form-control input-lg" placeholder="Idioma" required></p>
          </div>
          <div class="col-lg-6 col-lg-offset-3">
            <p><label for="duracionL">Duración:</label><input type="text" name="duracionL" class="form-control input-lg" placeholder="Duración" required></p>
          </div>
          <div class="col-lg-6 col-lg-offset-3">
            <p><label for="jugadoresL">Jugadores:</label><input type="number" name="jugadoresL" class="form-control input-lg" placeholder="Jugadores" required></p>
          </div>
          <div class="col-lg-6 col-lg-offset-3">
            <p><label for="pegiL">Pegi:</label><input type="number" name="pegiL" class="form-control input-lg" placeholder="Pegi" required></p>
          </div>
          <div class="col-lg-6 col-lg-offset-3">
            <p><label for="trailerL">Link del trailer:</label><input type="text" name="trailerL" class="form-control input-lg" placeholder="Trailer" required></p>
          </div>
          <div class="col-lg-6 col-lg-offset-3">
            <label for="fechaL">Fecha:</label><input type="text" class="form-control input-lg" placeholder="Fecha" name="fechaL" required>                        
          </div>
          <div class="col-lg-6 col-lg-offset-3">
            <label for="portadaL">Portada:</label>
            <input type="file" name="portadaL">                        
          </div>
          <div class="col-lg-6 col-lg-offset-3">
            <input type="submit" value="Subir lanzamiento" name="submitL">
          </div>
        </form>  
      </div>
    </div>

    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?>

  </div>
</body>
</html>