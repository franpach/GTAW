<?php
    echo '<footer class="footer">
    		<div class="row">
      			<div class="col-lg-12">
      				<p>© 2016 GTAW, Inc. | Lee <a href="normas.php">aquí</a> nuestras normas | Documentación para el profesor. <a href="https://github.com/franpach/GTAW">Este</a> es el código fuente, en nuestro repositorio Github. Es el archivo GTAWFINAL. La memoria está <a href="pdfs/memoriaGTAW.pdf" download="memoriaGTAW.pdf">aquí</a>.
      				</p>
      			</div>
      		</div>
   		 </footer>'; 
?>