<?php
    echo '<footer class="footer">
    		<div class="row">
      			<div class="col-lg-12">
      				<p>© 2016 GTAW, Inc. | Lee <a href="normas.php">aquí</a> nuestras normas | Consulta <a href="https://github.com/franpach/GTAW">aquí</a> el código fuente, en nuestro repositorio Github. Es el archivo GTAWFINAL.</p>
      			</div>
      		</div>
   		 </footer>'; 
?>