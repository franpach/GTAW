<?php
	require 'dbconnect.php';
	require 'database.php';
	session_start();
	$usuario = $_SESSION['nombre'];

	$idopinion = $_GET["idopinion"];
	$comentario = htmlspecialchars(trim(strip_tags($_POST['coment-text'])));

	$insert = insertComOp($usuario, $idopinion, $comentario);
	if(!$insert) {
		echo "mal";
	}
	header("Location: opinion.php?idopinion=$idopinion");
?>