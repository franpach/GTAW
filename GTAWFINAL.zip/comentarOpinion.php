<?php
	if((include 'dbconnect.php')==FALSE) {
      header('Location: paginaerror.php');
    }
    if((include 'database.php')==FALSE) {
      header('Location: paginaerror.php');
    }
	session_start();
	$usuario = $_SESSION['nombre'];

	$idopinion = $_GET["idopinion"];
	$comentario = htmlspecialchars(trim(strip_tags($_POST['coment-text'])));

	$insert = insertComOp($usuario, $idopinion, $comentario);
	if(!$insert) {
		echo "mal";
	}
	header("Location: opinion.php?idopinion=$idopinion");
?>