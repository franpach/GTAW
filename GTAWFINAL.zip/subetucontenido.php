<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="http://getbootstrap.com/favicon.ico">

  <title>Sube tu contenido</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

  <!-- CSS -->
  <link rel="stylesheet" href="bootstrap/css/header.css"> <!-- Cabecera, footer, links y título -->
  <link rel="stylesheet" href="bootstrap/css/formularios.css"> <!-- Display de formularios -->


  <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
  <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
  <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
  <script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>
  <!-- Funcionalidad de la página -->
  <script type="text/javascript" src="bootstrap/js/funcionalidad.js"></script>
</head>
<body>
  
  <?php
    if((include 'database.php')==FALSE) {
      header('Location: paginaerror.php');
    }
    $juego = $_GET["juego"];

    session_start();
    if(isset($_SESSION['nombre'])) {
      $usuario = $_SESSION['nombre'];
    }
    else $usuario = "visitante";
  ?>

  <div class="container">

    <!-- CABECERA -->
    <?php
      include 'menu.php';
    ?>

    <!-- LINKS -->
    <div class="row links">
      <div class="col-lg-12">
        <a href="main.php" >Inicio</a> / <a href="subetucontenido.php">Sube tu contenido</a> 
      </div>
    </div>

    <!-- TITULO -->
    <div class="row">
      <div class="col-lg-12">
        <?php
          echo '<h1 class="titulo"> Sube tu contenido para <a href="juego.php?juego=' . $juego . '">' . $juego . '</a></h1>';
        ?>
      </div>
    </div>

    <!-- LEAD -->
    <div class="row">
      <div class="col-lg-12">
        <p class="lead"> ¡Exprésate libremente! Da tu opinión acerca de un juego o analiza su apartado técnico, pero recuerda, ¡siempre desde el respeto!
          Te animamos a consultar previamente nuestras normas <a href="normas.html">aquí</a> para que no nos obligues a borrar aquello que no consideremos
          adecuado para nuestro sitio.
        </p>
      </div>
    </div>

    <?php  

      if($usuario == "visitante") {
        echo '<div class="row">
                <div class="col-lg-12">
                  <p class="lead"> Si quieres participar en nuestra comunidad, tendrás que registrarte o loguearte</p>
                </div>
              </div>';
      }
      else {
        echo ' <form action="subircontenido.php?juego=' . $juego . '" method="post">
                  <div class="row">
                    <div class="col-lg-5 col-lg-offset-3">
                      <p><label for="titulo">Título:</label><input type="text" name="titulo" class="form-control input-lg" placeholder="Título" required></p>                      
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-5 col-lg-offset-3">
                      <p><label for="articulo">Tipo de artículo:</label><br>
                        <div class="row">
                          <div class="col-lg-12 radio-buttons">
                            <input type="radio" id="analisis" name="articulo" value="analisis" checked onclick="insertarNota()"> Análisis
                            <input type="radio" id="opinion" name="articulo" value="opinion" onclick="insertarNota()"> Opinión <br>
                          </div>
                        </div>
                      </p>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-5 col-lg-offset-3">
                      <p><label for="texto">Escribe aquí tu artículo:</label></p>
                      <textarea name="texto" class="textarea-lg" required></textarea>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-5 col-lg-offset-3" id="notaIn">
                      <p><label for="nota">Si es un análisis, introduce aquí tu nota:</label><input type="number" name="nota" class="form-control input-lg" max="100"></p>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-5 col-lg-offset-3">
                      <input type="submit" value="Enviar artículo">
                    </div>
                  </div>
                </form>';  
      }
      
    ?>

    <!-- FOOTER -->
    <?php
      $ok = include 'footer.php';
      if(!$ok) {
        echo '<footer> GTAW </footer>';
      }
    ?>

  </div>
</body>