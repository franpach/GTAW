<?php

	echo '<div class="masthead">
		  	<div class="row">
		    	<div class="col-lg-12">
		          <h3 class="text-muted">GTAW</h3>
		        </div>
		      </div> 
		      <div class="row">
		        <div class="col-lg-2 col-lg-offset-10">
		          <p class="accionesUser"><a href="login.php">Login</a> | <a href="registro.php">Regístrate</a></p>
		        </div>
		        <div class="row">
		          <div class="col-lg-1">
		            <button class="navbar-toggle collapsed" type="button" data-target="#navbarCollapse" data-toggle="collapse" aria-expanded="false">
		              <span class="sr-only">Toggle navigation </span>
		              <span class="icon-bar"></span>
		              <span class="icon-bar"></span>
		              <span class="icon-bar"></span>
		            </button>
		          </div>
		        </div>
		        <div id="navbarCollapse" class="navbar-collapse collapse" aria-expanded="false" role="banner">
		          <ul class="nav nav-justified">
		            <li><a href="main.php">HOME</a></li>
		            <li><a href="juegos.php">JUEGOS</a></li>
		            <li><a href="foro.php">FORO</a></li>
		            <li class="dropdown"><a class="dropbtn">TOP<span class="caret"></span></a>
		              <div class="dropdown-content">
		                <a href="topjuegos.php"> TOP JUEGOS </a>
		                <a href="topusers.php"> TOP USUARIOS </a>
		              </div>
		            </li>
		            <li class="dropdown"><a class="dropbtn">ACERCA DE<span class="caret"></span></a>
		            <div class="dropdown-content">
		              <a href="acercade.php">¿QUIÉNES SOMOS?</a>
		              <a href="contacto.php">CONTACTO</a>
		            </div>
		          </ul>
		        </div>
		      </div>
		    </div>';
?>